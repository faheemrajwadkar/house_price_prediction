
# Python Class Project  
## House Price Prediction

### Project Description
> The objective is to predict house prices in the city of Ames, Iowa based on the dataset provided

### Importing Libraries


```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
```

### Setting Options and Seed
> We need to set the option to display all the columns as Python, by default, skips a certain number of columns in the middle of the dataset
> We also need to set a seed for random generator so as to replicate our results.


```python
pd.set_option('display.max_columns', 500)
pd.set_option('display.max_rows', 5000)
pd.set_option('display.max_colwidth', 500)
pd.options.mode.chained_assignment = None
```


```python
np.random.seed(28)
```

### 1. Data Preparation
#### 1.1 Importing Dataset
> The dataset is already split into two parts - train.csv and test.csv


```python
path_train = 'C:\\Users\\Fahim Usman\\Documents\\Edu\\Data Science\\Python\\Project\\train.csv'
train = pd.read_csv(path_train)
train.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Id</th>
      <th>MSSubClass</th>
      <th>MSZoning</th>
      <th>LotFrontage</th>
      <th>LotArea</th>
      <th>Street</th>
      <th>Alley</th>
      <th>LotShape</th>
      <th>LandContour</th>
      <th>Utilities</th>
      <th>LotConfig</th>
      <th>LandSlope</th>
      <th>Neighborhood</th>
      <th>Condition1</th>
      <th>Condition2</th>
      <th>BldgType</th>
      <th>HouseStyle</th>
      <th>OverallQual</th>
      <th>OverallCond</th>
      <th>YearBuilt</th>
      <th>YearRemodAdd</th>
      <th>RoofStyle</th>
      <th>RoofMatl</th>
      <th>Exterior1st</th>
      <th>Exterior2nd</th>
      <th>MasVnrType</th>
      <th>MasVnrArea</th>
      <th>ExterQual</th>
      <th>ExterCond</th>
      <th>Foundation</th>
      <th>BsmtQual</th>
      <th>BsmtCond</th>
      <th>BsmtExposure</th>
      <th>BsmtFinType1</th>
      <th>BsmtFinSF1</th>
      <th>BsmtFinType2</th>
      <th>BsmtFinSF2</th>
      <th>BsmtUnfSF</th>
      <th>TotalBsmtSF</th>
      <th>Heating</th>
      <th>HeatingQC</th>
      <th>CentralAir</th>
      <th>Electrical</th>
      <th>1stFlrSF</th>
      <th>2ndFlrSF</th>
      <th>LowQualFinSF</th>
      <th>GrLivArea</th>
      <th>BsmtFullBath</th>
      <th>BsmtHalfBath</th>
      <th>FullBath</th>
      <th>HalfBath</th>
      <th>BedroomAbvGr</th>
      <th>KitchenAbvGr</th>
      <th>KitchenQual</th>
      <th>TotRmsAbvGrd</th>
      <th>Functional</th>
      <th>Fireplaces</th>
      <th>FireplaceQu</th>
      <th>GarageType</th>
      <th>GarageYrBlt</th>
      <th>GarageFinish</th>
      <th>GarageCars</th>
      <th>GarageArea</th>
      <th>GarageQual</th>
      <th>GarageCond</th>
      <th>PavedDrive</th>
      <th>WoodDeckSF</th>
      <th>OpenPorchSF</th>
      <th>EnclosedPorch</th>
      <th>3SsnPorch</th>
      <th>ScreenPorch</th>
      <th>PoolArea</th>
      <th>PoolQC</th>
      <th>Fence</th>
      <th>MiscFeature</th>
      <th>MiscVal</th>
      <th>MoSold</th>
      <th>YrSold</th>
      <th>SaleType</th>
      <th>SaleCondition</th>
      <th>SalePrice</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>60</td>
      <td>RL</td>
      <td>65.0</td>
      <td>8450</td>
      <td>Pave</td>
      <td>NaN</td>
      <td>Reg</td>
      <td>Lvl</td>
      <td>AllPub</td>
      <td>Inside</td>
      <td>Gtl</td>
      <td>CollgCr</td>
      <td>Norm</td>
      <td>Norm</td>
      <td>1Fam</td>
      <td>2Story</td>
      <td>7</td>
      <td>5</td>
      <td>2003</td>
      <td>2003</td>
      <td>Gable</td>
      <td>CompShg</td>
      <td>VinylSd</td>
      <td>VinylSd</td>
      <td>BrkFace</td>
      <td>196.0</td>
      <td>Gd</td>
      <td>TA</td>
      <td>PConc</td>
      <td>Gd</td>
      <td>TA</td>
      <td>No</td>
      <td>GLQ</td>
      <td>706</td>
      <td>Unf</td>
      <td>0</td>
      <td>150</td>
      <td>856</td>
      <td>GasA</td>
      <td>Ex</td>
      <td>Y</td>
      <td>SBrkr</td>
      <td>856</td>
      <td>854</td>
      <td>0</td>
      <td>1710</td>
      <td>1</td>
      <td>0</td>
      <td>2</td>
      <td>1</td>
      <td>3</td>
      <td>1</td>
      <td>Gd</td>
      <td>8</td>
      <td>Typ</td>
      <td>0</td>
      <td>NaN</td>
      <td>Attchd</td>
      <td>2003.0</td>
      <td>RFn</td>
      <td>2</td>
      <td>548</td>
      <td>TA</td>
      <td>TA</td>
      <td>Y</td>
      <td>0</td>
      <td>61</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0</td>
      <td>2</td>
      <td>2008</td>
      <td>WD</td>
      <td>Normal</td>
      <td>208500</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>20</td>
      <td>RL</td>
      <td>80.0</td>
      <td>9600</td>
      <td>Pave</td>
      <td>NaN</td>
      <td>Reg</td>
      <td>Lvl</td>
      <td>AllPub</td>
      <td>FR2</td>
      <td>Gtl</td>
      <td>Veenker</td>
      <td>Feedr</td>
      <td>Norm</td>
      <td>1Fam</td>
      <td>1Story</td>
      <td>6</td>
      <td>8</td>
      <td>1976</td>
      <td>1976</td>
      <td>Gable</td>
      <td>CompShg</td>
      <td>MetalSd</td>
      <td>MetalSd</td>
      <td>None</td>
      <td>0.0</td>
      <td>TA</td>
      <td>TA</td>
      <td>CBlock</td>
      <td>Gd</td>
      <td>TA</td>
      <td>Gd</td>
      <td>ALQ</td>
      <td>978</td>
      <td>Unf</td>
      <td>0</td>
      <td>284</td>
      <td>1262</td>
      <td>GasA</td>
      <td>Ex</td>
      <td>Y</td>
      <td>SBrkr</td>
      <td>1262</td>
      <td>0</td>
      <td>0</td>
      <td>1262</td>
      <td>0</td>
      <td>1</td>
      <td>2</td>
      <td>0</td>
      <td>3</td>
      <td>1</td>
      <td>TA</td>
      <td>6</td>
      <td>Typ</td>
      <td>1</td>
      <td>TA</td>
      <td>Attchd</td>
      <td>1976.0</td>
      <td>RFn</td>
      <td>2</td>
      <td>460</td>
      <td>TA</td>
      <td>TA</td>
      <td>Y</td>
      <td>298</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0</td>
      <td>5</td>
      <td>2007</td>
      <td>WD</td>
      <td>Normal</td>
      <td>181500</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3</td>
      <td>60</td>
      <td>RL</td>
      <td>68.0</td>
      <td>11250</td>
      <td>Pave</td>
      <td>NaN</td>
      <td>IR1</td>
      <td>Lvl</td>
      <td>AllPub</td>
      <td>Inside</td>
      <td>Gtl</td>
      <td>CollgCr</td>
      <td>Norm</td>
      <td>Norm</td>
      <td>1Fam</td>
      <td>2Story</td>
      <td>7</td>
      <td>5</td>
      <td>2001</td>
      <td>2002</td>
      <td>Gable</td>
      <td>CompShg</td>
      <td>VinylSd</td>
      <td>VinylSd</td>
      <td>BrkFace</td>
      <td>162.0</td>
      <td>Gd</td>
      <td>TA</td>
      <td>PConc</td>
      <td>Gd</td>
      <td>TA</td>
      <td>Mn</td>
      <td>GLQ</td>
      <td>486</td>
      <td>Unf</td>
      <td>0</td>
      <td>434</td>
      <td>920</td>
      <td>GasA</td>
      <td>Ex</td>
      <td>Y</td>
      <td>SBrkr</td>
      <td>920</td>
      <td>866</td>
      <td>0</td>
      <td>1786</td>
      <td>1</td>
      <td>0</td>
      <td>2</td>
      <td>1</td>
      <td>3</td>
      <td>1</td>
      <td>Gd</td>
      <td>6</td>
      <td>Typ</td>
      <td>1</td>
      <td>TA</td>
      <td>Attchd</td>
      <td>2001.0</td>
      <td>RFn</td>
      <td>2</td>
      <td>608</td>
      <td>TA</td>
      <td>TA</td>
      <td>Y</td>
      <td>0</td>
      <td>42</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0</td>
      <td>9</td>
      <td>2008</td>
      <td>WD</td>
      <td>Normal</td>
      <td>223500</td>
    </tr>
    <tr>
      <th>3</th>
      <td>4</td>
      <td>70</td>
      <td>RL</td>
      <td>60.0</td>
      <td>9550</td>
      <td>Pave</td>
      <td>NaN</td>
      <td>IR1</td>
      <td>Lvl</td>
      <td>AllPub</td>
      <td>Corner</td>
      <td>Gtl</td>
      <td>Crawfor</td>
      <td>Norm</td>
      <td>Norm</td>
      <td>1Fam</td>
      <td>2Story</td>
      <td>7</td>
      <td>5</td>
      <td>1915</td>
      <td>1970</td>
      <td>Gable</td>
      <td>CompShg</td>
      <td>Wd Sdng</td>
      <td>Wd Shng</td>
      <td>None</td>
      <td>0.0</td>
      <td>TA</td>
      <td>TA</td>
      <td>BrkTil</td>
      <td>TA</td>
      <td>Gd</td>
      <td>No</td>
      <td>ALQ</td>
      <td>216</td>
      <td>Unf</td>
      <td>0</td>
      <td>540</td>
      <td>756</td>
      <td>GasA</td>
      <td>Gd</td>
      <td>Y</td>
      <td>SBrkr</td>
      <td>961</td>
      <td>756</td>
      <td>0</td>
      <td>1717</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>3</td>
      <td>1</td>
      <td>Gd</td>
      <td>7</td>
      <td>Typ</td>
      <td>1</td>
      <td>Gd</td>
      <td>Detchd</td>
      <td>1998.0</td>
      <td>Unf</td>
      <td>3</td>
      <td>642</td>
      <td>TA</td>
      <td>TA</td>
      <td>Y</td>
      <td>0</td>
      <td>35</td>
      <td>272</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0</td>
      <td>2</td>
      <td>2006</td>
      <td>WD</td>
      <td>Abnorml</td>
      <td>140000</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5</td>
      <td>60</td>
      <td>RL</td>
      <td>84.0</td>
      <td>14260</td>
      <td>Pave</td>
      <td>NaN</td>
      <td>IR1</td>
      <td>Lvl</td>
      <td>AllPub</td>
      <td>FR2</td>
      <td>Gtl</td>
      <td>NoRidge</td>
      <td>Norm</td>
      <td>Norm</td>
      <td>1Fam</td>
      <td>2Story</td>
      <td>8</td>
      <td>5</td>
      <td>2000</td>
      <td>2000</td>
      <td>Gable</td>
      <td>CompShg</td>
      <td>VinylSd</td>
      <td>VinylSd</td>
      <td>BrkFace</td>
      <td>350.0</td>
      <td>Gd</td>
      <td>TA</td>
      <td>PConc</td>
      <td>Gd</td>
      <td>TA</td>
      <td>Av</td>
      <td>GLQ</td>
      <td>655</td>
      <td>Unf</td>
      <td>0</td>
      <td>490</td>
      <td>1145</td>
      <td>GasA</td>
      <td>Ex</td>
      <td>Y</td>
      <td>SBrkr</td>
      <td>1145</td>
      <td>1053</td>
      <td>0</td>
      <td>2198</td>
      <td>1</td>
      <td>0</td>
      <td>2</td>
      <td>1</td>
      <td>4</td>
      <td>1</td>
      <td>Gd</td>
      <td>9</td>
      <td>Typ</td>
      <td>1</td>
      <td>TA</td>
      <td>Attchd</td>
      <td>2000.0</td>
      <td>RFn</td>
      <td>3</td>
      <td>836</td>
      <td>TA</td>
      <td>TA</td>
      <td>Y</td>
      <td>192</td>
      <td>84</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0</td>
      <td>12</td>
      <td>2008</td>
      <td>WD</td>
      <td>Normal</td>
      <td>250000</td>
    </tr>
  </tbody>
</table>
</div>




```python
path_test = 'C:\\Users\\Fahim Usman\\Documents\\Edu\\Data Science\\Python\\Project\\test.csv'
test = pd.read_csv(path_test)
test.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Id</th>
      <th>MSSubClass</th>
      <th>MSZoning</th>
      <th>LotFrontage</th>
      <th>LotArea</th>
      <th>Street</th>
      <th>Alley</th>
      <th>LotShape</th>
      <th>LandContour</th>
      <th>Utilities</th>
      <th>LotConfig</th>
      <th>LandSlope</th>
      <th>Neighborhood</th>
      <th>Condition1</th>
      <th>Condition2</th>
      <th>BldgType</th>
      <th>HouseStyle</th>
      <th>OverallQual</th>
      <th>OverallCond</th>
      <th>YearBuilt</th>
      <th>YearRemodAdd</th>
      <th>RoofStyle</th>
      <th>RoofMatl</th>
      <th>Exterior1st</th>
      <th>Exterior2nd</th>
      <th>MasVnrType</th>
      <th>MasVnrArea</th>
      <th>ExterQual</th>
      <th>ExterCond</th>
      <th>Foundation</th>
      <th>BsmtQual</th>
      <th>BsmtCond</th>
      <th>BsmtExposure</th>
      <th>BsmtFinType1</th>
      <th>BsmtFinSF1</th>
      <th>BsmtFinType2</th>
      <th>BsmtFinSF2</th>
      <th>BsmtUnfSF</th>
      <th>TotalBsmtSF</th>
      <th>Heating</th>
      <th>HeatingQC</th>
      <th>CentralAir</th>
      <th>Electrical</th>
      <th>1stFlrSF</th>
      <th>2ndFlrSF</th>
      <th>LowQualFinSF</th>
      <th>GrLivArea</th>
      <th>BsmtFullBath</th>
      <th>BsmtHalfBath</th>
      <th>FullBath</th>
      <th>HalfBath</th>
      <th>BedroomAbvGr</th>
      <th>KitchenAbvGr</th>
      <th>KitchenQual</th>
      <th>TotRmsAbvGrd</th>
      <th>Functional</th>
      <th>Fireplaces</th>
      <th>FireplaceQu</th>
      <th>GarageType</th>
      <th>GarageYrBlt</th>
      <th>GarageFinish</th>
      <th>GarageCars</th>
      <th>GarageArea</th>
      <th>GarageQual</th>
      <th>GarageCond</th>
      <th>PavedDrive</th>
      <th>WoodDeckSF</th>
      <th>OpenPorchSF</th>
      <th>EnclosedPorch</th>
      <th>3SsnPorch</th>
      <th>ScreenPorch</th>
      <th>PoolArea</th>
      <th>PoolQC</th>
      <th>Fence</th>
      <th>MiscFeature</th>
      <th>MiscVal</th>
      <th>MoSold</th>
      <th>YrSold</th>
      <th>SaleType</th>
      <th>SaleCondition</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1461</td>
      <td>20</td>
      <td>RH</td>
      <td>80.0</td>
      <td>11622</td>
      <td>Pave</td>
      <td>NaN</td>
      <td>Reg</td>
      <td>Lvl</td>
      <td>AllPub</td>
      <td>Inside</td>
      <td>Gtl</td>
      <td>NAmes</td>
      <td>Feedr</td>
      <td>Norm</td>
      <td>1Fam</td>
      <td>1Story</td>
      <td>5</td>
      <td>6</td>
      <td>1961</td>
      <td>1961</td>
      <td>Gable</td>
      <td>CompShg</td>
      <td>VinylSd</td>
      <td>VinylSd</td>
      <td>None</td>
      <td>0.0</td>
      <td>TA</td>
      <td>TA</td>
      <td>CBlock</td>
      <td>TA</td>
      <td>TA</td>
      <td>No</td>
      <td>Rec</td>
      <td>468.0</td>
      <td>LwQ</td>
      <td>144.0</td>
      <td>270.0</td>
      <td>882.0</td>
      <td>GasA</td>
      <td>TA</td>
      <td>Y</td>
      <td>SBrkr</td>
      <td>896</td>
      <td>0</td>
      <td>0</td>
      <td>896</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1</td>
      <td>0</td>
      <td>2</td>
      <td>1</td>
      <td>TA</td>
      <td>5</td>
      <td>Typ</td>
      <td>0</td>
      <td>NaN</td>
      <td>Attchd</td>
      <td>1961.0</td>
      <td>Unf</td>
      <td>1.0</td>
      <td>730.0</td>
      <td>TA</td>
      <td>TA</td>
      <td>Y</td>
      <td>140</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>120</td>
      <td>0</td>
      <td>NaN</td>
      <td>MnPrv</td>
      <td>NaN</td>
      <td>0</td>
      <td>6</td>
      <td>2010</td>
      <td>WD</td>
      <td>Normal</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1462</td>
      <td>20</td>
      <td>RL</td>
      <td>81.0</td>
      <td>14267</td>
      <td>Pave</td>
      <td>NaN</td>
      <td>IR1</td>
      <td>Lvl</td>
      <td>AllPub</td>
      <td>Corner</td>
      <td>Gtl</td>
      <td>NAmes</td>
      <td>Norm</td>
      <td>Norm</td>
      <td>1Fam</td>
      <td>1Story</td>
      <td>6</td>
      <td>6</td>
      <td>1958</td>
      <td>1958</td>
      <td>Hip</td>
      <td>CompShg</td>
      <td>Wd Sdng</td>
      <td>Wd Sdng</td>
      <td>BrkFace</td>
      <td>108.0</td>
      <td>TA</td>
      <td>TA</td>
      <td>CBlock</td>
      <td>TA</td>
      <td>TA</td>
      <td>No</td>
      <td>ALQ</td>
      <td>923.0</td>
      <td>Unf</td>
      <td>0.0</td>
      <td>406.0</td>
      <td>1329.0</td>
      <td>GasA</td>
      <td>TA</td>
      <td>Y</td>
      <td>SBrkr</td>
      <td>1329</td>
      <td>0</td>
      <td>0</td>
      <td>1329</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1</td>
      <td>1</td>
      <td>3</td>
      <td>1</td>
      <td>Gd</td>
      <td>6</td>
      <td>Typ</td>
      <td>0</td>
      <td>NaN</td>
      <td>Attchd</td>
      <td>1958.0</td>
      <td>Unf</td>
      <td>1.0</td>
      <td>312.0</td>
      <td>TA</td>
      <td>TA</td>
      <td>Y</td>
      <td>393</td>
      <td>36</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Gar2</td>
      <td>12500</td>
      <td>6</td>
      <td>2010</td>
      <td>WD</td>
      <td>Normal</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1463</td>
      <td>60</td>
      <td>RL</td>
      <td>74.0</td>
      <td>13830</td>
      <td>Pave</td>
      <td>NaN</td>
      <td>IR1</td>
      <td>Lvl</td>
      <td>AllPub</td>
      <td>Inside</td>
      <td>Gtl</td>
      <td>Gilbert</td>
      <td>Norm</td>
      <td>Norm</td>
      <td>1Fam</td>
      <td>2Story</td>
      <td>5</td>
      <td>5</td>
      <td>1997</td>
      <td>1998</td>
      <td>Gable</td>
      <td>CompShg</td>
      <td>VinylSd</td>
      <td>VinylSd</td>
      <td>None</td>
      <td>0.0</td>
      <td>TA</td>
      <td>TA</td>
      <td>PConc</td>
      <td>Gd</td>
      <td>TA</td>
      <td>No</td>
      <td>GLQ</td>
      <td>791.0</td>
      <td>Unf</td>
      <td>0.0</td>
      <td>137.0</td>
      <td>928.0</td>
      <td>GasA</td>
      <td>Gd</td>
      <td>Y</td>
      <td>SBrkr</td>
      <td>928</td>
      <td>701</td>
      <td>0</td>
      <td>1629</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>2</td>
      <td>1</td>
      <td>3</td>
      <td>1</td>
      <td>TA</td>
      <td>6</td>
      <td>Typ</td>
      <td>1</td>
      <td>TA</td>
      <td>Attchd</td>
      <td>1997.0</td>
      <td>Fin</td>
      <td>2.0</td>
      <td>482.0</td>
      <td>TA</td>
      <td>TA</td>
      <td>Y</td>
      <td>212</td>
      <td>34</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>NaN</td>
      <td>MnPrv</td>
      <td>NaN</td>
      <td>0</td>
      <td>3</td>
      <td>2010</td>
      <td>WD</td>
      <td>Normal</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1464</td>
      <td>60</td>
      <td>RL</td>
      <td>78.0</td>
      <td>9978</td>
      <td>Pave</td>
      <td>NaN</td>
      <td>IR1</td>
      <td>Lvl</td>
      <td>AllPub</td>
      <td>Inside</td>
      <td>Gtl</td>
      <td>Gilbert</td>
      <td>Norm</td>
      <td>Norm</td>
      <td>1Fam</td>
      <td>2Story</td>
      <td>6</td>
      <td>6</td>
      <td>1998</td>
      <td>1998</td>
      <td>Gable</td>
      <td>CompShg</td>
      <td>VinylSd</td>
      <td>VinylSd</td>
      <td>BrkFace</td>
      <td>20.0</td>
      <td>TA</td>
      <td>TA</td>
      <td>PConc</td>
      <td>TA</td>
      <td>TA</td>
      <td>No</td>
      <td>GLQ</td>
      <td>602.0</td>
      <td>Unf</td>
      <td>0.0</td>
      <td>324.0</td>
      <td>926.0</td>
      <td>GasA</td>
      <td>Ex</td>
      <td>Y</td>
      <td>SBrkr</td>
      <td>926</td>
      <td>678</td>
      <td>0</td>
      <td>1604</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>2</td>
      <td>1</td>
      <td>3</td>
      <td>1</td>
      <td>Gd</td>
      <td>7</td>
      <td>Typ</td>
      <td>1</td>
      <td>Gd</td>
      <td>Attchd</td>
      <td>1998.0</td>
      <td>Fin</td>
      <td>2.0</td>
      <td>470.0</td>
      <td>TA</td>
      <td>TA</td>
      <td>Y</td>
      <td>360</td>
      <td>36</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0</td>
      <td>6</td>
      <td>2010</td>
      <td>WD</td>
      <td>Normal</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1465</td>
      <td>120</td>
      <td>RL</td>
      <td>43.0</td>
      <td>5005</td>
      <td>Pave</td>
      <td>NaN</td>
      <td>IR1</td>
      <td>HLS</td>
      <td>AllPub</td>
      <td>Inside</td>
      <td>Gtl</td>
      <td>StoneBr</td>
      <td>Norm</td>
      <td>Norm</td>
      <td>TwnhsE</td>
      <td>1Story</td>
      <td>8</td>
      <td>5</td>
      <td>1992</td>
      <td>1992</td>
      <td>Gable</td>
      <td>CompShg</td>
      <td>HdBoard</td>
      <td>HdBoard</td>
      <td>None</td>
      <td>0.0</td>
      <td>Gd</td>
      <td>TA</td>
      <td>PConc</td>
      <td>Gd</td>
      <td>TA</td>
      <td>No</td>
      <td>ALQ</td>
      <td>263.0</td>
      <td>Unf</td>
      <td>0.0</td>
      <td>1017.0</td>
      <td>1280.0</td>
      <td>GasA</td>
      <td>Ex</td>
      <td>Y</td>
      <td>SBrkr</td>
      <td>1280</td>
      <td>0</td>
      <td>0</td>
      <td>1280</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>2</td>
      <td>0</td>
      <td>2</td>
      <td>1</td>
      <td>Gd</td>
      <td>5</td>
      <td>Typ</td>
      <td>0</td>
      <td>NaN</td>
      <td>Attchd</td>
      <td>1992.0</td>
      <td>RFn</td>
      <td>2.0</td>
      <td>506.0</td>
      <td>TA</td>
      <td>TA</td>
      <td>Y</td>
      <td>0</td>
      <td>82</td>
      <td>0</td>
      <td>0</td>
      <td>144</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0</td>
      <td>1</td>
      <td>2010</td>
      <td>WD</td>
      <td>Normal</td>
    </tr>
  </tbody>
</table>
</div>




```python
%%html
<style>
table {float:left}
</style>
```


<style>
table {float:left}
</style>



#### 1.2 Data Preview


```python
train.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 1460 entries, 0 to 1459
    Data columns (total 81 columns):
    Id               1460 non-null int64
    MSSubClass       1460 non-null int64
    MSZoning         1460 non-null object
    LotFrontage      1201 non-null float64
    LotArea          1460 non-null int64
    Street           1460 non-null object
    Alley            91 non-null object
    LotShape         1460 non-null object
    LandContour      1460 non-null object
    Utilities        1460 non-null object
    LotConfig        1460 non-null object
    LandSlope        1460 non-null object
    Neighborhood     1460 non-null object
    Condition1       1460 non-null object
    Condition2       1460 non-null object
    BldgType         1460 non-null object
    HouseStyle       1460 non-null object
    OverallQual      1460 non-null int64
    OverallCond      1460 non-null int64
    YearBuilt        1460 non-null int64
    YearRemodAdd     1460 non-null int64
    RoofStyle        1460 non-null object
    RoofMatl         1460 non-null object
    Exterior1st      1460 non-null object
    Exterior2nd      1460 non-null object
    MasVnrType       1452 non-null object
    MasVnrArea       1452 non-null float64
    ExterQual        1460 non-null object
    ExterCond        1460 non-null object
    Foundation       1460 non-null object
    BsmtQual         1423 non-null object
    BsmtCond         1423 non-null object
    BsmtExposure     1422 non-null object
    BsmtFinType1     1423 non-null object
    BsmtFinSF1       1460 non-null int64
    BsmtFinType2     1422 non-null object
    BsmtFinSF2       1460 non-null int64
    BsmtUnfSF        1460 non-null int64
    TotalBsmtSF      1460 non-null int64
    Heating          1460 non-null object
    HeatingQC        1460 non-null object
    CentralAir       1460 non-null object
    Electrical       1459 non-null object
    1stFlrSF         1460 non-null int64
    2ndFlrSF         1460 non-null int64
    LowQualFinSF     1460 non-null int64
    GrLivArea        1460 non-null int64
    BsmtFullBath     1460 non-null int64
    BsmtHalfBath     1460 non-null int64
    FullBath         1460 non-null int64
    HalfBath         1460 non-null int64
    BedroomAbvGr     1460 non-null int64
    KitchenAbvGr     1460 non-null int64
    KitchenQual      1460 non-null object
    TotRmsAbvGrd     1460 non-null int64
    Functional       1460 non-null object
    Fireplaces       1460 non-null int64
    FireplaceQu      770 non-null object
    GarageType       1379 non-null object
    GarageYrBlt      1379 non-null float64
    GarageFinish     1379 non-null object
    GarageCars       1460 non-null int64
    GarageArea       1460 non-null int64
    GarageQual       1379 non-null object
    GarageCond       1379 non-null object
    PavedDrive       1460 non-null object
    WoodDeckSF       1460 non-null int64
    OpenPorchSF      1460 non-null int64
    EnclosedPorch    1460 non-null int64
    3SsnPorch        1460 non-null int64
    ScreenPorch      1460 non-null int64
    PoolArea         1460 non-null int64
    PoolQC           7 non-null object
    Fence            281 non-null object
    MiscFeature      54 non-null object
    MiscVal          1460 non-null int64
    MoSold           1460 non-null int64
    YrSold           1460 non-null int64
    SaleType         1460 non-null object
    SaleCondition    1460 non-null object
    SalePrice        1460 non-null int64
    dtypes: float64(3), int64(35), object(43)
    memory usage: 924.0+ KB
    

**Some Notable Observations**  
* The variables Alley, PoolQC, Fence and MiscFeature have over 80 to 90 percent of NAs or Nulls.
* The variable Fireplace has more than half of values as NAs or Nulls.

We will treat these values later in the Data Preparation section.

#### 1.3 Data Cleaning
We will now clean the data i.e. fix or remove missing values, eliminate or add new features, etc. But first, let's list down what each of the features mean.


```python
features = pd.read_csv("features.csv", index_col = "No.")
features
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Feature Name</th>
      <th>Feature Description</th>
      <th>Type</th>
      <th>Nulls</th>
      <th>Nulls_per</th>
      <th>Zeros</th>
      <th>Zeros_per</th>
    </tr>
    <tr>
      <th>No.</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>MSSubClass</td>
      <td>Identifies the type of dwelling involved in the sale.</td>
      <td>Categorical</td>
      <td>0</td>
      <td>0%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>2</th>
      <td>MSZoning</td>
      <td>Identifies the general zoning classification of the sale.</td>
      <td>Categorical</td>
      <td>0</td>
      <td>0%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>3</th>
      <td>LotFrontage</td>
      <td>Linear feet of street connected to property</td>
      <td>Numeric</td>
      <td>259</td>
      <td>18%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>4</th>
      <td>LotArea</td>
      <td>Lot size in square feet</td>
      <td>Numeric</td>
      <td>0</td>
      <td>0%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Street</td>
      <td>Type of road access to property</td>
      <td>Categorical</td>
      <td>0</td>
      <td>0%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Alley</td>
      <td>Type of alley access to property</td>
      <td>Categorical</td>
      <td>1369</td>
      <td>94%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>7</th>
      <td>LotShape</td>
      <td>General shape of property</td>
      <td>Categorical</td>
      <td>0</td>
      <td>0%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>8</th>
      <td>LandContour</td>
      <td>Flatness of the property</td>
      <td>Categorical</td>
      <td>0</td>
      <td>0%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Utilities</td>
      <td>Type of utilities available</td>
      <td>Categorical</td>
      <td>0</td>
      <td>0%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>10</th>
      <td>LotConfig</td>
      <td>Lot configuration</td>
      <td>Categorical</td>
      <td>0</td>
      <td>0%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>11</th>
      <td>LandSlope</td>
      <td>Slope of property</td>
      <td>Categorical</td>
      <td>0</td>
      <td>0%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Neighborhood</td>
      <td>Physical locations within Ames city limits</td>
      <td>Categorical</td>
      <td>0</td>
      <td>0%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>13</th>
      <td>Condition1</td>
      <td>Proximity to various conditions</td>
      <td>Categorical</td>
      <td>0</td>
      <td>0%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Condition2</td>
      <td>Proximity to various conditions (if more than one is present)</td>
      <td>Categorical</td>
      <td>0</td>
      <td>0%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>15</th>
      <td>BldgType</td>
      <td>Type of dwelling</td>
      <td>Categorical</td>
      <td>0</td>
      <td>0%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>16</th>
      <td>HouseStyle</td>
      <td>Style of dwelling</td>
      <td>Categorical</td>
      <td>0</td>
      <td>0%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>17</th>
      <td>OverallQual</td>
      <td>Rates the overall material and finish of the house</td>
      <td>Categorical</td>
      <td>0</td>
      <td>0%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>18</th>
      <td>OverallCond</td>
      <td>Rates the overall condition of the house</td>
      <td>Categorical</td>
      <td>0</td>
      <td>0%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>19</th>
      <td>YearBuilt</td>
      <td>Original construction date</td>
      <td>Datetime</td>
      <td>0</td>
      <td>0%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>20</th>
      <td>YearRemodAdd</td>
      <td>Remodel date (same as construction date if no remodeling or additions)</td>
      <td>Datetime</td>
      <td>0</td>
      <td>0%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>21</th>
      <td>RoofStyle</td>
      <td>Type of roof</td>
      <td>Categorical</td>
      <td>0</td>
      <td>0%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>22</th>
      <td>RoofMatl</td>
      <td>Roof material</td>
      <td>Categorical</td>
      <td>0</td>
      <td>0%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>23</th>
      <td>Exterior1st</td>
      <td>Exterior covering on house</td>
      <td>Categorical</td>
      <td>0</td>
      <td>0%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>24</th>
      <td>Exterior2nd</td>
      <td>Exterior covering on house (if more than one material)</td>
      <td>Categorical</td>
      <td>0</td>
      <td>0%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>25</th>
      <td>MasVnrType</td>
      <td>Masonry veneer type</td>
      <td>Categorical</td>
      <td>8</td>
      <td>1%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>26</th>
      <td>MasVnrArea</td>
      <td>Masonry veneer area in square feet</td>
      <td>Numeric</td>
      <td>8</td>
      <td>1%</td>
      <td>861</td>
      <td>59%</td>
    </tr>
    <tr>
      <th>27</th>
      <td>ExterQual</td>
      <td>Evaluates the quality of the material on the exterior</td>
      <td>Categorical</td>
      <td>0</td>
      <td>0%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>28</th>
      <td>ExterCond</td>
      <td>Evaluates the present condition of the material on the exterior</td>
      <td>Categorical</td>
      <td>0</td>
      <td>0%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>29</th>
      <td>Foundation</td>
      <td>Type of foundation</td>
      <td>Categorical</td>
      <td>0</td>
      <td>0%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>30</th>
      <td>BsmtQual</td>
      <td>Evaluates the height of the basement</td>
      <td>Categorical</td>
      <td>37</td>
      <td>3%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>31</th>
      <td>BsmtCond</td>
      <td>Evaluates the general condition of the basement</td>
      <td>Categorical</td>
      <td>37</td>
      <td>3%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>32</th>
      <td>BsmtExposure</td>
      <td>Refers to walkout or garden level walls</td>
      <td>Categorical</td>
      <td>38</td>
      <td>3%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>33</th>
      <td>BsmtFinType1</td>
      <td>Rating of basement finished area</td>
      <td>Categorical</td>
      <td>37</td>
      <td>3%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>34</th>
      <td>BsmtFinSF1</td>
      <td>Type 1 finished square feet</td>
      <td>Numeric</td>
      <td>0</td>
      <td>0%</td>
      <td>467</td>
      <td>32%</td>
    </tr>
    <tr>
      <th>35</th>
      <td>BsmtFinType2</td>
      <td>Rating of basement finished area (if multiple types)</td>
      <td>Categorical</td>
      <td>38</td>
      <td>3%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>36</th>
      <td>BsmtFinSF2</td>
      <td>Type 2 finished square feet</td>
      <td>Numeric</td>
      <td>0</td>
      <td>0%</td>
      <td>1293</td>
      <td>89%</td>
    </tr>
    <tr>
      <th>37</th>
      <td>BsmtUnfSF</td>
      <td>Unfinished square feet of basement area</td>
      <td>Numeric</td>
      <td>0</td>
      <td>0%</td>
      <td>118</td>
      <td>8%</td>
    </tr>
    <tr>
      <th>38</th>
      <td>TotalBsmtSF</td>
      <td>Total square feet of basement area</td>
      <td>Numeric</td>
      <td>0</td>
      <td>0%</td>
      <td>37</td>
      <td>3%</td>
    </tr>
    <tr>
      <th>39</th>
      <td>Heating</td>
      <td>Type of heating</td>
      <td>Categorical</td>
      <td>0</td>
      <td>0%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>40</th>
      <td>HeatingQC</td>
      <td>Heating quality and condition</td>
      <td>Categorical</td>
      <td>0</td>
      <td>0%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>41</th>
      <td>CentralAir</td>
      <td>Central air conditioning</td>
      <td>Categorical</td>
      <td>0</td>
      <td>0%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>42</th>
      <td>Electrical</td>
      <td>Electrical system</td>
      <td>Categorical</td>
      <td>1</td>
      <td>0%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>43</th>
      <td>1stFlrSF</td>
      <td>First Floor square feet</td>
      <td>Numeric</td>
      <td>0</td>
      <td>0%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>44</th>
      <td>2ndFlrSF</td>
      <td>Second floor square feet</td>
      <td>Numeric</td>
      <td>0</td>
      <td>0%</td>
      <td>829</td>
      <td>57%</td>
    </tr>
    <tr>
      <th>45</th>
      <td>LowQualFinSF</td>
      <td>Low quality finished square feet (all floors)</td>
      <td>Numeric</td>
      <td>0</td>
      <td>0%</td>
      <td>1434</td>
      <td>98%</td>
    </tr>
    <tr>
      <th>46</th>
      <td>GrLivArea</td>
      <td>Above grade (ground) living area square feet</td>
      <td>Numeric</td>
      <td>0</td>
      <td>0%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>47</th>
      <td>BsmtFullBath</td>
      <td>Basement full bathrooms</td>
      <td>Numeric</td>
      <td>0</td>
      <td>0%</td>
      <td>856</td>
      <td>59%</td>
    </tr>
    <tr>
      <th>48</th>
      <td>BsmtHalfBath</td>
      <td>Basement half bathrooms</td>
      <td>Numeric</td>
      <td>0</td>
      <td>0%</td>
      <td>1378</td>
      <td>94%</td>
    </tr>
    <tr>
      <th>49</th>
      <td>FullBath</td>
      <td>Full bathrooms above grade</td>
      <td>Numeric</td>
      <td>0</td>
      <td>0%</td>
      <td>9</td>
      <td>1%</td>
    </tr>
    <tr>
      <th>50</th>
      <td>HalfBath</td>
      <td>Half baths above grade</td>
      <td>Numeric</td>
      <td>0</td>
      <td>0%</td>
      <td>913</td>
      <td>63%</td>
    </tr>
    <tr>
      <th>51</th>
      <td>BedroomAbvGr</td>
      <td>Bedrooms above grade (does NOT include basement bedrooms)</td>
      <td>Numeric</td>
      <td>0</td>
      <td>0%</td>
      <td>6</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>52</th>
      <td>KitchenAbvGr</td>
      <td>Kitchens above grade</td>
      <td>Numeric</td>
      <td>0</td>
      <td>0%</td>
      <td>1</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>53</th>
      <td>KitchenQual</td>
      <td>Kitchen quality</td>
      <td>Categorical</td>
      <td>0</td>
      <td>0%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>54</th>
      <td>TotRmsAbvGrd</td>
      <td>Total rooms above grade (does not include bathrooms)</td>
      <td>Numeric</td>
      <td>0</td>
      <td>0%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>55</th>
      <td>Functional</td>
      <td>Home functionality (Assume typical unless deductions are warranted)</td>
      <td>Categorical</td>
      <td>0</td>
      <td>0%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>56</th>
      <td>Fireplaces</td>
      <td>Number of fireplaces</td>
      <td>Numeric</td>
      <td>0</td>
      <td>0%</td>
      <td>690</td>
      <td>47%</td>
    </tr>
    <tr>
      <th>57</th>
      <td>FireplaceQu</td>
      <td>Fireplace quality</td>
      <td>Categorical</td>
      <td>690</td>
      <td>47%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>58</th>
      <td>GarageType</td>
      <td>Garage location</td>
      <td>Categorical</td>
      <td>81</td>
      <td>6%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>59</th>
      <td>GarageYrBlt</td>
      <td>Year garage was built</td>
      <td>Datetime</td>
      <td>81</td>
      <td>6%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>60</th>
      <td>GarageFinish</td>
      <td>Interior finish of the garage</td>
      <td>Categorical</td>
      <td>81</td>
      <td>6%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>61</th>
      <td>GarageCars</td>
      <td>Size of garage in car capacity</td>
      <td>Numeric</td>
      <td>0</td>
      <td>0%</td>
      <td>81</td>
      <td>6%</td>
    </tr>
    <tr>
      <th>62</th>
      <td>GarageArea</td>
      <td>Size of garage in square feet</td>
      <td>Numeric</td>
      <td>0</td>
      <td>0%</td>
      <td>81</td>
      <td>6%</td>
    </tr>
    <tr>
      <th>63</th>
      <td>GarageQual</td>
      <td>Garage quality</td>
      <td>Categorical</td>
      <td>81</td>
      <td>6%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>64</th>
      <td>GarageCond</td>
      <td>Garage condition</td>
      <td>Categorical</td>
      <td>81</td>
      <td>6%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>65</th>
      <td>PavedDrive</td>
      <td>Paved driveway</td>
      <td>Categorical</td>
      <td>0</td>
      <td>0%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>66</th>
      <td>WoodDeckSF</td>
      <td>Wood deck area in square feet</td>
      <td>Numeric</td>
      <td>0</td>
      <td>0%</td>
      <td>761</td>
      <td>52%</td>
    </tr>
    <tr>
      <th>67</th>
      <td>OpenPorchSF</td>
      <td>Open porch area in square feet</td>
      <td>Numeric</td>
      <td>0</td>
      <td>0%</td>
      <td>656</td>
      <td>45%</td>
    </tr>
    <tr>
      <th>68</th>
      <td>EnclosedPorch</td>
      <td>Enclosed porch area in square feet</td>
      <td>Numeric</td>
      <td>0</td>
      <td>0%</td>
      <td>1252</td>
      <td>86%</td>
    </tr>
    <tr>
      <th>69</th>
      <td>3SsnPorch</td>
      <td>Three season porch area in square feet</td>
      <td>Numeric</td>
      <td>0</td>
      <td>0%</td>
      <td>1436</td>
      <td>98%</td>
    </tr>
    <tr>
      <th>70</th>
      <td>ScreenPorch</td>
      <td>Screen porch area in square feet</td>
      <td>Numeric</td>
      <td>0</td>
      <td>0%</td>
      <td>1344</td>
      <td>92%</td>
    </tr>
    <tr>
      <th>71</th>
      <td>PoolArea</td>
      <td>Pool area in square feet</td>
      <td>Numeric</td>
      <td>0</td>
      <td>0%</td>
      <td>1453</td>
      <td>100%</td>
    </tr>
    <tr>
      <th>72</th>
      <td>PoolQC</td>
      <td>Pool quality</td>
      <td>Categorical</td>
      <td>1453</td>
      <td>100%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>73</th>
      <td>Fence</td>
      <td>Fence quality</td>
      <td>Categorical</td>
      <td>1179</td>
      <td>81%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>74</th>
      <td>MiscFeature</td>
      <td>Miscellaneous feature not covered in other categories</td>
      <td>Categorical</td>
      <td>1406</td>
      <td>96%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>75</th>
      <td>MiscVal</td>
      <td>$Value of miscellaneous feature</td>
      <td>Numeric</td>
      <td>0</td>
      <td>0%</td>
      <td>1408</td>
      <td>96%</td>
    </tr>
    <tr>
      <th>76</th>
      <td>MoSold</td>
      <td>Month Sold (MM)</td>
      <td>Datetime</td>
      <td>0</td>
      <td>0%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>77</th>
      <td>YrSold</td>
      <td>Year Sold (YYYY)</td>
      <td>Datetime</td>
      <td>0</td>
      <td>0%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>78</th>
      <td>SaleType</td>
      <td>Type of sale</td>
      <td>Categorical</td>
      <td>0</td>
      <td>0%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
    <tr>
      <th>79</th>
      <td>SaleCondition</td>
      <td>Condition of Sale</td>
      <td>Categorical</td>
      <td>0</td>
      <td>0%</td>
      <td>0</td>
      <td>0%</td>
    </tr>
  </tbody>
</table>
</div>



**The prediction variable** 

| Feature Name  |  Feature Description                                                    | Type        |
|:--------------|:------------------------------------------------------------------------|:-----------:|
| SalePrice     |  Price of House                                                         | Numeric     |


The variables, though, have the following datatypes only - 


```python
print(train.dtypes.unique())
```

    [dtype('int64') dtype('O') dtype('float64')]
    

As we can see, there are no variables having datetime as their datatype (or categorical, but one thing at a time). Now do we really need datetime variables in our data?  
Let's take a look at the unique values in these 5 columns - 


```python
datetimes = list(features[features.Type == "Datetime"]["Feature Name"])
for e in datetimes:
    print("Unique Values in", e)
    print(train[e].unique(), '\n')
```

    Unique Values in YearBuilt
    [2003 1976 2001 1915 2000 1993 2004 1973 1931 1939 1965 2005 1962 2006
     1960 1929 1970 1967 1958 1930 2002 1968 2007 1951 1957 1927 1920 1966
     1959 1994 1954 1953 1955 1983 1975 1997 1934 1963 1981 1964 1999 1972
     1921 1945 1982 1998 1956 1948 1910 1995 1991 2009 1950 1961 1977 1985
     1979 1885 1919 1990 1969 1935 1988 1971 1952 1936 1923 1924 1984 1926
     1940 1941 1987 1986 2008 1908 1892 1916 1932 1918 1912 1947 1925 1900
     1980 1989 1992 1949 1880 1928 1978 1922 1996 2010 1946 1913 1937 1942
     1938 1974 1893 1914 1906 1890 1898 1904 1882 1875 1911 1917 1872 1905] 
    
    Unique Values in YearRemodAdd
    [2003 1976 2002 1970 2000 1995 2005 1973 1950 1965 2006 1962 2007 1960
     2001 1967 2004 2008 1997 1959 1990 1955 1983 1980 1966 1963 1987 1964
     1972 1996 1998 1989 1953 1956 1968 1981 1992 2009 1982 1961 1993 1999
     1985 1979 1977 1969 1958 1991 1971 1952 1975 2010 1984 1986 1994 1988
     1954 1957 1951 1978 1974] 
    
    Unique Values in GarageYrBlt
    [2003. 1976. 2001. 1998. 2000. 1993. 2004. 1973. 1931. 1939. 1965. 2005.
     1962. 2006. 1960. 1991. 1970. 1967. 1958. 1930. 2002. 1968. 2007. 2008.
     1957. 1920. 1966. 1959. 1995. 1954. 1953.   nan 1983. 1977. 1997. 1985.
     1963. 1981. 1964. 1999. 1935. 1990. 1945. 1987. 1989. 1915. 1956. 1948.
     1974. 2009. 1950. 1961. 1921. 1900. 1979. 1951. 1969. 1936. 1975. 1971.
     1923. 1984. 1926. 1955. 1986. 1988. 1916. 1932. 1972. 1918. 1980. 1924.
     1996. 1940. 1949. 1994. 1910. 1978. 1982. 1992. 1925. 1941. 2010. 1927.
     1947. 1937. 1942. 1938. 1952. 1928. 1922. 1934. 1906. 1914. 1946. 1908.
     1929. 1933.] 
    
    Unique Values in MoSold
    [ 2  5  9 12 10  8 11  4  1  7  3  6] 
    
    Unique Values in YrSold
    [2008 2007 2006 2009 2010] 
    
    

As seen above, we have 5 variables having datetime information - Years that the house was built in, the house was remodelled in, the garage was built in and the house was (or will be) sold in, respectively. The fifth is the month of sale. Rather than converting them into datetime we will keep them as numeric and then engineer a few new features from them.

Now that we've decided what to do with the datetime variables, let's start looking at the categorical variables.

First, we will create two variables - cols_cat and cols_num - which will hold the names of all the categorical and numerical variables, respectively. Let's extract them from the table mentioned above.


```python
cols_num = list(features[features["Type"] == "Numeric"]["Feature Name"])
cols_cat = list(features[features["Type"] == "Categorical"]["Feature Name"])
print("Categorical Features", cols_cat, "","Numerical Features", cols_num, sep = '\n')
```

    Categorical Features
    ['MSSubClass', 'MSZoning', 'Street', 'Alley', 'LotShape', 'LandContour', 'Utilities', 'LotConfig', 'LandSlope', 'Neighborhood', 'Condition1', 'Condition2', 'BldgType', 'HouseStyle', 'OverallQual', 'OverallCond', 'RoofStyle', 'RoofMatl', 'Exterior1st', 'Exterior2nd', 'MasVnrType', 'ExterQual', 'ExterCond', 'Foundation', 'BsmtQual', 'BsmtCond', 'BsmtExposure', 'BsmtFinType1', 'BsmtFinType2', 'Heating', 'HeatingQC', 'CentralAir', 'Electrical', 'KitchenQual', 'Functional', 'FireplaceQu', 'GarageType', 'GarageFinish', 'GarageQual', 'GarageCond', 'PavedDrive', 'PoolQC', 'Fence', 'MiscFeature', 'SaleType', 'SaleCondition']
    
    Numerical Features
    ['LotFrontage', 'LotArea', 'MasVnrArea', 'BsmtFinSF1', 'BsmtFinSF2', 'BsmtUnfSF', 'TotalBsmtSF', '1stFlrSF', '2ndFlrSF', 'LowQualFinSF', 'GrLivArea', 'BsmtFullBath', 'BsmtHalfBath', 'FullBath', 'HalfBath', 'BedroomAbvGr', 'KitchenAbvGr', 'TotRmsAbvGrd', 'Fireplaces', 'GarageCars', 'GarageArea', 'WoodDeckSF', 'OpenPorchSF', 'EnclosedPorch', '3SsnPorch', 'ScreenPorch', 'PoolArea', 'MiscVal']
    


```python
n = []
print("No. of Nulls")
print("============")
for e in train.iloc[:, 1:-1].columns:
    if train[e].isna().sum() > 0:
        n.append(e)
        print(e, "-->", train[e].isna().sum(), "=", format(((train[e].isna().sum() / train.shape[0]) * 100), ".0f"), "%")
```

    No. of Nulls
    ============
    LotFrontage --> 259 = 18 %
    Alley --> 1369 = 94 %
    MasVnrType --> 8 = 1 %
    MasVnrArea --> 8 = 1 %
    BsmtQual --> 37 = 3 %
    BsmtCond --> 37 = 3 %
    BsmtExposure --> 38 = 3 %
    BsmtFinType1 --> 37 = 3 %
    BsmtFinType2 --> 38 = 3 %
    Electrical --> 1 = 0 %
    FireplaceQu --> 690 = 47 %
    GarageType --> 81 = 6 %
    GarageYrBlt --> 81 = 6 %
    GarageFinish --> 81 = 6 %
    GarageQual --> 81 = 6 %
    GarageCond --> 81 = 6 %
    PoolQC --> 1453 = 100 %
    Fence --> 1179 = 81 %
    MiscFeature --> 1406 = 96 %
    

Now that we know where the Null values are, we can treat them each as follows using the documentation provided

| No. (n) | Feature Name | Nulls | Notes                                                       |
|---------|--------------|-------|-------------------------------------------------------------|
| 0       | LotFrontage  | 259   | Put them as zeros                                           |
| 1       | Alley        | 1369  | NA = No alley Access o we will put "None"                   |
| 2       | MasVnrType   | 8     | NA = No masonry so put "None"                               |
| 3       | MasVnrArea   | 8     | NA = 0 as no masonry area                                   |
| 4       | BsmtQual     | 37    | NA = no baement so "None"                                   |
| 5       | BsmtCond     | 37    | NA = no baement so "None"                                   |
| 6       | BsmtExposure | 38    | NA = no baement so "None"                                   |
| 7       | BsmtFinType1 | 37    | NA = no baement so "None"                                   |
| 8       | BsmtFinType2 | 38    | NA = no baement so "None"                                   |
| 9       | Electrical   | 1     | Only 1 so we will remove that observation                   |
| 10      | FireplaceQu  | 690   | NA = no fireplace so "None"                                 |
| 11      | GarageType   | 81    | NA = no garage so "None"                                    |
| 12      | GarageYrBlt  | 81    | NA = no garage so we will use max value of age of garage    |
| 13      | GarageFinish | 81    | NA = no fireplace so "None"                                 |
| 14      | GarageQual   | 81    | NA = no fireplace so "None"                                 |
| 15      | GarageCond   | 81    | NA = no garage so "None"                                    |
| 16      | PoolQC       | 1453  | NA = no pool so "None"                                      |
| 17      | Fence        | 1179  | NA = no fence so "None"                                     |
| 18      | MiscFeature  | 1406  | NA = no miscfeature so "None"                               |


```python
train[n[0]][train[n[0]].isna()] = 0
train[n[1]][train[n[1]].isna()] = "None"
train[n[2]][train[n[2]].isna()] = "None"
train[n[3]][train[n[3]].isna()] = 0
train[n[4]][train[n[4]].isna()] = "None"
train[n[5]][train[n[5]].isna()] = "None"
train[n[6]][train[n[6]].isna()] = "None"
train[n[7]][train[n[7]].isna()] = "None"
train[n[8]][train[n[8]].isna()] = "None"
train = train.dropna(subset = [n[9]])
train[n[10]][train[n[10]].isna()] = "None"
train[n[11]][train[n[11]].isna()] = "None"
train[n[12]][train[n[12]].isna()] = 2012
train[n[13]][train[n[13]].isna()] = "None"
train[n[14]][train[n[14]].isna()] = "None"
train[n[15]][train[n[15]].isna()] = "None"
train[n[16]][train[n[16]].isna()] = "None"
train[n[17]][train[n[17]].isna()] = "None"
train[n[18]][train[n[18]].isna()] = "None"
```


```python
# testing again
for e in train.iloc[:, 1:-1].columns:
    if train[e].isna().sum() > 0:
        print(e, "-->", train[e].isna().sum(), "=", format(((train[e].isna().sum() / train.shape[0]) * 100), ".0f"), "%")
```

As can be seen above, no NAs remain. Now, we will try and treat the zeros in our dataset (if necessary).


```python
print("""No. of Zeros
============""")
for e in train.columns:
    if len(train[train[e] == 0]) > 0:
        print(e, "-->", len(train[train[e] == 0]), "=", format(((len(train[train[e] == 0]) / train.shape[0]) * 100), ".0f"), "%")
```

    No. of Zeros
    ============
    LotFrontage --> 259 = 18 %
    MasVnrArea --> 868 = 59 %
    BsmtFinSF1 --> 466 = 32 %
    BsmtFinSF2 --> 1292 = 89 %
    BsmtUnfSF --> 118 = 8 %
    TotalBsmtSF --> 37 = 3 %
    2ndFlrSF --> 829 = 57 %
    LowQualFinSF --> 1433 = 98 %
    BsmtFullBath --> 855 = 59 %
    BsmtHalfBath --> 1377 = 94 %
    FullBath --> 9 = 1 %
    HalfBath --> 913 = 63 %
    BedroomAbvGr --> 6 = 0 %
    KitchenAbvGr --> 1 = 0 %
    Fireplaces --> 689 = 47 %
    GarageCars --> 81 = 6 %
    GarageArea --> 81 = 6 %
    WoodDeckSF --> 761 = 52 %
    OpenPorchSF --> 655 = 45 %
    EnclosedPorch --> 1251 = 86 %
    3SsnPorch --> 1435 = 98 %
    ScreenPorch --> 1343 = 92 %
    PoolArea --> 1452 = 100 %
    MiscVal --> 1407 = 96 %
    

Looking at the description of these features, we can safely say that the value 0 is valid in each of them so we will not treat any of these features.

We will now treat the Null values in the testing dataset as well.


```python
m = n.copy()
m
```




    ['LotFrontage',
     'Alley',
     'MasVnrType',
     'MasVnrArea',
     'BsmtQual',
     'BsmtCond',
     'BsmtExposure',
     'BsmtFinType1',
     'BsmtFinType2',
     'Electrical',
     'FireplaceQu',
     'GarageType',
     'GarageYrBlt',
     'GarageFinish',
     'GarageQual',
     'GarageCond',
     'PoolQC',
     'Fence',
     'MiscFeature']




```python
n = []
print("""No. of Nulls
============""")
for e in test.iloc[:, 1:-1].columns:
    if test[e].isna().sum() > 0:
        n.append(e)
        print(e, "-->", test[e].isna().sum(), "=", format(((test[e].isna().sum() / test.shape[0]) * 100), ".0f"), "%")
        
print("\nTotal number of columns having Null values =", len(n))
```

    No. of Nulls
    ============
    MSZoning --> 4 = 0 %
    LotFrontage --> 227 = 16 %
    Alley --> 1352 = 93 %
    Utilities --> 2 = 0 %
    Exterior1st --> 1 = 0 %
    Exterior2nd --> 1 = 0 %
    MasVnrType --> 16 = 1 %
    MasVnrArea --> 15 = 1 %
    BsmtQual --> 44 = 3 %
    BsmtCond --> 45 = 3 %
    BsmtExposure --> 44 = 3 %
    BsmtFinType1 --> 42 = 3 %
    BsmtFinSF1 --> 1 = 0 %
    BsmtFinType2 --> 42 = 3 %
    BsmtFinSF2 --> 1 = 0 %
    BsmtUnfSF --> 1 = 0 %
    TotalBsmtSF --> 1 = 0 %
    BsmtFullBath --> 2 = 0 %
    BsmtHalfBath --> 2 = 0 %
    KitchenQual --> 1 = 0 %
    Functional --> 2 = 0 %
    FireplaceQu --> 730 = 50 %
    GarageType --> 76 = 5 %
    GarageYrBlt --> 78 = 5 %
    GarageFinish --> 78 = 5 %
    GarageCars --> 1 = 0 %
    GarageArea --> 1 = 0 %
    GarageQual --> 78 = 5 %
    GarageCond --> 78 = 5 %
    PoolQC --> 1456 = 100 %
    Fence --> 1169 = 80 %
    MiscFeature --> 1408 = 97 %
    SaleType --> 1 = 0 %
    
    Total number of columns having Null values = 33
    

As we can see more features in the testing dataset have missing values than those in the training dataset. We will first fix the common features, that have null values, between the train and test sets. After that, we will fix the remaining variables while also ensuring that the unique values in each categorical feature in the train and test datasets are the same.


```python
test[m[0]][test[m[0]].isna()] = 0
test[m[1]][test[m[1]].isna()] = "None"
test[m[2]][test[m[2]].isna()] = "None"
test[m[3]][test[m[3]].isna()] = 0
test[m[4]][test[m[4]].isna()] = "None"
test[m[5]][test[m[5]].isna()] = "None"
test[m[6]][test[m[6]].isna()] = "None"
test[m[7]][test[m[7]].isna()] = "None"
test[m[8]][test[m[8]].isna()] = "None"
test = test.dropna(subset = [m[9]])
test[m[10]][test[m[10]].isna()] = "None"
test[m[11]][test[m[11]].isna()] = "None"
test[m[12]][test[m[12]].isna()] = 2012
test[m[13]][test[m[13]].isna()] = "None"
test[m[14]][test[m[14]].isna()] = "None"
test[m[15]][test[m[15]].isna()] = "None"
test[m[16]][test[m[16]].isna()] = "None"
test[m[17]][test[m[17]].isna()] = "None"
test[m[18]][test[m[18]].isna()] = "None"
```


```python
# testing again
n = []
print("""No. of Nulls
============""")
for e in test.iloc[:, 1:-1].columns:
    if test[e].isna().sum() > 0:
        n.append(e)
        print(e, "-->", test[e].isna().sum(), "=", format(((test[e].isna().sum() / test.shape[0]) * 100), ".0f"), "%")
        
print("\nTotal number of columns having Null values =", len(n))
```

    No. of Nulls
    ============
    MSZoning --> 4 = 0 %
    Utilities --> 2 = 0 %
    Exterior1st --> 1 = 0 %
    Exterior2nd --> 1 = 0 %
    BsmtFinSF1 --> 1 = 0 %
    BsmtFinSF2 --> 1 = 0 %
    BsmtUnfSF --> 1 = 0 %
    TotalBsmtSF --> 1 = 0 %
    BsmtFullBath --> 2 = 0 %
    BsmtHalfBath --> 2 = 0 %
    KitchenQual --> 1 = 0 %
    Functional --> 2 = 0 %
    GarageCars --> 1 = 0 %
    GarageArea --> 1 = 0 %
    SaleType --> 1 = 0 %
    
    Total number of columns having Null values = 15
    

As there are barely any records, we will drop them all having above features as Null values.


```python
test = test.dropna(subset = n)
```

Before moving forward, we will check if the unique values in each categorical variable are the same


```python
for e in cols_cat:
    if not (set(test[e].unique()).issubset(set(train[e].unique()))):
        print(e, "is not same")
        print("Training values = ", set(train[e].unique()))
        print("Testing values  = ", set(test[e].unique()))
        print("Difference      = ", set(test[e].unique()) - set(train[e].unique()))
```


    ---------------------------------------------------------------------------

    KeyError                                  Traceback (most recent call last)

    C:\ProgramData\Anaconda3\lib\site-packages\pandas\core\indexes\base.py in get_loc(self, key, method, tolerance)
       3077             try:
    -> 3078                 return self._engine.get_loc(key)
       3079             except KeyError:
    

    pandas\_libs\index.pyx in pandas._libs.index.IndexEngine.get_loc()
    

    pandas\_libs\index.pyx in pandas._libs.index.IndexEngine.get_loc()
    

    pandas\_libs\hashtable_class_helper.pxi in pandas._libs.hashtable.PyObjectHashTable.get_item()
    

    pandas\_libs\hashtable_class_helper.pxi in pandas._libs.hashtable.PyObjectHashTable.get_item()
    

    KeyError: 'MSSubClass'

    
    During handling of the above exception, another exception occurred:
    

    KeyError                                  Traceback (most recent call last)

    <ipython-input-1209-e0c466bb19ce> in <module>
          1 for e in cols_cat:
    ----> 2     if not (set(test[e].unique()).issubset(set(train[e].unique()))):
          3         print(e, "is not same")
          4         print("Training values = ", set(train[e].unique()))
          5         print("Testing values  = ", set(test[e].unique()))
    

    C:\ProgramData\Anaconda3\lib\site-packages\pandas\core\frame.py in __getitem__(self, key)
       2686             return self._getitem_multilevel(key)
       2687         else:
    -> 2688             return self._getitem_column(key)
       2689 
       2690     def _getitem_column(self, key):
    

    C:\ProgramData\Anaconda3\lib\site-packages\pandas\core\frame.py in _getitem_column(self, key)
       2693         # get column
       2694         if self.columns.is_unique:
    -> 2695             return self._get_item_cache(key)
       2696 
       2697         # duplicate columns & possible reduce dimensionality
    

    C:\ProgramData\Anaconda3\lib\site-packages\pandas\core\generic.py in _get_item_cache(self, item)
       2487         res = cache.get(item)
       2488         if res is None:
    -> 2489             values = self._data.get(item)
       2490             res = self._box_item_values(item, values)
       2491             cache[item] = res
    

    C:\ProgramData\Anaconda3\lib\site-packages\pandas\core\internals.py in get(self, item, fastpath)
       4113 
       4114             if not isna(item):
    -> 4115                 loc = self.items.get_loc(item)
       4116             else:
       4117                 indexer = np.arange(len(self.items))[isna(self.items)]
    

    C:\ProgramData\Anaconda3\lib\site-packages\pandas\core\indexes\base.py in get_loc(self, key, method, tolerance)
       3078                 return self._engine.get_loc(key)
       3079             except KeyError:
    -> 3080                 return self._engine.get_loc(self._maybe_cast_indexer(key))
       3081 
       3082         indexer = self.get_indexer([key], method=method, tolerance=tolerance)
    

    pandas\_libs\index.pyx in pandas._libs.index.IndexEngine.get_loc()
    

    pandas\_libs\index.pyx in pandas._libs.index.IndexEngine.get_loc()
    

    pandas\_libs\hashtable_class_helper.pxi in pandas._libs.hashtable.PyObjectHashTable.get_item()
    

    pandas\_libs\hashtable_class_helper.pxi in pandas._libs.hashtable.PyObjectHashTable.get_item()
    

    KeyError: 'MSSubClass'


As seen above, we have one or more records in the test dataset with a level not in the training set. This is unacceptable and so we will drop those records.


```python
test = test.drop(test[test["MSSubClass"] == 150].index, axis=0)
test.shape
```




    (1446, 80)



Now that we have cleaned our data (i.e. got rid of Nulls), we will convert all features into their respective datatypes.


```python
print("For training dataset\n====================")
for e in cols_num:
    print(e, "\t", train[e].dtype)

print("\nFor testing dataset\n===================")
for e in cols_num:
    print(e, "\t", test[e].dtype)
```

    For training dataset
    ====================
    LotFrontage 	 float64
    LotArea 	 int64
    MasVnrArea 	 float64
    BsmtFinSF1 	 int64
    BsmtFinSF2 	 int64
    BsmtUnfSF 	 int64
    TotalBsmtSF 	 int64
    1stFlrSF 	 int64
    2ndFlrSF 	 int64
    LowQualFinSF 	 int64
    GrLivArea 	 int64
    BsmtFullBath 	 int64
    BsmtHalfBath 	 int64
    FullBath 	 int64
    HalfBath 	 int64
    BedroomAbvGr 	 int64
    KitchenAbvGr 	 int64
    TotRmsAbvGrd 	 int64
    Fireplaces 	 int64
    GarageCars 	 int64
    GarageArea 	 int64
    WoodDeckSF 	 int64
    OpenPorchSF 	 int64
    EnclosedPorch 	 int64
    3SsnPorch 	 int64
    ScreenPorch 	 int64
    PoolArea 	 int64
    MiscVal 	 int64
    
    For testing dataset
    ===================
    LotFrontage 	 float64
    LotArea 	 int64
    MasVnrArea 	 float64
    BsmtFinSF1 	 float64
    BsmtFinSF2 	 float64
    BsmtUnfSF 	 float64
    TotalBsmtSF 	 float64
    1stFlrSF 	 int64
    2ndFlrSF 	 int64
    LowQualFinSF 	 int64
    GrLivArea 	 int64
    BsmtFullBath 	 float64
    BsmtHalfBath 	 float64
    FullBath 	 int64
    HalfBath 	 int64
    BedroomAbvGr 	 int64
    KitchenAbvGr 	 int64
    TotRmsAbvGrd 	 int64
    Fireplaces 	 int64
    GarageCars 	 float64
    GarageArea 	 float64
    WoodDeckSF 	 int64
    OpenPorchSF 	 int64
    EnclosedPorch 	 int64
    3SsnPorch 	 int64
    ScreenPorch 	 int64
    PoolArea 	 int64
    MiscVal 	 int64
    

As can be seen, all the numeric variables are in either integer or float format. Let's now check for caategorical variables.


```python
for e in cols_cat:
    train[e] = train[e].astype('category')
    test[e] = test[e].astype('category')

print("For training dataset\n====================")
for e in cols_cat:
    print(e, "\t", train[e].dtype)

print("\nFor testing dataset\n===================")
for e in cols_cat:
    print(e, "\t", test[e].dtype)
```

    For training dataset
    ====================
    MSSubClass 	 category
    MSZoning 	 category
    Street 	 category
    Alley 	 category
    LotShape 	 category
    LandContour 	 category
    Utilities 	 category
    LotConfig 	 category
    LandSlope 	 category
    Neighborhood 	 category
    Condition1 	 category
    Condition2 	 category
    BldgType 	 category
    HouseStyle 	 category
    OverallQual 	 category
    OverallCond 	 category
    RoofStyle 	 category
    RoofMatl 	 category
    Exterior1st 	 category
    Exterior2nd 	 category
    MasVnrType 	 category
    ExterQual 	 category
    ExterCond 	 category
    Foundation 	 category
    BsmtQual 	 category
    BsmtCond 	 category
    BsmtExposure 	 category
    BsmtFinType1 	 category
    BsmtFinType2 	 category
    Heating 	 category
    HeatingQC 	 category
    CentralAir 	 category
    Electrical 	 category
    KitchenQual 	 category
    Functional 	 category
    FireplaceQu 	 category
    GarageType 	 category
    GarageFinish 	 category
    GarageQual 	 category
    GarageCond 	 category
    PavedDrive 	 category
    PoolQC 	 category
    Fence 	 category
    MiscFeature 	 category
    SaleType 	 category
    SaleCondition 	 category
    
    For testing dataset
    ===================
    MSSubClass 	 category
    MSZoning 	 category
    Street 	 category
    Alley 	 category
    LotShape 	 category
    LandContour 	 category
    Utilities 	 category
    LotConfig 	 category
    LandSlope 	 category
    Neighborhood 	 category
    Condition1 	 category
    Condition2 	 category
    BldgType 	 category
    HouseStyle 	 category
    OverallQual 	 category
    OverallCond 	 category
    RoofStyle 	 category
    RoofMatl 	 category
    Exterior1st 	 category
    Exterior2nd 	 category
    MasVnrType 	 category
    ExterQual 	 category
    ExterCond 	 category
    Foundation 	 category
    BsmtQual 	 category
    BsmtCond 	 category
    BsmtExposure 	 category
    BsmtFinType1 	 category
    BsmtFinType2 	 category
    Heating 	 category
    HeatingQC 	 category
    CentralAir 	 category
    Electrical 	 category
    KitchenQual 	 category
    Functional 	 category
    FireplaceQu 	 category
    GarageType 	 category
    GarageFinish 	 category
    GarageQual 	 category
    GarageCond 	 category
    PavedDrive 	 category
    PoolQC 	 category
    Fence 	 category
    MiscFeature 	 category
    SaleType 	 category
    SaleCondition 	 category
    

For the datetime variables, which we need to be in numeric form.


```python
print("For training dataset\n====================")
for e in datetimes:
    print(e, "\t", train[e].dtype)

print("\nFor testing dataset\n===================")
for e in datetimes:
    print(e, "\t", test[e].dtype)
```

    For training dataset
    ====================
    YearBuilt 	 int64
    YearRemodAdd 	 int64
    GarageYrBlt 	 float64
    MoSold 	 int64
    YrSold 	 int64
    
    For testing dataset
    ===================
    YearBuilt 	 int64
    YearRemodAdd 	 int64
    GarageYrBlt 	 float64
    MoSold 	 int64
    YrSold 	 int64
    

### 2. Feature Selection and Feature Engineering
#### 2.1 Datetime Variables
Remember our datetime variables? 5 variables having datetime information - Years that the house was built in, the house was remodelled in, the garage was built in and the house was (or will be) sold in, respectively. The fourth is the month of sale. Now we will do the following - 
> - Create three new variables out of the four variables having years - age of the house, garage and years since remodelling - the parameters that matter to buyers and, hence, affect cost.  
>> As it is obvious, this will yield a few rows having Age of Garage as negative. These are records belonging to properties having no garage. To deal with them, we will equate them to the maximum value of Age_Garage based on the general perception that houses that have older garages have lower value which is similar to the haouses that have no garages.
> - From the month variable we will create a new variable named season (summer, winter, etc.) so as to reduce the number of dummies. We will try this post base model creation.


```python
datetimes
```




    ['YearBuilt', 'YearRemodAdd', 'GarageYrBlt', 'MoSold', 'YrSold']




```python
train_og = train.copy()
```


```python
train["Age_House"] = train['YrSold'] - train['YearBuilt']
train["Age_Remod"] = train['YrSold'] - train['YearRemodAdd']
train["Age_Garage"] = train['YrSold'] - train['GarageYrBlt']
train["Age_Garage"][train["Age_Garage"] <= 0] = train.Age_Garage.max()
# train[train.Age_Garage <= 0].shape
```

For the month variable, we will first see how it is distributed.


```python
sns.distplot(train.MoSold)
```

    C:\ProgramData\Anaconda3\lib\site-packages\scipy\stats\stats.py:1713: FutureWarning: Using a non-tuple sequence for multidimensional indexing is deprecated; use `arr[tuple(seq)]` instead of `arr[seq]`. In the future this will be interpreted as an array index, `arr[np.array(seq)]`, which will result either in an error or a different result.
      return np.add.reduce(sorted[indexer] * weights, axis=axis) / sumval
    




    <matplotlib.axes._subplots.AxesSubplot at 0x2d9c3579860>




![png](output_52_2.png)


As can be seen above, there is a peak in the middle of the year which is mostly in, or at the start of, summer when house sales are usually higher. And there's a uniform trend towards the end and start of the season (obviously, not many people are moving in or out in the holiday season or around that). Hence we can safely say that reducing this variable into seasons will be better to understand the data more effectively.


```python
def seasons(x):
    if x in [12, 1, 2]:
        return("Winter")
    elif x in [3, 4, 5]:
        return("Spring")
    elif x in [6, 7, 8]:
        return("Summer")
    elif x in [9, 10, 11]:
        return("Fall")
train["SznSold"] = train["MoSold"].apply(seasons)
```

Dropping the variables now.


```python
train = train.drop(datetimes, axis = 1)
train.shape
```




    (1459, 80)



And converting the season variable to category.


```python
train.SznSold = train.SznSold.astype('category')
train.SznSold.dtype
```




    CategoricalDtype(categories=['Fall', 'Spring', 'Summer', 'Winter'], ordered=False)



Doing the same for testing data set.


```python
test_og = test.copy()
test["Age_House"] = test['YrSold'] - test['YearBuilt']
test["Age_Remod"] = test['YrSold'] - test['YearRemodAdd']
test["Age_Garage"] = test['YrSold'] - test['GarageYrBlt']
test["Age_Garage"][test["Age_Garage"] <= 0] = test.Age_Garage.max()
test["SznSold"] = test["MoSold"].apply(seasons)
test.SznSold = test.SznSold.astype('category')
test = test.drop(datetimes, axis = 1)
test.shape
```




    (1446, 79)




```python

```


```python


```

#### 2.2 Categorical Variables
When it comes to categorical variables, there are some basic challenges we need to overcome before applying a machine learning model on them. Some of them that we will look to address in the two steps below- 
> 1. Feature Elimination - We will have to use ANOVA in this case as the target variable is continuous. We will use this feature selection technique to eliminate unimportant features having a high skewness towards one category (over 90 % of the distribution is occupied by a single variable). This is based on the general perception that variables having little variation usually contribute little to the target prediction (which again is not always the case, hence ANOVA).
> 2. Feature Cardinality - When there are too many categories (we will take that limit as 5 here) in a feature or if the distribution is skewed towards one or two categories, we will have to find ways to minimize the cardinality of those variables by combining certain categories which are rare based on either frequency or domain information. This is important because too many features usually lead to a less than desirable model.

#### 2.2.1 Feature Elimination
Let's first extract features that have a category occupying over 90% of the distribution.


```python
cols_cat_90 = []
for e in train.select_dtypes("category"):
    if train[e].value_counts(normalize = True).max() >= 0.9:
        cols_cat_90.append(e)
        
print("Columns with category occupying over 90% of the distribution")
print("============================================================")
print(cols_cat_90)
print("\nNo. of columns =", len(cols_cat_90))
```

    Columns with category occupying over 90% of the distribution
    ============================================================
    ['Street', 'Alley', 'Utilities', 'LandSlope', 'Condition2', 'RoofMatl', 'Heating', 'CentralAir', 'Electrical', 'Functional', 'GarageCond', 'PavedDrive', 'PoolQC', 'MiscFeature']
    
    No. of columns = 14
    

Now, let's take a look at their distribution.


```python
plt.rcParams['figure.figsize'] = [16, 5]
for e in cols_cat_90:
    plt.figure()
    sns.countplot(train[e])
```


![png](output_66_0.png)



![png](output_66_1.png)



![png](output_66_2.png)



![png](output_66_3.png)



![png](output_66_4.png)



![png](output_66_5.png)



![png](output_66_6.png)



![png](output_66_7.png)



![png](output_66_8.png)



![png](output_66_9.png)



![png](output_66_10.png)



![png](output_66_11.png)



![png](output_66_12.png)



![png](output_66_13.png)


As can be seen, these variables are highly skewed. We will now use ANOVA to see if these need to stay. If they are insignificant, we will eliminate them. If not, we will treat them in the next step.


```python
from sklearn.feature_selection import f_classif
X = train.loc[:, cols_cat_90]
X = pd.get_dummies(X, drop_first = False)
y = train.SalePrice
anova = f_classif(X, y)
percent = []
for e in X.columns:
    percent.append(round((X[e].sum() / len(X) * 100)))
result = pd.DataFrame({"Features": X.columns,
              "Percent" : percent,
              "F-values": anova[0],
              "p-values": np.round(anova[1], 3)})
result
```

    C:\ProgramData\Anaconda3\lib\site-packages\sklearn\feature_selection\univariate_selection.py:115: RuntimeWarning: divide by zero encountered in true_divide
      f = msb / msw
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Features</th>
      <th>Percent</th>
      <th>F-values</th>
      <th>p-values</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Street_Grvl</td>
      <td>0.0</td>
      <td>1.868361</td>
      <td>0.000</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Street_Pave</td>
      <td>100.0</td>
      <td>1.868398</td>
      <td>0.000</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Alley_Grvl</td>
      <td>3.0</td>
      <td>0.712832</td>
      <td>1.000</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Alley_None</td>
      <td>94.0</td>
      <td>0.797760</td>
      <td>0.999</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Alley_Pave</td>
      <td>3.0</td>
      <td>1.081563</td>
      <td>0.145</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Utilities_AllPub</td>
      <td>100.0</td>
      <td>0.239356</td>
      <td>1.000</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Utilities_NoSeWa</td>
      <td>0.0</td>
      <td>0.239494</td>
      <td>1.000</td>
    </tr>
    <tr>
      <th>7</th>
      <td>LandSlope_Gtl</td>
      <td>95.0</td>
      <td>1.195060</td>
      <td>0.008</td>
    </tr>
    <tr>
      <th>8</th>
      <td>LandSlope_Mod</td>
      <td>4.0</td>
      <td>1.133349</td>
      <td>0.046</td>
    </tr>
    <tr>
      <th>9</th>
      <td>LandSlope_Sev</td>
      <td>1.0</td>
      <td>1.045696</td>
      <td>0.273</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Condition2_Artery</td>
      <td>0.0</td>
      <td>0.598736</td>
      <td>1.000</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Condition2_Feedr</td>
      <td>0.0</td>
      <td>0.618357</td>
      <td>1.000</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Condition2_Norm</td>
      <td>99.0</td>
      <td>0.934793</td>
      <td>0.817</td>
    </tr>
    <tr>
      <th>13</th>
      <td>Condition2_PosA</td>
      <td>0.0</td>
      <td>0.399707</td>
      <td>1.000</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Condition2_PosN</td>
      <td>0.0</td>
      <td>3.600658</td>
      <td>0.000</td>
    </tr>
    <tr>
      <th>15</th>
      <td>Condition2_RRAe</td>
      <td>0.0</td>
      <td>0.099309</td>
      <td>1.000</td>
    </tr>
    <tr>
      <th>16</th>
      <td>Condition2_RRAn</td>
      <td>0.0</td>
      <td>inf</td>
      <td>0.000</td>
    </tr>
    <tr>
      <th>17</th>
      <td>Condition2_RRNn</td>
      <td>0.0</td>
      <td>1.465958</td>
      <td>0.000</td>
    </tr>
    <tr>
      <th>18</th>
      <td>RoofMatl_ClyTile</td>
      <td>0.0</td>
      <td>0.108412</td>
      <td>1.000</td>
    </tr>
    <tr>
      <th>19</th>
      <td>RoofMatl_CompShg</td>
      <td>98.0</td>
      <td>0.832423</td>
      <td>0.993</td>
    </tr>
    <tr>
      <th>20</th>
      <td>RoofMatl_Membran</td>
      <td>0.0</td>
      <td>1.200769</td>
      <td>0.007</td>
    </tr>
    <tr>
      <th>21</th>
      <td>RoofMatl_Metal</td>
      <td>0.0</td>
      <td>0.132686</td>
      <td>1.000</td>
    </tr>
    <tr>
      <th>22</th>
      <td>RoofMatl_Roll</td>
      <td>0.0</td>
      <td>0.299574</td>
      <td>1.000</td>
    </tr>
    <tr>
      <th>23</th>
      <td>RoofMatl_Tar&amp;Grv</td>
      <td>1.0</td>
      <td>0.595784</td>
      <td>1.000</td>
    </tr>
    <tr>
      <th>24</th>
      <td>RoofMatl_WdShake</td>
      <td>0.0</td>
      <td>0.637487</td>
      <td>1.000</td>
    </tr>
    <tr>
      <th>25</th>
      <td>RoofMatl_WdShngl</td>
      <td>0.0</td>
      <td>1.770618</td>
      <td>0.000</td>
    </tr>
    <tr>
      <th>26</th>
      <td>Heating_Floor</td>
      <td>0.0</td>
      <td>inf</td>
      <td>0.000</td>
    </tr>
    <tr>
      <th>27</th>
      <td>Heating_GasA</td>
      <td>98.0</td>
      <td>0.978162</td>
      <td>0.616</td>
    </tr>
    <tr>
      <th>28</th>
      <td>Heating_GasW</td>
      <td>1.0</td>
      <td>0.602775</td>
      <td>1.000</td>
    </tr>
    <tr>
      <th>29</th>
      <td>Heating_Grav</td>
      <td>0.0</td>
      <td>2.040113</td>
      <td>0.000</td>
    </tr>
    <tr>
      <th>30</th>
      <td>Heating_OthW</td>
      <td>0.0</td>
      <td>0.398608</td>
      <td>1.000</td>
    </tr>
    <tr>
      <th>31</th>
      <td>Heating_Wall</td>
      <td>0.0</td>
      <td>2.394944</td>
      <td>0.000</td>
    </tr>
    <tr>
      <th>32</th>
      <td>CentralAir_N</td>
      <td>7.0</td>
      <td>1.582220</td>
      <td>0.000</td>
    </tr>
    <tr>
      <th>33</th>
      <td>CentralAir_Y</td>
      <td>93.0</td>
      <td>1.582218</td>
      <td>0.000</td>
    </tr>
    <tr>
      <th>34</th>
      <td>Electrical_FuseA</td>
      <td>6.0</td>
      <td>1.071396</td>
      <td>0.176</td>
    </tr>
    <tr>
      <th>35</th>
      <td>Electrical_FuseF</td>
      <td>2.0</td>
      <td>0.838676</td>
      <td>0.991</td>
    </tr>
    <tr>
      <th>36</th>
      <td>Electrical_FuseP</td>
      <td>0.0</td>
      <td>1.252015</td>
      <td>0.001</td>
    </tr>
    <tr>
      <th>37</th>
      <td>Electrical_Mix</td>
      <td>0.0</td>
      <td>1.200769</td>
      <td>0.007</td>
    </tr>
    <tr>
      <th>38</th>
      <td>Electrical_SBrkr</td>
      <td>91.0</td>
      <td>1.186508</td>
      <td>0.011</td>
    </tr>
    <tr>
      <th>39</th>
      <td>Functional_Maj1</td>
      <td>1.0</td>
      <td>0.977175</td>
      <td>0.621</td>
    </tr>
    <tr>
      <th>40</th>
      <td>Functional_Maj2</td>
      <td>0.0</td>
      <td>0.736735</td>
      <td>1.000</td>
    </tr>
    <tr>
      <th>41</th>
      <td>Functional_Min1</td>
      <td>2.0</td>
      <td>0.516689</td>
      <td>1.000</td>
    </tr>
    <tr>
      <th>42</th>
      <td>Functional_Min2</td>
      <td>2.0</td>
      <td>0.723812</td>
      <td>1.000</td>
    </tr>
    <tr>
      <th>43</th>
      <td>Functional_Mod</td>
      <td>1.0</td>
      <td>1.086714</td>
      <td>0.131</td>
    </tr>
    <tr>
      <th>44</th>
      <td>Functional_Sev</td>
      <td>0.0</td>
      <td>0.170832</td>
      <td>1.000</td>
    </tr>
    <tr>
      <th>45</th>
      <td>Functional_Typ</td>
      <td>93.0</td>
      <td>0.800925</td>
      <td>0.999</td>
    </tr>
    <tr>
      <th>46</th>
      <td>GarageCond_Ex</td>
      <td>0.0</td>
      <td>0.314343</td>
      <td>1.000</td>
    </tr>
    <tr>
      <th>47</th>
      <td>GarageCond_Fa</td>
      <td>2.0</td>
      <td>0.917284</td>
      <td>0.876</td>
    </tr>
    <tr>
      <th>48</th>
      <td>GarageCond_Gd</td>
      <td>1.0</td>
      <td>0.694727</td>
      <td>1.000</td>
    </tr>
    <tr>
      <th>49</th>
      <td>GarageCond_None</td>
      <td>6.0</td>
      <td>1.240927</td>
      <td>0.002</td>
    </tr>
    <tr>
      <th>50</th>
      <td>GarageCond_Po</td>
      <td>0.0</td>
      <td>0.824164</td>
      <td>0.995</td>
    </tr>
    <tr>
      <th>51</th>
      <td>GarageCond_TA</td>
      <td>91.0</td>
      <td>1.273116</td>
      <td>0.001</td>
    </tr>
    <tr>
      <th>52</th>
      <td>PavedDrive_N</td>
      <td>6.0</td>
      <td>1.133627</td>
      <td>0.045</td>
    </tr>
    <tr>
      <th>53</th>
      <td>PavedDrive_P</td>
      <td>2.0</td>
      <td>0.616719</td>
      <td>1.000</td>
    </tr>
    <tr>
      <th>54</th>
      <td>PavedDrive_Y</td>
      <td>92.0</td>
      <td>1.020908</td>
      <td>0.390</td>
    </tr>
    <tr>
      <th>55</th>
      <td>PoolQC_Ex</td>
      <td>0.0</td>
      <td>1.599377</td>
      <td>0.000</td>
    </tr>
    <tr>
      <th>56</th>
      <td>PoolQC_Fa</td>
      <td>0.0</td>
      <td>0.184038</td>
      <td>1.000</td>
    </tr>
    <tr>
      <th>57</th>
      <td>PoolQC_Gd</td>
      <td>0.0</td>
      <td>0.894573</td>
      <td>0.932</td>
    </tr>
    <tr>
      <th>58</th>
      <td>PoolQC_None</td>
      <td>100.0</td>
      <td>0.742946</td>
      <td>1.000</td>
    </tr>
    <tr>
      <th>59</th>
      <td>MiscFeature_Gar2</td>
      <td>0.0</td>
      <td>1.399249</td>
      <td>0.000</td>
    </tr>
    <tr>
      <th>60</th>
      <td>MiscFeature_None</td>
      <td>96.0</td>
      <td>0.908992</td>
      <td>0.899</td>
    </tr>
    <tr>
      <th>61</th>
      <td>MiscFeature_Othr</td>
      <td>0.0</td>
      <td>0.598736</td>
      <td>1.000</td>
    </tr>
    <tr>
      <th>62</th>
      <td>MiscFeature_Shed</td>
      <td>3.0</td>
      <td>0.947668</td>
      <td>0.764</td>
    </tr>
    <tr>
      <th>63</th>
      <td>MiscFeature_TenC</td>
      <td>0.0</td>
      <td>0.170832</td>
      <td>1.000</td>
    </tr>
  </tbody>
</table>
</div>



For deciding which variables to drop (or keep), we will use the following condition
> For a given variable if **either all the categories or at least the dominant category (over 90 %) is insignificant (p > 0.05)** we will then **DROP** those variables. 

From the above table the **Variables to keep** are -  
[Street, LandSlope, CentralAir, Electrical, GarageCond]

We will drop the rest of the variables.


```python
# updating the variables to remove
cols_cat_90 = list(set(cols_cat_90) - set(["Street", "LandSlope", "CentralAir", "Electrical", "GarageCond"]))
cols_cat_90
```




    ['PavedDrive',
     'Alley',
     'Utilities',
     'Functional',
     'RoofMatl',
     'Condition2',
     'MiscFeature',
     'PoolQC',
     'Heating']




```python
train = train.drop(cols_cat_90, axis = 1)
print(train.shape)
```

    (1459, 71)
    


```python
test = test.drop(cols_cat_90, axis = 1)
print(test.shape)
```

    (1446, 70)
    

#### 2.2.2 Feature Cardinality
We will now see how each of the categorical variable is distributed both using plots and numeric counts. We will re-establish the categories if one of the following is true - 
> 1. The distribution is heavily skewed towards one or two categories only i.e. about 80-90 %. 
> 2. If there are categories that are very rare (by thumb rule under 5% of the distribution) or if there are too many categories (> 10) and they cannot be combined using domain information we will just combine them into a new category "Others".


```python
for e in train.select_dtypes("category"):
    if train[e].nunique() > 2:
        print(train[e].value_counts(normalize = True, sort = False) * 100)
        print()
```

    20     36.737491
    30      4.729267
    40      0.274160
    45      0.822481
    50      9.869774
    60     20.493489
    70      4.112406
    75      1.096642
    80      3.906785
    85      1.370802
    90      3.564085
    120     5.962988
    160     4.318026
    180     0.685401
    190     2.056203
    Name: MSSubClass, dtype: float64
    
    C (all)     0.685401
    FV          4.455106
    RH          1.096642
    RL         78.821110
    RM         14.941741
    Name: MSZoning, dtype: float64
    
    IR1    33.173406
    IR2     2.810144
    IR3     0.685401
    Reg    63.331049
    Name: LotShape, dtype: float64
    
    Bnk     4.318026
    HLS     3.427005
    Low     2.467443
    Lvl    89.787526
    Name: LandContour, dtype: float64
    
    Corner     18.026045
    CulDSac     6.442769
    FR2         3.221385
    FR3         0.274160
    Inside     72.035641
    Name: LotConfig, dtype: float64
    
    Gtl    94.653873
    Mod     4.455106
    Sev     0.891021
    Name: LandSlope, dtype: float64
    
    Blmngtn     1.165182
    Blueste     0.137080
    BrDale      1.096642
    BrkSide     3.975326
    ClearCr     1.919123
    CollgCr    10.281014
    Crawfor     3.495545
    Edwards     6.854010
    Gilbert     5.414668
    IDOTRR      2.535984
    MeadowV     1.165182
    Mitchel     3.358465
    NAmes      15.421522
    NPkVill     0.616861
    NWAmes      5.003427
    NoRidge     2.810144
    NridgHt     5.277587
    OldTown     7.745031
    SWISU       1.713502
    Sawyer      5.071967
    SawyerW     4.043866
    Somerst     5.894448
    StoneBr     1.713502
    Timber      2.535984
    Veenker     0.753941
    Name: Neighborhood, dtype: float64
    
    Artery     3.289925
    Feedr      5.551748
    Norm      86.291981
    PosA       0.548321
    PosN       1.302262
    RRAe       0.753941
    RRAn       1.782042
    RRNe       0.137080
    RRNn       0.342700
    Name: Condition1, dtype: float64
    
    1Fam      83.550377
    2fmCon     2.124743
    Duplex     3.564085
    Twnhs      2.947224
    TwnhsE     7.813571
    Name: BldgType, dtype: float64
    
    1.5Fin    10.555175
    1.5Unf     0.959561
    1Story    49.760110
    2.5Fin     0.548321
    2.5Unf     0.753941
    2Story    30.500343
    SFoyer     2.535984
    SLvl       4.386566
    Name: HouseStyle, dtype: float64
    
    1      0.137080
    2      0.205620
    3      1.370802
    4      7.950651
    5     27.141878
    6     25.633996
    7     21.864291
    8     11.514736
    9      2.947224
    10     1.233722
    Name: OverallQual, dtype: float64
    
    1     0.068540
    2     0.342700
    3     1.713502
    4     3.906785
    5    56.202879
    6    17.272104
    7    14.050720
    8     4.934887
    9     1.507882
    Name: OverallCond, dtype: float64
    
    Flat        0.891021
    Gable      78.135709
    Gambrel     0.753941
    Hip        19.602467
    Mansard     0.479781
    Shed        0.137080
    Name: RoofStyle, dtype: float64
    
    AsbShng     1.370802
    AsphShn     0.068540
    BrkComm     0.137080
    BrkFace     3.427005
    CBlock      0.068540
    CemntBd     4.180946
    HdBoard    15.215901
    ImStucc     0.068540
    MetalSd    15.078821
    Plywood     7.402330
    Stone       0.137080
    Stucco      1.713502
    VinylSd    35.229609
    Wd Sdng    14.119260
    WdShing     1.782042
    Name: Exterior1st, dtype: float64
    
    AsbShng     1.370802
    AsphShn     0.205620
    Brk Cmn     0.479781
    BrkFace     1.713502
    CBlock      0.068540
    CmentBd     4.112406
    HdBoard    14.187800
    ImStucc     0.685401
    MetalSd    14.667581
    Other       0.068540
    Plywood     9.732694
    Stone       0.342700
    Stucco      1.782042
    VinylSd    34.475668
    Wd Sdng    13.502399
    Wd Shng     2.604524
    Name: Exterior2nd, dtype: float64
    
    BrkCmn      1.028101
    BrkFace    30.500343
    None       59.698424
    Stone       8.773132
    Name: MasVnrType, dtype: float64
    
    Ex     3.564085
    Fa     0.959561
    Gd    33.447567
    TA    62.028787
    Name: ExterQual, dtype: float64
    
    Ex     0.205620
    Fa     1.919123
    Gd    10.006854
    Po     0.068540
    TA    87.799863
    Name: ExterCond, dtype: float64
    
    BrkTil    10.006854
    CBlock    43.454421
    PConc     44.276902
    Slab       1.644962
    Stone      0.411241
    Wood       0.205620
    Name: Foundation, dtype: float64
    
    Ex       8.293352
    Fa       2.398903
    Gd      42.289239
    None     2.535984
    TA      44.482522
    Name: BsmtQual, dtype: float64
    
    Fa       3.084304
    Gd       4.455106
    None     2.535984
    Po       0.137080
    TA      89.787526
    Name: BsmtCond, dtype: float64
    
    Av      15.147361
    Gd       9.184373
    Mn       7.813571
    No      65.250171
    None     2.604524
    Name: BsmtExposure, dtype: float64
    
    ALQ     15.078821
    BLQ     10.143934
    GLQ     28.649760
    LwQ      5.071967
    None     2.535984
    Rec      9.115833
    Unf     29.403701
    Name: BsmtFinType1, dtype: float64
    
    ALQ      1.302262
    BLQ      2.261823
    GLQ      0.959561
    LwQ      3.152844
    None     2.604524
    Rec      3.701165
    Unf     86.017820
    Name: BsmtFinType2, dtype: float64
    
    Ex    50.788211
    Fa     3.358465
    Gd    16.449623
    Po     0.068540
    TA    29.335161
    Name: HeatingQC, dtype: float64
    
    FuseA     6.442769
    FuseF     1.850583
    FuseP     0.205620
    Mix       0.068540
    SBrkr    91.432488
    Name: Electrical, dtype: float64
    
    Ex     6.854010
    Fa     2.673064
    Gd    40.095956
    TA    50.376971
    Name: KitchenQual, dtype: float64
    
    Ex       1.644962
    Fa       2.261823
    Gd      26.045236
    None    47.224126
    Po       1.370802
    TA      21.453050
    Name: FireplaceQu, dtype: float64
    
    2Types      0.411241
    Attchd     59.629883
    Basment     1.302262
    BuiltIn     5.962988
    CarPort     0.616861
    Detchd     26.525017
    None        5.551748
    Name: GarageType, dtype: float64
    
    Fin     24.057574
    None     5.551748
    RFn     28.923920
    Unf     41.466758
    Name: GarageFinish, dtype: float64
    
    Ex       0.205620
    Fa       3.289925
    Gd       0.959561
    None     5.551748
    Po       0.205620
    TA      89.787526
    Name: GarageQual, dtype: float64
    
    Ex       0.137080
    Fa       2.398903
    Gd       0.616861
    None     5.551748
    Po       0.479781
    TA      90.815627
    Name: GarageCond, dtype: float64
    
    GdPrv     4.043866
    GdWo      3.701165
    MnPrv    10.760795
    MnWw      0.753941
    None     80.740233
    Name: Fence, dtype: float64
    
    COD       2.947224
    CWD       0.274160
    Con       0.137080
    ConLD     0.616861
    ConLI     0.342700
    ConLw     0.342700
    New       8.361892
    Oth       0.205620
    WD       86.771761
    Name: SaleType, dtype: float64
    
    Abnorml     6.922550
    AdjLand     0.274160
    Alloca      0.822481
    Family      1.370802
    Normal     82.042495
    Partial     8.567512
    Name: SaleCondition, dtype: float64
    
    Fall      15.832762
    Spring    30.843043
    Summer    41.740918
    Winter    11.583276
    Name: SznSold, dtype: float64
    
    


```python
plt.rcParams['figure.figsize'] = [16, 5]
plt.rcParams.update({'figure.max_open_warning': 0})
for e in train.select_dtypes("category"):
    if train[e].nunique() > 2:
        plt.figure()
        sns.countplot(train[e])
```


![png](output_75_0.png)



![png](output_75_1.png)



![png](output_75_2.png)



![png](output_75_3.png)



![png](output_75_4.png)



![png](output_75_5.png)



![png](output_75_6.png)



![png](output_75_7.png)



![png](output_75_8.png)



![png](output_75_9.png)



![png](output_75_10.png)



![png](output_75_11.png)



![png](output_75_12.png)



![png](output_75_13.png)



![png](output_75_14.png)



![png](output_75_15.png)



![png](output_75_16.png)



![png](output_75_17.png)



![png](output_75_18.png)



![png](output_75_19.png)



![png](output_75_20.png)



![png](output_75_21.png)



![png](output_75_22.png)



![png](output_75_23.png)



![png](output_75_24.png)



![png](output_75_25.png)



![png](output_75_26.png)



![png](output_75_27.png)



![png](output_75_28.png)



![png](output_75_29.png)



![png](output_75_30.png)



![png](output_75_31.png)



![png](output_75_32.png)



![png](output_75_33.png)



![png](output_75_34.png)



![png](output_75_35.png)


Now we will re-establish some of the categories from above variables.


```python
# Conversion to str 
for e in train.select_dtypes("category"):
    train[e] = train[e].astype(str)
    
for e in test.select_dtypes("category"):
    test[e] = test[e].astype(str)
```


```python
# MSZoning
train['MSZoning'][train['MSZoning'].str.startswith('R')] = "R"

# LotShape
train['LotShape'][train['LotShape'].str.startswith('I')] = "IR"

# LandContour
train['LandContour'][train['LandContour'] != "Lvl"] = "N Lvl"

# LotConfig
train['LotConfig'][train['LotConfig'].str.startswith('F')] = "FR"

# LandSlope
train['LandSlope'][train['LandSlope'] == "Gtl"] = "Low"
train['LandSlope'][train['LandSlope'] != "Low"] = "High"

# Condition1
train['Condition1'][train['Condition1'].str.startswith("Pos")] = "Pos"
train['Condition1'][train['Condition1'].str.startswith("RR")] = "RR"

# HouseStyle
train['HouseStyle'][train['HouseStyle'] == "1Story"] = "1"
train['HouseStyle'][train['HouseStyle'].str.startswith("1.5")] = "1.5"
train['HouseStyle'][train['HouseStyle'].str.startswith("2")] = "2+"
train['HouseStyle'][train['HouseStyle'].str.startswith("S")] = "Split"

# OverallQual
def level(x):
    if x in ["1", "2", "3", "4"]:
        return "Low"
    elif x in ["5", "6", "7"]:
        return "Med"
    else:
        return "High"
train['OverallQual'] = train['OverallQual'].apply(level)

# OverallCond
def level(x):
    if x in ["1", "2", "3", "4"]:
        return "Bad"
    elif x in ["5"]:
        return "Average"
    else:
        return "Good"
train['OverallCond'] = train['OverallCond'].apply(level)

# RoofStyle
train['RoofStyle'][train['RoofStyle'].isin(['Gambrel', 'Mansard', 'Flat', 'Shed'])] = "Others"

# Exterior1st
train['Exterior1st'][train['Exterior1st'].isin(['BrkFace', 'WdShing', 'AsbShng', 'Stucco', 'BrkComm', 'AsphShn', 'Stone', 'ImStucc', 'CBlock'])] = "Others"

# Exterior2nd
train['Exterior2nd'][train['Exterior2nd'].isin(['Wd Shng', 'BrkFace', 'Stucco', 'AsbShng', 'Brk Cmn', 'ImStucc', 'AsphShn', 'Stone', 'Other', 'CBlock'])] = "Others"

# MasVnrType
train['MasVnrType'][train['MasVnrType'].str.startswith("Brk")] = "Brick"

# ExterQual, ExterCond, BsmtQual, BsmtCond, FireplaceQu, GarageQual, GarageCond 
def quality(x):
    if x in ['TA', 'Fa', 'Po']:
        return "Low"
    elif x in ['Ex', 'Gd']:
        return "High"
    else:
        return "None"

train['ExterQual'] = train['ExterQual'].apply(quality)
train['ExterCond'] = train['ExterCond'].apply(quality)
train['BsmtQual'] = train['BsmtQual'].apply(quality)
train['BsmtCond'] = train['BsmtCond'].apply(quality)
train['FireplaceQu'] = train['FireplaceQu'].apply(quality)
train['GarageQual'] = train['GarageQual'].apply(quality)
train['GarageCond'] = train['GarageCond'].apply(quality)

# Foundation
train['Foundation'][train['Foundation'].isin(['Wood', 'Slab', 'Stone'])] = "Other"

# HeatingQC, KitchenQual
def quality(x):
    if x in ['TA', 'Fa', 'Po']:
        return "Low"
    elif x in ['Gd']:
        return "Med"
    elif x in ['Ex']:
        return "High"
    else:
        return "None"
    
train['HeatingQC'] = train['HeatingQC'].apply(quality)
train['KitchenQual'] = train['KitchenQual'].apply(quality)

# Electrical
train['Electrical'][train['Electrical'] != "SBrkr"] = "Other"

# GarageType
train['GarageType'][train['GarageType'].isin(['Attchd', 'BuiltIn', 'CarPort', 'Basment', '2Types'])] = "Attchd"

# SaleType
train['SaleType'][train['SaleType'].isin(['COD', 'ConLD', 'ConLI', 'CWD', 'ConLw', 'Con', 'Oth'])] = "Other"

# SaleCondition
train['SaleCondition'][train['SaleCondition'].isin(['AdjLand', 'Alloca', 'Family'])] = "Other"
```


```python
# MSZoning
test['MSZoning'][test['MSZoning'].str.startswith('R')] = "R"

# LotShape
test['LotShape'][test['LotShape'].str.startswith('I')] = "IR"

# LandContour
test['LandContour'][test['LandContour'] != "Lvl"] = "N Lvl"

# LotConfig
test['LotConfig'][test['LotConfig'].str.startswith('F')] = "FR"

# LandSlope
test['LandSlope'][test['LandSlope'] == "Gtl"] = "Low"
test['LandSlope'][test['LandSlope'] != "Low"] = "High"

# Condition1
test['Condition1'][test['Condition1'].str.startswith("Pos")] = "Pos"
test['Condition1'][test['Condition1'].str.startswith("RR")] = "RR"

# HouseStyle
test['HouseStyle'][test['HouseStyle'] == "1Story"] = "1"
test['HouseStyle'][test['HouseStyle'].str.startswith("1.5")] = "1.5"
test['HouseStyle'][test['HouseStyle'].str.startswith("2")] = "2+"
test['HouseStyle'][test['HouseStyle'].str.startswith("S")] = "Split"

# OverallQual
test['OverallQual'] = test['OverallQual'].apply(level)

# OverallCond
test['OverallCond'] = test['OverallCond'].apply(level)

# RoofStyle
test['RoofStyle'][test['RoofStyle'].isin(['Gambrel', 'Mansard', 'Flat', 'Shed'])] = "Others"

# Exterior1st
test['Exterior1st'][test['Exterior1st'].isin(['BrkFace', 'WdShing', 'AsbShng', 'Stucco', 'BrkComm', 'AsphShn', 'Stone', 'ImStucc', 'CBlock'])] = "Others"

# Exterior2nd
test['Exterior2nd'][test['Exterior2nd'].isin(['Wd Shng', 'BrkFace', 'Stucco', 'AsbShng', 'Brk Cmn', 'ImStucc', 'AsphShn', 'Stone', 'Other', 'CBlock'])] = "Others"

# MasVnrType
test['MasVnrType'][test['MasVnrType'].str.startswith("Brk")] = "Brick"

# ExterQual, ExterCond, BsmtQual, BsmtCond, FireplaceQu, GarageQual, GarageCond 
test['ExterQual'] = test['ExterQual'].apply(quality)
test['ExterCond'] = test['ExterCond'].apply(quality)
test['BsmtQual'] = test['BsmtQual'].apply(quality)
test['BsmtCond'] = test['BsmtCond'].apply(quality)
test['FireplaceQu'] = test['FireplaceQu'].apply(quality)
test['GarageQual'] = test['GarageQual'].apply(quality)
test['GarageCond'] = test['GarageCond'].apply(quality)

# Foundation
test['Foundation'][test['Foundation'].isin(['Wood', 'Slab', 'Stone'])] = "Other"

# HeatingQC, KitchenQual
test['HeatingQC'] = test['HeatingQC'].apply(quality)
test['KitchenQual'] = test['KitchenQual'].apply(quality)

# Electrical
test['Electrical'][test['Electrical'] != "SBrkr"] = "Other"

# GarageType
test['GarageType'][test['GarageType'].isin(['Attchd', 'BuiltIn', 'CarPort', 'Basment', '2Types'])] = "Attchd"

# SaleType
test['SaleType'][test['SaleType'].isin(['COD', 'ConLD', 'ConLI', 'CWD', 'ConLw', 'Con', 'Oth'])] = "Other"

# SaleCondition
test['SaleCondition'][test['SaleCondition'].isin(['AdjLand', 'Alloca', 'Family'])] = "Other"
```

#### 2.3 Numeric Variables
For the numeric variables, we will look to do the following - 
> 1. Check for multi-collinearity. If there are two correlated variables in our dataset, we will eliminate the one having higher cumulative correlation with all the other variables.
> 2. Check the skewness of each variable. If skewness is greater than 0.75 we will have to transform the variables using a "log + 1" transformation as we need to get them closer to a normal distribution (which is ideally desirable for a linear regression algorithm, but not always possible).  

Extracting all the numeric feature names.


```python
numeric = []
for e in train.columns:
    if (train[e].dtype in ["int64", "float"]):
        numeric.append(e)
        
numeric = numeric[1:-4] + numeric[-3:]
print(numeric)
```

    ['LotFrontage', 'LotArea', 'MasVnrArea', 'BsmtFinSF1', 'BsmtFinSF2', 'BsmtUnfSF', 'TotalBsmtSF', '1stFlrSF', '2ndFlrSF', 'LowQualFinSF', 'GrLivArea', 'BsmtFullBath', 'BsmtHalfBath', 'FullBath', 'HalfBath', 'BedroomAbvGr', 'KitchenAbvGr', 'TotRmsAbvGrd', 'Fireplaces', 'GarageCars', 'GarageArea', 'WoodDeckSF', 'OpenPorchSF', 'EnclosedPorch', '3SsnPorch', 'ScreenPorch', 'PoolArea', 'MiscVal', 'Age_House', 'Age_Remod', 'Age_Garage']
    

#### 2.3.1 Multi-collinearity

Getting the correlation plot.


```python
corr_mat = train[numeric].corr()
corr_mat.style.background_gradient(cmap = "coolwarm").set_precision(2)
```




<style  type="text/css" >
    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col0 {
            background-color:  #b40426;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col1 {
            background-color:  #5e7de7;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col2 {
            background-color:  #a5c3fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col3 {
            background-color:  #bbd1f8;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col4 {
            background-color:  #6f92f3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col5 {
            background-color:  #ccd9ed;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col6 {
            background-color:  #d1dae9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col7 {
            background-color:  #c4d5f3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col8 {
            background-color:  #7da0f9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col9 {
            background-color:  #6384eb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col10 {
            background-color:  #bfd3f6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col11 {
            background-color:  #a1c0ff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col12 {
            background-color:  #5a78e4;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col13 {
            background-color:  #c0d4f5;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col14 {
            background-color:  #7699f6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col15 {
            background-color:  #8fb1fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col16 {
            background-color:  #6788ee;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col17 {
            background-color:  #afcafc;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col18 {
            background-color:  #7093f3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col19 {
            background-color:  #d2dbe8;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col20 {
            background-color:  #d2dbe8;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col21 {
            background-color:  #7093f3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col22 {
            background-color:  #8badfd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col23 {
            background-color:  #6b8df0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col24 {
            background-color:  #4e68d8;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col25 {
            background-color:  #5977e3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col26 {
            background-color:  #6788ee;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col27 {
            background-color:  #3b4cc0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col28 {
            background-color:  #a7c5fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col29 {
            background-color:  #8db0fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col30 {
            background-color:  #b9d0f9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col0 {
            background-color:  #6f92f3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col1 {
            background-color:  #b40426;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col2 {
            background-color:  #a5c3fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col3 {
            background-color:  #d6dce4;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col4 {
            background-color:  #92b4fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col5 {
            background-color:  #a9c6fd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col6 {
            background-color:  #d5dbe5;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col7 {
            background-color:  #d1dae9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col8 {
            background-color:  #7ea1fa;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col9 {
            background-color:  #5673e0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col10 {
            background-color:  #c9d7f0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col11 {
            background-color:  #c3d5f4;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col12 {
            background-color:  #7093f3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col13 {
            background-color:  #c1d4f4;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col14 {
            background-color:  #7da0f9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col15 {
            background-color:  #88abfd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col16 {
            background-color:  #5875e1;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col17 {
            background-color:  #a6c4fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col18 {
            background-color:  #b5cdfa;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col19 {
            background-color:  #cfdaea;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col20 {
            background-color:  #cedaeb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col21 {
            background-color:  #a6c4fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col22 {
            background-color:  #8fb1fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col23 {
            background-color:  #5e7de7;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col24 {
            background-color:  #4c66d6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col25 {
            background-color:  #5e7de7;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col26 {
            background-color:  #5b7ae5;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col27 {
            background-color:  #5673e0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col28 {
            background-color:  #adc9fd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col29 {
            background-color:  #9dbdff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col30 {
            background-color:  #a6c4fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col0 {
            background-color:  #7093f3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col1 {
            background-color:  #5f7fe8;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col2 {
            background-color:  #b40426;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col3 {
            background-color:  #dedcdb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col4 {
            background-color:  #5e7de7;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col5 {
            background-color:  #c3d5f4;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col6 {
            background-color:  #e7d7ce;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col7 {
            background-color:  #d9dce1;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col8 {
            background-color:  #a3c2fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col9 {
            background-color:  #4257c9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col10 {
            background-color:  #e3d9d3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col11 {
            background-color:  #b2ccfb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col12 {
            background-color:  #6b8df0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col13 {
            background-color:  #dedcdb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col14 {
            background-color:  #b2ccfb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col15 {
            background-color:  #82a6fb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col16 {
            background-color:  #516ddb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col17 {
            background-color:  #bfd3f6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col18 {
            background-color:  #aec9fc;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col19 {
            background-color:  #efcebd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col20 {
            background-color:  #eed0c0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col21 {
            background-color:  #a3c2fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col22 {
            background-color:  #9abbff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col23 {
            background-color:  #455cce;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col24 {
            background-color:  #4c66d6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col25 {
            background-color:  #6485ec;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col26 {
            background-color:  #485fd1;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col27 {
            background-color:  #4358cb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col28 {
            background-color:  #688aef;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col29 {
            background-color:  #7597f6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col30 {
            background-color:  #86a9fc;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col0 {
            background-color:  #688aef;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col1 {
            background-color:  #85a8fc;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col2 {
            background-color:  #cbd8ee;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col3 {
            background-color:  #b40426;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col4 {
            background-color:  #6384eb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col5 {
            background-color:  #3b4cc0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col6 {
            background-color:  #f7ba9f;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col7 {
            background-color:  #edd2c3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col8 {
            background-color:  #4a63d3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col9 {
            background-color:  #4257c9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col10 {
            background-color:  #bbd1f8;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col11 {
            background-color:  #f4987a;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col12 {
            background-color:  #779af7;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col13 {
            background-color:  #b2ccfb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col14 {
            background-color:  #7a9df8;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col15 {
            background-color:  #455cce;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col16 {
            background-color:  #455cce;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col17 {
            background-color:  #7b9ff9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col18 {
            background-color:  #b2ccfb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col19 {
            background-color:  #dbdcde;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col20 {
            background-color:  #e3d9d3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col21 {
            background-color:  #afcafc;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col22 {
            background-color:  #97b8ff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col23 {
            background-color:  #465ecf;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col24 {
            background-color:  #4f69d9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col25 {
            background-color:  #6485ec;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col26 {
            background-color:  #7093f3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col27 {
            background-color:  #4c66d6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col28 {
            background-color:  #779af7;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col29 {
            background-color:  #81a4fb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col30 {
            background-color:  #88abfd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col0 {
            background-color:  #4e68d8;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col1 {
            background-color:  #6282ea;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col2 {
            background-color:  #7597f6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col3 {
            background-color:  #9ebeff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col4 {
            background-color:  #b40426;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col5 {
            background-color:  #799cf8;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col6 {
            background-color:  #b2ccfb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col7 {
            background-color:  #9dbdff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col8 {
            background-color:  #5470de;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col9 {
            background-color:  #5977e3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col10 {
            background-color:  #81a4fb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col11 {
            background-color:  #c3d5f4;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col12 {
            background-color:  #779af7;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col13 {
            background-color:  #93b5fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col14 {
            background-color:  #7093f3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col15 {
            background-color:  #5f7fe8;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col16 {
            background-color:  #506bda;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col17 {
            background-color:  #6485ec;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col18 {
            background-color:  #7093f3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col19 {
            background-color:  #a7c5fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col20 {
            background-color:  #a2c1ff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col21 {
            background-color:  #88abfd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col22 {
            background-color:  #779af7;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col23 {
            background-color:  #6e90f2;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col24 {
            background-color:  #3e51c5;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col25 {
            background-color:  #6c8ff1;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col26 {
            background-color:  #506bda;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col27 {
            background-color:  #4c66d6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col28 {
            background-color:  #bad0f8;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col29 {
            background-color:  #b1cbfc;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col30 {
            background-color:  #a3c2fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col0 {
            background-color:  #82a6fb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col1 {
            background-color:  #3e51c5;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col2 {
            background-color:  #a7c5fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col3 {
            background-color:  #3b4cc0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col4 {
            background-color:  #3b4cc0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col5 {
            background-color:  #b40426;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col6 {
            background-color:  #efcfbf;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col7 {
            background-color:  #d4dbe6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col8 {
            background-color:  #7295f4;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col9 {
            background-color:  #5d7ce6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col10 {
            background-color:  #c4d5f3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col11 {
            background-color:  #3b4cc0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col12 {
            background-color:  #485fd1;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col13 {
            background-color:  #e1dad6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col14 {
            background-color:  #6e90f2;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col15 {
            background-color:  #96b7ff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col16 {
            background-color:  #6687ed;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col17 {
            background-color:  #b7cff9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col18 {
            background-color:  #7295f4;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col19 {
            background-color:  #dadce0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col20 {
            background-color:  #cedaeb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col21 {
            background-color:  #7396f5;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col22 {
            background-color:  #9bbcff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col23 {
            background-color:  #6384eb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col24 {
            background-color:  #4c66d6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col25 {
            background-color:  #4e68d8;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col26 {
            background-color:  #3b4cc0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col27 {
            background-color:  #445acc;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col28 {
            background-color:  #8db0fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col29 {
            background-color:  #7396f5;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col30 {
            background-color:  #a5c3fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col0 {
            background-color:  #9dbdff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col1 {
            background-color:  #96b7ff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col2 {
            background-color:  #e0dbd8;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col3 {
            background-color:  #f7b396;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col4 {
            background-color:  #90b2fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col5 {
            background-color:  #f2c9b4;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col6 {
            background-color:  #b40426;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col7 {
            background-color:  #e26952;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col8 {
            background-color:  #4257c9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col9 {
            background-color:  #4b64d5;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col10 {
            background-color:  #eed0c0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col11 {
            background-color:  #e0dbd8;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col12 {
            background-color:  #6282ea;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col13 {
            background-color:  #e7d7ce;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col14 {
            background-color:  #6c8ff1;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col15 {
            background-color:  #7295f4;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col16 {
            background-color:  #4961d2;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col17 {
            background-color:  #c0d4f5;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col18 {
            background-color:  #c7d7f0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col19 {
            background-color:  #f5c1a9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col20 {
            background-color:  #f7bca1;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col21 {
            background-color:  #b7cff9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col22 {
            background-color:  #bcd2f7;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col23 {
            background-color:  #4961d2;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col24 {
            background-color:  #516ddb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col25 {
            background-color:  #6b8df0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col26 {
            background-color:  #6b8df0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col27 {
            background-color:  #455cce;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col28 {
            background-color:  #5875e1;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col29 {
            background-color:  #5a78e4;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col30 {
            background-color:  #85a8fc;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col0 {
            background-color:  #9fbfff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col1 {
            background-color:  #a2c1ff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col2 {
            background-color:  #dcdddd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col3 {
            background-color:  #f5c2aa;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col4 {
            background-color:  #8db0fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col5 {
            background-color:  #e8d6cc;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col6 {
            background-color:  #df634e;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col7 {
            background-color:  #b40426;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col8 {
            background-color:  #3b4cc0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col9 {
            background-color:  #506bda;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col10 {
            background-color:  #f7b99e;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col11 {
            background-color:  #d5dbe5;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col12 {
            background-color:  #6384eb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col13 {
            background-color:  #efcfbf;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col14 {
            background-color:  #5977e3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col15 {
            background-color:  #89acfd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col16 {
            background-color:  #7093f3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col17 {
            background-color:  #dedcdb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col18 {
            background-color:  #d9dce1;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col19 {
            background-color:  #f5c1a9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col20 {
            background-color:  #f7bca1;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col21 {
            background-color:  #b9d0f9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col22 {
            background-color:  #b2ccfb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col23 {
            background-color:  #516ddb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col24 {
            background-color:  #5875e1;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col25 {
            background-color:  #6c8ff1;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col26 {
            background-color:  #6e90f2;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col27 {
            background-color:  #455cce;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col28 {
            background-color:  #6f92f3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col29 {
            background-color:  #6687ed;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col30 {
            background-color:  #8db0fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col0 {
            background-color:  #5d7ce6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col1 {
            background-color:  #4f69d9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col2 {
            background-color:  #b6cefa;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col3 {
            background-color:  #89acfd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col4 {
            background-color:  #5673e0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col5 {
            background-color:  #aac7fd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col6 {
            background-color:  #6c8ff1;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col7 {
            background-color:  #4e68d8;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col8 {
            background-color:  #b40426;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col9 {
            background-color:  #6788ee;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col10 {
            background-color:  #f39577;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col11 {
            background-color:  #7396f5;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col12 {
            background-color:  #5b7ae5;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col13 {
            background-color:  #f2c9b4;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col14 {
            background-color:  #f7b194;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col15 {
            background-color:  #edd2c3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col16 {
            background-color:  #6e90f2;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col17 {
            background-color:  #f7b497;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col18 {
            background-color:  #9ebeff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col19 {
            background-color:  #d5dbe5;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col20 {
            background-color:  #c5d6f2;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col21 {
            background-color:  #90b2fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col22 {
            background-color:  #b2ccfb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col23 {
            background-color:  #7699f6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col24 {
            background-color:  #3f53c6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col25 {
            background-color:  #5e7de7;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col26 {
            background-color:  #5d7ce6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col27 {
            background-color:  #506bda;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col28 {
            background-color:  #adc9fd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col29 {
            background-color:  #7ea1fa;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col30 {
            background-color:  #96b7ff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col0 {
            background-color:  #5f7fe8;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col1 {
            background-color:  #4055c8;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col2 {
            background-color:  #7699f6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col3 {
            background-color:  #9abbff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col4 {
            background-color:  #7699f6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col5 {
            background-color:  #afcafc;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col6 {
            background-color:  #90b2fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col7 {
            background-color:  #7ea1fa;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col8 {
            background-color:  #82a6fb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col9 {
            background-color:  #b40426;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col10 {
            background-color:  #a9c6fd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col11 {
            background-color:  #92b4fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col12 {
            background-color:  #6180e9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col13 {
            background-color:  #a5c3fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col14 {
            background-color:  #7295f4;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col15 {
            background-color:  #84a7fc;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col16 {
            background-color:  #5e7de7;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col17 {
            background-color:  #94b6ff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col18 {
            background-color:  #5d7ce6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col19 {
            background-color:  #9abbff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col20 {
            background-color:  #97b8ff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col21 {
            background-color:  #6e90f2;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col22 {
            background-color:  #7b9ff9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col23 {
            background-color:  #7699f6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col24 {
            background-color:  #455cce;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col25 {
            background-color:  #5977e3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col26 {
            background-color:  #5875e1;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col27 {
            background-color:  #4a63d3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col28 {
            background-color:  #d4dbe6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col29 {
            background-color:  #aec9fc;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col30 {
            background-color:  #b7cff9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col0 {
            background-color:  #97b8ff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col1 {
            background-color:  #96b7ff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col2 {
            background-color:  #e5d8d1;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col3 {
            background-color:  #d5dbe5;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col4 {
            background-color:  #6f92f3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col5 {
            background-color:  #dadce0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col6 {
            background-color:  #f2c9b4;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col7 {
            background-color:  #f7b99e;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col8 {
            background-color:  #f59d7e;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col9 {
            background-color:  #7ea1fa;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col10 {
            background-color:  #b40426;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col11 {
            background-color:  #a6c4fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col12 {
            background-color:  #5d7ce6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col13 {
            background-color:  #f49a7b;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col14 {
            background-color:  #e4d9d2;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col15 {
            background-color:  #efcebd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col16 {
            background-color:  #7b9ff9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col17 {
            background-color:  #e36b54;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col18 {
            background-color:  #e5d8d1;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col19 {
            background-color:  #f7bca1;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col20 {
            background-color:  #f6bfa6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col21 {
            background-color:  #bbd1f8;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col22 {
            background-color:  #d1dae9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col23 {
            background-color:  #6687ed;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col24 {
            background-color:  #4c66d6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col25 {
            background-color:  #7093f3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col26 {
            background-color:  #7a9df8;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col27 {
            background-color:  #4a63d3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col28 {
            background-color:  #82a6fb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col29 {
            background-color:  #5a78e4;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col30 {
            background-color:  #88abfd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col0 {
            background-color:  #5470de;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col1 {
            background-color:  #7295f4;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col2 {
            background-color:  #9fbfff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col3 {
            background-color:  #f39475;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col4 {
            background-color:  #9fbfff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col5 {
            background-color:  #4961d2;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col6 {
            background-color:  #dddcdc;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col7 {
            background-color:  #c4d5f3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col8 {
            background-color:  #4358cb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col9 {
            background-color:  #485fd1;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col10 {
            background-color:  #8db0fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col11 {
            background-color:  #b40426;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col12 {
            background-color:  #3b4cc0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col13 {
            background-color:  #96b7ff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col14 {
            background-color:  #7093f3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col15 {
            background-color:  #3b4cc0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col16 {
            background-color:  #506bda;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col17 {
            background-color:  #5f7fe8;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col18 {
            background-color:  #8caffe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col19 {
            background-color:  #cbd8ee;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col20 {
            background-color:  #cdd9ec;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col21 {
            background-color:  #a7c5fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col22 {
            background-color:  #89acfd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col23 {
            background-color:  #5572df;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col24 {
            background-color:  #465ecf;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col25 {
            background-color:  #5977e3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col26 {
            background-color:  #5977e3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col27 {
            background-color:  #445acc;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col28 {
            background-color:  #85a8fc;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col29 {
            background-color:  #84a7fc;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col30 {
            background-color:  #8db0fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col0 {
            background-color:  #4961d2;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col1 {
            background-color:  #4e68d8;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col2 {
            background-color:  #90b2fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col3 {
            background-color:  #b9d0f9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col4 {
            background-color:  #86a9fc;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col5 {
            background-color:  #93b5fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col6 {
            background-color:  #98b9ff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col7 {
            background-color:  #82a6fb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col8 {
            background-color:  #6a8bef;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col9 {
            background-color:  #536edd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col10 {
            background-color:  #7ea1fa;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col11 {
            background-color:  #799cf8;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col12 {
            background-color:  #b40426;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col13 {
            background-color:  #98b9ff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col14 {
            background-color:  #7699f6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col15 {
            background-color:  #7093f3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col16 {
            background-color:  #516ddb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col17 {
            background-color:  #6788ee;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col18 {
            background-color:  #6b8df0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col19 {
            background-color:  #abc8fd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col20 {
            background-color:  #a1c0ff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col21 {
            background-color:  #81a4fb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col22 {
            background-color:  #6f92f3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col23 {
            background-color:  #6180e9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col24 {
            background-color:  #516ddb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col25 {
            background-color:  #5b7ae5;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col26 {
            background-color:  #4a63d3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col27 {
            background-color:  #4961d2;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col28 {
            background-color:  #b7cff9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col29 {
            background-color:  #a2c1ff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col30 {
            background-color:  #a7c5fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col0 {
            background-color:  #7699f6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col1 {
            background-color:  #6788ee;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col2 {
            background-color:  #cedaeb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col3 {
            background-color:  #b6cefa;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col4 {
            background-color:  #5d7ce6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col5 {
            background-color:  #e3d9d3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col6 {
            background-color:  #e0dbd8;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col7 {
            background-color:  #e1dad6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col8 {
            background-color:  #e1dad6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col9 {
            background-color:  #5470de;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col10 {
            background-color:  #f7a889;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col11 {
            background-color:  #8db0fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col12 {
            background-color:  #536edd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col13 {
            background-color:  #b40426;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col14 {
            background-color:  #9fbfff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col15 {
            background-color:  #cedaeb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col16 {
            background-color:  #85a8fc;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col17 {
            background-color:  #f5c4ac;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col18 {
            background-color:  #adc9fd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col19 {
            background-color:  #f7bca1;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col20 {
            background-color:  #f2cbb7;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col21 {
            background-color:  #abc8fd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col22 {
            background-color:  #c0d4f5;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col23 {
            background-color:  #445acc;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col24 {
            background-color:  #516ddb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col25 {
            background-color:  #4f69d9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col26 {
            background-color:  #536edd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col27 {
            background-color:  #465ecf;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col28 {
            background-color:  #485fd1;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col29 {
            background-color:  #3b4cc0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col30 {
            background-color:  #6a8bef;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col0 {
            background-color:  #4c66d6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col1 {
            background-color:  #445acc;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col2 {
            background-color:  #bcd2f7;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col3 {
            background-color:  #aac7fd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col4 {
            background-color:  #688aef;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col5 {
            background-color:  #9fbfff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col6 {
            background-color:  #8caffe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col7 {
            background-color:  #6282ea;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col8 {
            background-color:  #f7b599;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col9 {
            background-color:  #4c66d6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col10 {
            background-color:  #e9d5cb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col11 {
            background-color:  #96b7ff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col12 {
            background-color:  #5f7fe8;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col13 {
            background-color:  #c4d5f3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col14 {
            background-color:  #b40426;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col15 {
            background-color:  #a7c5fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col16 {
            background-color:  #4961d2;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col17 {
            background-color:  #cfdaea;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col18 {
            background-color:  #a1c0ff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col19 {
            background-color:  #dbdcde;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col20 {
            background-color:  #cbd8ee;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col21 {
            background-color:  #94b6ff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col22 {
            background-color:  #afcafc;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col23 {
            background-color:  #4961d2;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col24 {
            background-color:  #455cce;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col25 {
            background-color:  #6788ee;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col26 {
            background-color:  #4b64d5;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col27 {
            background-color:  #4b64d5;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col28 {
            background-color:  #799cf8;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col29 {
            background-color:  #7396f5;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col30 {
            background-color:  #82a6fb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col0 {
            background-color:  #7ea1fa;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col1 {
            background-color:  #6485ec;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col2 {
            background-color:  #a3c2fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col3 {
            background-color:  #90b2fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col4 {
            background-color:  #6e90f2;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col5 {
            background-color:  #cdd9ec;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col6 {
            background-color:  #a5c3fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col7 {
            background-color:  #a5c3fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col8 {
            background-color:  #f0cdbb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col9 {
            background-color:  #7597f6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col10 {
            background-color:  #f5c2aa;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col11 {
            background-color:  #799cf8;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col12 {
            background-color:  #7093f3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col13 {
            background-color:  #ecd3c5;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col14 {
            background-color:  #b9d0f9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col15 {
            background-color:  #b40426;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col16 {
            background-color:  #9abbff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col17 {
            background-color:  #f6a283;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col18 {
            background-color:  #84a7fc;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col19 {
            background-color:  #c1d4f4;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col20 {
            background-color:  #b6cefa;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col21 {
            background-color:  #82a6fb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col22 {
            background-color:  #92b4fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col23 {
            background-color:  #6f92f3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col24 {
            background-color:  #3f53c6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col25 {
            background-color:  #5f7fe8;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col26 {
            background-color:  #5a78e4;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col27 {
            background-color:  #4e68d8;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col28 {
            background-color:  #bfd3f6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col29 {
            background-color:  #aac7fd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col30 {
            background-color:  #aac7fd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col0 {
            background-color:  #5a78e4;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col1 {
            background-color:  #3b4cc0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col2 {
            background-color:  #7ea1fa;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col3 {
            background-color:  #96b7ff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col4 {
            background-color:  #6687ed;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col5 {
            background-color:  #afcafc;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col6 {
            background-color:  #86a9fc;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col7 {
            background-color:  #96b7ff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col8 {
            background-color:  #81a4fb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col9 {
            background-color:  #5673e0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col10 {
            background-color:  #9fbfff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col11 {
            background-color:  #93b5fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col12 {
            background-color:  #5875e1;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col13 {
            background-color:  #c3d5f4;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col14 {
            background-color:  #6687ed;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col15 {
            background-color:  #9fbfff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col16 {
            background-color:  #b40426;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col17 {
            background-color:  #b9d0f9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col18 {
            background-color:  #4055c8;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col19 {
            background-color:  #a5c3fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col20 {
            background-color:  #97b8ff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col21 {
            background-color:  #5b7ae5;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col22 {
            background-color:  #6384eb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col23 {
            background-color:  #6e90f2;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col24 {
            background-color:  #3f53c6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col25 {
            background-color:  #4358cb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col26 {
            background-color:  #4055c8;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col27 {
            background-color:  #5e7de7;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col28 {
            background-color:  #d3dbe7;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col29 {
            background-color:  #c4d5f3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col30 {
            background-color:  #c1d4f4;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col0 {
            background-color:  #97b8ff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col1 {
            background-color:  #7da0f9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col2 {
            background-color:  #cfdaea;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col3 {
            background-color:  #b3cdfb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col4 {
            background-color:  #6788ee;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col5 {
            background-color:  #dcdddd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col6 {
            background-color:  #d9dce1;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col7 {
            background-color:  #e7d7ce;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col8 {
            background-color:  #f7b396;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col9 {
            background-color:  #7da0f9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col10 {
            background-color:  #e0654f;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col11 {
            background-color:  #90b2fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col12 {
            background-color:  #5b7ae5;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col13 {
            background-color:  #f7ad90;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col14 {
            background-color:  #d5dbe5;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col15 {
            background-color:  #f6a586;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col16 {
            background-color:  #abc8fd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col17 {
            background-color:  #b40426;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col18 {
            background-color:  #c4d5f3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col19 {
            background-color:  #efcebd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col20 {
            background-color:  #ead5c9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col21 {
            background-color:  #a5c3fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col22 {
            background-color:  #b9d0f9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col23 {
            background-color:  #6485ec;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col24 {
            background-color:  #455cce;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col25 {
            background-color:  #6384eb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col26 {
            background-color:  #5e7de7;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col27 {
            background-color:  #536edd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col28 {
            background-color:  #9abbff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col29 {
            background-color:  #7093f3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col30 {
            background-color:  #98b9ff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col0 {
            background-color:  #5e7de7;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col1 {
            background-color:  #98b9ff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col2 {
            background-color:  #c9d7f0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col3 {
            background-color:  #dedcdb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col4 {
            background-color:  #80a3fa;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col5 {
            background-color:  #b5cdfa;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col6 {
            background-color:  #e3d9d3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col7 {
            background-color:  #e7d7ce;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col8 {
            background-color:  #a9c6fd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col9 {
            background-color:  #4f69d9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col10 {
            background-color:  #efcebd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col11 {
            background-color:  #bed2f6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col12 {
            background-color:  #6b8df0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col13 {
            background-color:  #d9dce1;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col14 {
            background-color:  #b3cdfb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col15 {
            background-color:  #84a7fc;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col16 {
            background-color:  #3b4cc0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col17 {
            background-color:  #cbd8ee;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col18 {
            background-color:  #b40426;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col19 {
            background-color:  #e8d6cc;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col20 {
            background-color:  #dedcdb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col21 {
            background-color:  #aec9fc;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col22 {
            background-color:  #a7c5fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col23 {
            background-color:  #5d7ce6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col24 {
            background-color:  #4a63d3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col25 {
            background-color:  #8caffe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col26 {
            background-color:  #6282ea;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col27 {
            background-color:  #4b64d5;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col28 {
            background-color:  #8db0fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col29 {
            background-color:  #84a7fc;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col30 {
            background-color:  #8caffe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col0 {
            background-color:  #84a7fc;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col1 {
            background-color:  #7093f3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col2 {
            background-color:  #e0dbd8;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col3 {
            background-color:  #d8dce2;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col4 {
            background-color:  #6788ee;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col5 {
            background-color:  #d6dce4;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col6 {
            background-color:  #f1ccb8;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col7 {
            background-color:  #ecd3c5;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col8 {
            background-color:  #a6c4fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col9 {
            background-color:  #3b4cc0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col10 {
            background-color:  #f0cdbb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col11 {
            background-color:  #bcd2f7;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col12 {
            background-color:  #5d7ce6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col13 {
            background-color:  #f5c0a7;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col14 {
            background-color:  #b7cff9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col15 {
            background-color:  #7da0f9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col16 {
            background-color:  #4e68d8;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col17 {
            background-color:  #d4dbe6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col18 {
            background-color:  #bed2f6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col19 {
            background-color:  #b40426;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col20 {
            background-color:  #d0473d;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col21 {
            background-color:  #b6cefa;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col22 {
            background-color:  #b3cdfb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col23 {
            background-color:  #3b4cc0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col24 {
            background-color:  #516ddb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col25 {
            background-color:  #6180e9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col26 {
            background-color:  #4a63d3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col27 {
            background-color:  #3e51c5;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col28 {
            background-color:  #3b4cc0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col29 {
            background-color:  #3e51c5;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col30 {
            background-color:  #3b4cc0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col0 {
            background-color:  #90b2fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col1 {
            background-color:  #799cf8;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col2 {
            background-color:  #e2dad5;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col3 {
            background-color:  #e4d9d2;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col4 {
            background-color:  #6c8ff1;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col5 {
            background-color:  #d1dae9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col6 {
            background-color:  #f5c2aa;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col7 {
            background-color:  #f2cab5;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col8 {
            background-color:  #98b9ff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col9 {
            background-color:  #4257c9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col10 {
            background-color:  #f0cdbb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col11 {
            background-color:  #c7d7f0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col12 {
            background-color:  #5b7ae5;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col13 {
            background-color:  #f1ccb8;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col14 {
            background-color:  #a7c5fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col15 {
            background-color:  #779af7;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col16 {
            background-color:  #4a63d3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col17 {
            background-color:  #cedaeb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col18 {
            background-color:  #b5cdfa;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col19 {
            background-color:  #cf453c;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col20 {
            background-color:  #b40426;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col21 {
            background-color:  #b5cdfa;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col22 {
            background-color:  #bbd1f8;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col23 {
            background-color:  #4257c9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col24 {
            background-color:  #516ddb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col25 {
            background-color:  #6180e9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col26 {
            background-color:  #5673e0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col27 {
            background-color:  #4358cb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col28 {
            background-color:  #455cce;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col29 {
            background-color:  #485fd1;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col30 {
            background-color:  #4257c9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col0 {
            background-color:  #4b64d5;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col1 {
            background-color:  #7699f6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col2 {
            background-color:  #b3cdfb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col3 {
            background-color:  #d4dbe6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col4 {
            background-color:  #85a8fc;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col5 {
            background-color:  #a7c5fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col6 {
            background-color:  #cedaeb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col7 {
            background-color:  #c1d4f4;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col8 {
            background-color:  #8badfd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col9 {
            background-color:  #4e68d8;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col10 {
            background-color:  #c5d6f2;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col11 {
            background-color:  #c6d6f1;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col12 {
            background-color:  #6e90f2;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col13 {
            background-color:  #cedaeb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col14 {
            background-color:  #98b9ff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col15 {
            background-color:  #7093f3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col16 {
            background-color:  #4358cb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col17 {
            background-color:  #9fbfff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col18 {
            background-color:  #9fbfff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col19 {
            background-color:  #dcdddd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col20 {
            background-color:  #d6dce4;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col21 {
            background-color:  #b40426;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col22 {
            background-color:  #88abfd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col23 {
            background-color:  #4055c8;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col24 {
            background-color:  #3d50c3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col25 {
            background-color:  #3d50c3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col26 {
            background-color:  #5a78e4;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col27 {
            background-color:  #4961d2;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col28 {
            background-color:  #7da0f9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col29 {
            background-color:  #6e90f2;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col30 {
            background-color:  #7699f6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col0 {
            background-color:  #6687ed;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col1 {
            background-color:  #5977e3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col2 {
            background-color:  #a9c6fd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col3 {
            background-color:  #c1d4f4;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col4 {
            background-color:  #7295f4;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col5 {
            background-color:  #c5d6f2;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col6 {
            background-color:  #d2dbe8;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col7 {
            background-color:  #bbd1f8;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col8 {
            background-color:  #adc9fd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col9 {
            background-color:  #5a78e4;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col10 {
            background-color:  #d8dce2;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col11 {
            background-color:  #aec9fc;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col12 {
            background-color:  #5b7ae5;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col13 {
            background-color:  #dcdddd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col14 {
            background-color:  #b2ccfb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col15 {
            background-color:  #80a3fa;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col16 {
            background-color:  #4961d2;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col17 {
            background-color:  #b2ccfb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col18 {
            background-color:  #96b7ff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col19 {
            background-color:  #dadce0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col20 {
            background-color:  #d9dce1;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col21 {
            background-color:  #86a9fc;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col22 {
            background-color:  #b40426;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col23 {
            background-color:  #4961d2;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col24 {
            background-color:  #455cce;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col25 {
            background-color:  #688aef;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col26 {
            background-color:  #5673e0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col27 {
            background-color:  #455cce;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col28 {
            background-color:  #84a7fc;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col29 {
            background-color:  #688aef;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col30 {
            background-color:  #9abbff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col0 {
            background-color:  #5977e3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col1 {
            background-color:  #3b4cc0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col2 {
            background-color:  #6b8df0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col3 {
            background-color:  #92b4fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col4 {
            background-color:  #7da0f9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col5 {
            background-color:  #a9c6fd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col6 {
            background-color:  #80a3fa;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col7 {
            background-color:  #7093f3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col8 {
            background-color:  #82a6fb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col9 {
            background-color:  #6788ee;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col10 {
            background-color:  #86a9fc;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col11 {
            background-color:  #92b4fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col12 {
            background-color:  #6180e9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col13 {
            background-color:  #89acfd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col14 {
            background-color:  #5f7fe8;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col15 {
            background-color:  #6f92f3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col16 {
            background-color:  #6788ee;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col17 {
            background-color:  #6f92f3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col18 {
            background-color:  #5b7ae5;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col19 {
            background-color:  #8db0fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col20 {
            background-color:  #89acfd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col21 {
            background-color:  #536edd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col22 {
            background-color:  #5d7ce6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col23 {
            background-color:  #b40426;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col24 {
            background-color:  #3c4ec2;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col25 {
            background-color:  #3b4cc0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col26 {
            background-color:  #5572df;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col27 {
            background-color:  #506bda;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col28 {
            background-color:  #f2cbb7;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col29 {
            background-color:  #ccd9ed;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col30 {
            background-color:  #cdd9ec;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col0 {
            background-color:  #5875e1;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col1 {
            background-color:  #455cce;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col2 {
            background-color:  #8db0fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col3 {
            background-color:  #afcafc;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col4 {
            background-color:  #688aef;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col5 {
            background-color:  #aec9fc;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col6 {
            background-color:  #a2c1ff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col7 {
            background-color:  #92b4fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col8 {
            background-color:  #688aef;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col9 {
            background-color:  #5470de;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col10 {
            background-color:  #89acfd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col11 {
            background-color:  #9ebeff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col12 {
            background-color:  #6c8ff1;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col13 {
            background-color:  #adc9fd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col14 {
            background-color:  #779af7;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col15 {
            background-color:  #5d7ce6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col16 {
            background-color:  #5572df;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col17 {
            background-color:  #6c8ff1;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col18 {
            background-color:  #6687ed;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col19 {
            background-color:  #b7cff9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col20 {
            background-color:  #afcafc;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col21 {
            background-color:  #6b8df0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col22 {
            background-color:  #7597f6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col23 {
            background-color:  #5977e3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col24 {
            background-color:  #b40426;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col25 {
            background-color:  #4961d2;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col26 {
            background-color:  #4257c9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col27 {
            background-color:  #4b64d5;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col28 {
            background-color:  #a9c6fd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col29 {
            background-color:  #96b7ff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col30 {
            background-color:  #a5c3fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col0 {
            background-color:  #5875e1;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col1 {
            background-color:  #4c66d6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col2 {
            background-color:  #9abbff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col3 {
            background-color:  #b7cff9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col4 {
            background-color:  #8caffe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col5 {
            background-color:  #a6c4fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col6 {
            background-color:  #adc9fd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col7 {
            background-color:  #9bbcff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col8 {
            background-color:  #7b9ff9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col9 {
            background-color:  #5d7ce6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col10 {
            background-color:  #9fbfff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col11 {
            background-color:  #a3c2fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col12 {
            background-color:  #6c8ff1;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col13 {
            background-color:  #a3c2fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col14 {
            background-color:  #8db0fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col15 {
            background-color:  #7093f3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col16 {
            background-color:  #4e68d8;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col17 {
            background-color:  #80a3fa;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col18 {
            background-color:  #9bbcff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col19 {
            background-color:  #bbd1f8;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col20 {
            background-color:  #b2ccfb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col21 {
            background-color:  #6180e9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col22 {
            background-color:  #8caffe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col23 {
            background-color:  #4c66d6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col24 {
            background-color:  #3e51c5;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col25 {
            background-color:  #b40426;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col26 {
            background-color:  #5470de;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col27 {
            background-color:  #5572df;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col28 {
            background-color:  #bbd1f8;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col29 {
            background-color:  #aac7fd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col30 {
            background-color:  #aac7fd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col0 {
            background-color:  #7396f5;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col1 {
            background-color:  #5875e1;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col2 {
            background-color:  #8caffe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col3 {
            background-color:  #c7d7f0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col4 {
            background-color:  #7ea1fa;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col5 {
            background-color:  #a1c0ff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col6 {
            background-color:  #b7cff9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col7 {
            background-color:  #a6c4fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col8 {
            background-color:  #88abfd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col9 {
            background-color:  #6788ee;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col10 {
            background-color:  #b2ccfb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col11 {
            background-color:  #aec9fc;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col12 {
            background-color:  #688aef;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col13 {
            background-color:  #b1cbfc;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col14 {
            background-color:  #80a3fa;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col15 {
            background-color:  #799cf8;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col16 {
            background-color:  #5875e1;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col17 {
            background-color:  #86a9fc;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col18 {
            background-color:  #80a3fa;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col19 {
            background-color:  #b5cdfa;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col20 {
            background-color:  #b5cdfa;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col21 {
            background-color:  #8badfd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col22 {
            background-color:  #88abfd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col23 {
            background-color:  #7396f5;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col24 {
            background-color:  #445acc;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col25 {
            background-color:  #6180e9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col26 {
            background-color:  #b40426;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col27 {
            background-color:  #5470de;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col28 {
            background-color:  #aec9fc;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col29 {
            background-color:  #9ebeff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col30 {
            background-color:  #a9c6fd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col0 {
            background-color:  #3f53c6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col1 {
            background-color:  #4b64d5;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col2 {
            background-color:  #81a4fb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col3 {
            background-color:  #aac7fd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col4 {
            background-color:  #7396f5;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col5 {
            background-color:  #a3c2fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col6 {
            background-color:  #93b5fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col7 {
            background-color:  #7da0f9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col8 {
            background-color:  #7597f6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col9 {
            background-color:  #5470de;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col10 {
            background-color:  #84a7fc;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col11 {
            background-color:  #97b8ff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col12 {
            background-color:  #6180e9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col13 {
            background-color:  #a2c1ff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col14 {
            background-color:  #7a9df8;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col15 {
            background-color:  #6687ed;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col16 {
            background-color:  #6f92f3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col17 {
            background-color:  #7597f6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col18 {
            background-color:  #6384eb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col19 {
            background-color:  #a6c4fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col20 {
            background-color:  #a1c0ff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col21 {
            background-color:  #7295f4;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col22 {
            background-color:  #7295f4;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col23 {
            background-color:  #688aef;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col24 {
            background-color:  #465ecf;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col25 {
            background-color:  #5b7ae5;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col26 {
            background-color:  #4e68d8;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col27 {
            background-color:  #b40426;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col28 {
            background-color:  #b7cff9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col29 {
            background-color:  #a3c2fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col30 {
            background-color:  #a9c6fd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col0 {
            background-color:  #465ecf;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col1 {
            background-color:  #3b4cc0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col2 {
            background-color:  #3b4cc0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col3 {
            background-color:  #6f92f3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col4 {
            background-color:  #80a3fa;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col5 {
            background-color:  #85a8fc;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col6 {
            background-color:  #3b4cc0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col7 {
            background-color:  #3b4cc0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col8 {
            background-color:  #6c8ff1;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col9 {
            background-color:  #8db0fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col10 {
            background-color:  #4f69d9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col11 {
            background-color:  #6f92f3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col12 {
            background-color:  #6e90f2;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col13 {
            background-color:  #3b4cc0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col14 {
            background-color:  #3b4cc0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col15 {
            background-color:  #779af7;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col16 {
            background-color:  #93b5fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col17 {
            background-color:  #536edd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col18 {
            background-color:  #3b4cc0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col19 {
            background-color:  #3b4cc0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col20 {
            background-color:  #3b4cc0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col21 {
            background-color:  #3b4cc0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col22 {
            background-color:  #445acc;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col23 {
            background-color:  #d4dbe6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col24 {
            background-color:  #3e51c5;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col25 {
            background-color:  #6180e9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col26 {
            background-color:  #4257c9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col27 {
            background-color:  #5572df;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col28 {
            background-color:  #b40426;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col29 {
            background-color:  #f7a688;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col30 {
            background-color:  #f6bfa6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col0 {
            background-color:  #3b4cc0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col1 {
            background-color:  #3b4cc0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col2 {
            background-color:  #5a78e4;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col3 {
            background-color:  #8badfd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col4 {
            background-color:  #86a9fc;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col5 {
            background-color:  #7ea1fa;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col6 {
            background-color:  #506bda;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col7 {
            background-color:  #445acc;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col8 {
            background-color:  #4961d2;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col9 {
            background-color:  #6788ee;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col10 {
            background-color:  #3b4cc0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col11 {
            background-color:  #81a4fb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col12 {
            background-color:  #6687ed;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col13 {
            background-color:  #3f53c6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col14 {
            background-color:  #4961d2;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col15 {
            background-color:  #6f92f3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col16 {
            background-color:  #8badfd;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col17 {
            background-color:  #3b4cc0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col18 {
            background-color:  #4358cb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col19 {
            background-color:  #516ddb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col20 {
            background-color:  #506bda;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col21 {
            background-color:  #3f53c6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col22 {
            background-color:  #3b4cc0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col23 {
            background-color:  #9ebeff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col24 {
            background-color:  #3b4cc0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col25 {
            background-color:  #5d7ce6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col26 {
            background-color:  #4257c9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col27 {
            background-color:  #4e68d8;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col28 {
            background-color:  #f59f80;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col29 {
            background-color:  #b40426;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col30 {
            background-color:  #e4d9d2;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col0 {
            background-color:  #688aef;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col1 {
            background-color:  #4055c8;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col2 {
            background-color:  #6485ec;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col3 {
            background-color:  #8caffe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col4 {
            background-color:  #6f92f3;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col5 {
            background-color:  #a7c5fe;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col6 {
            background-color:  #7597f6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col7 {
            background-color:  #6788ee;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col8 {
            background-color:  #5d7ce6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col9 {
            background-color:  #6b8df0;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col10 {
            background-color:  #6282ea;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col11 {
            background-color:  #84a7fc;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col12 {
            background-color:  #6485ec;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col13 {
            background-color:  #688aef;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col14 {
            background-color:  #516ddb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col15 {
            background-color:  #688aef;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col16 {
            background-color:  #81a4fb;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col17 {
            background-color:  #5e7de7;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col18 {
            background-color:  #455cce;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col19 {
            background-color:  #465ecf;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col20 {
            background-color:  #4257c9;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col21 {
            background-color:  #3f53c6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col22 {
            background-color:  #6788ee;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col23 {
            background-color:  #9abbff;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col24 {
            background-color:  #455cce;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col25 {
            background-color:  #5875e1;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col26 {
            background-color:  #485fd1;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col27 {
            background-color:  #4e68d8;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col28 {
            background-color:  #f7ba9f;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col29 {
            background-color:  #e1dad6;
        }    #T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col30 {
            background-color:  #b40426;
        }</style>  
<table id="T_e4735428_48da_11e9_a17a_48d224c0b2df" > 
<thead>    <tr> 
        <th class="blank level0" ></th> 
        <th class="col_heading level0 col0" >LotFrontage</th> 
        <th class="col_heading level0 col1" >LotArea</th> 
        <th class="col_heading level0 col2" >MasVnrArea</th> 
        <th class="col_heading level0 col3" >BsmtFinSF1</th> 
        <th class="col_heading level0 col4" >BsmtFinSF2</th> 
        <th class="col_heading level0 col5" >BsmtUnfSF</th> 
        <th class="col_heading level0 col6" >TotalBsmtSF</th> 
        <th class="col_heading level0 col7" >1stFlrSF</th> 
        <th class="col_heading level0 col8" >2ndFlrSF</th> 
        <th class="col_heading level0 col9" >LowQualFinSF</th> 
        <th class="col_heading level0 col10" >GrLivArea</th> 
        <th class="col_heading level0 col11" >BsmtFullBath</th> 
        <th class="col_heading level0 col12" >BsmtHalfBath</th> 
        <th class="col_heading level0 col13" >FullBath</th> 
        <th class="col_heading level0 col14" >HalfBath</th> 
        <th class="col_heading level0 col15" >BedroomAbvGr</th> 
        <th class="col_heading level0 col16" >KitchenAbvGr</th> 
        <th class="col_heading level0 col17" >TotRmsAbvGrd</th> 
        <th class="col_heading level0 col18" >Fireplaces</th> 
        <th class="col_heading level0 col19" >GarageCars</th> 
        <th class="col_heading level0 col20" >GarageArea</th> 
        <th class="col_heading level0 col21" >WoodDeckSF</th> 
        <th class="col_heading level0 col22" >OpenPorchSF</th> 
        <th class="col_heading level0 col23" >EnclosedPorch</th> 
        <th class="col_heading level0 col24" >3SsnPorch</th> 
        <th class="col_heading level0 col25" >ScreenPorch</th> 
        <th class="col_heading level0 col26" >PoolArea</th> 
        <th class="col_heading level0 col27" >MiscVal</th> 
        <th class="col_heading level0 col28" >Age_House</th> 
        <th class="col_heading level0 col29" >Age_Remod</th> 
        <th class="col_heading level0 col30" >Age_Garage</th> 
    </tr></thead> 
<tbody>    <tr> 
        <th id="T_e4735428_48da_11e9_a17a_48d224c0b2dflevel0_row0" class="row_heading level0 row0" >LotFrontage</th> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col0" class="data row0 col0" >1</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col1" class="data row0 col1" >0.1</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col2" class="data row0 col2" >0.11</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col3" class="data row0 col3" >0.077</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col4" class="data row0 col4" >-0.0092</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col5" class="data row0 col5" >0.16</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col6" class="data row0 col6" >0.24</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col7" class="data row0 col7" >0.25</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col8" class="data row0 col8" >0.042</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col9" class="data row0 col9" >0.05</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col10" class="data row0 col10" >0.22</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col11" class="data row0 col11" >0.011</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col12" class="data row0 col12" >-0.028</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col13" class="data row0 col13" >0.12</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col14" class="data row0 col14" >-0.013</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col15" class="data row0 col15" >0.14</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col16" class="data row0 col16" >0.034</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col17" class="data row0 col17" >0.22</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col18" class="data row0 col18" >0.044</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col19" class="data row0 col19" >0.17</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col20" class="data row0 col20" >0.2</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col21" class="data row0 col21" >-0.017</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col22" class="data row0 col22" >0.07</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col23" class="data row0 col23" >0.027</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col24" class="data row0 col24" >0.024</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col25" class="data row0 col25" >0.023</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col26" class="data row0 col26" >0.11</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col27" class="data row0 col27" >-0.06</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col28" class="data row0 col28" >-0.037</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col29" class="data row0 col29" >-0.079</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow0_col30" class="data row0 col30" >0.079</td> 
    </tr>    <tr> 
        <th id="T_e4735428_48da_11e9_a17a_48d224c0b2dflevel0_row1" class="row_heading level0 row1" >LotArea</th> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col0" class="data row1 col0" >0.1</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col1" class="data row1 col1" >1</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col2" class="data row1 col2" >0.1</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col3" class="data row1 col3" >0.21</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col4" class="data row1 col4" >0.11</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col5" class="data row1 col5" >-0.0026</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col6" class="data row1 col6" >0.26</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col7" class="data row1 col7" >0.3</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col8" class="data row1 col8" >0.051</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col9" class="data row1 col9" >0.0048</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col10" class="data row1 col10" >0.26</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col11" class="data row1 col11" >0.16</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col12" class="data row1 col12" >0.048</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col13" class="data row1 col13" >0.13</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col14" class="data row1 col14" >0.014</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col15" class="data row1 col15" >0.12</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col16" class="data row1 col16" >-0.018</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col17" class="data row1 col17" >0.19</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col18" class="data row1 col18" >0.27</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col19" class="data row1 col19" >0.15</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col20" class="data row1 col20" >0.18</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col21" class="data row1 col21" >0.17</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col22" class="data row1 col22" >0.085</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col23" class="data row1 col23" >-0.018</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col24" class="data row1 col24" >0.02</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col25" class="data row1 col25" >0.043</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col26" class="data row1 col26" >0.078</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col27" class="data row1 col27" >0.038</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col28" class="data row1 col28" >-0.015</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col29" class="data row1 col29" >-0.015</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow1_col30" class="data row1 col30" >0.0028</td> 
    </tr>    <tr> 
        <th id="T_e4735428_48da_11e9_a17a_48d224c0b2dflevel0_row2" class="row_heading level0 row2" >MasVnrArea</th> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col0" class="data row2 col0" >0.11</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col1" class="data row2 col1" >0.1</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col2" class="data row2 col2" >1</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col3" class="data row2 col3" >0.26</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col4" class="data row2 col4" >-0.071</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col5" class="data row2 col5" >0.11</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col6" class="data row2 col6" >0.36</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col7" class="data row2 col7" >0.34</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col8" class="data row2 col8" >0.17</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col9" class="data row2 col9" >-0.069</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col10" class="data row2 col10" >0.39</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col11" class="data row2 col11" >0.083</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col12" class="data row2 col12" >0.027</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col13" class="data row2 col13" >0.27</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col14" class="data row2 col14" >0.2</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col15" class="data row2 col15" >0.1</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col16" class="data row2 col16" >-0.039</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col17" class="data row2 col17" >0.28</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col18" class="data row2 col18" >0.25</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col19" class="data row2 col19" >0.36</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col20" class="data row2 col20" >0.37</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col21" class="data row2 col21" >0.16</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col22" class="data row2 col22" >0.12</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col23" class="data row2 col23" >-0.11</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col24" class="data row2 col24" >0.019</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col25" class="data row2 col25" >0.062</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col26" class="data row2 col26" >0.012</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col27" class="data row2 col27" >-0.03</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col28" class="data row2 col28" >-0.31</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col29" class="data row2 col29" >-0.18</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow2_col30" class="data row2 col30" >-0.14</td> 
    </tr>    <tr> 
        <th id="T_e4735428_48da_11e9_a17a_48d224c0b2dflevel0_row3" class="row_heading level0 row3" >BsmtFinSF1</th> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col0" class="data row3 col0" >0.077</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col1" class="data row3 col1" >0.21</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col2" class="data row3 col2" >0.26</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col3" class="data row3 col3" >1</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col4" class="data row3 col4" >-0.05</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col5" class="data row3 col5" >-0.5</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col6" class="data row3 col6" >0.52</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col7" class="data row3 col7" >0.45</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col8" class="data row3 col8" >-0.14</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col9" class="data row3 col9" >-0.065</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col10" class="data row3 col10" >0.21</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col11" class="data row3 col11" >0.65</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col12" class="data row3 col12" >0.067</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col13" class="data row3 col13" >0.059</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col14" class="data row3 col14" >0.0051</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col15" class="data row3 col15" >-0.11</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col16" class="data row3 col16" >-0.081</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col17" class="data row3 col17" >0.045</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col18" class="data row3 col18" >0.26</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col19" class="data row3 col19" >0.22</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col20" class="data row3 col20" >0.3</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col21" class="data row3 col21" >0.2</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col22" class="data row3 col22" >0.11</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col23" class="data row3 col23" >-0.1</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col24" class="data row3 col24" >0.026</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col25" class="data row3 col25" >0.062</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col26" class="data row3 col26" >0.14</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col27" class="data row3 col27" >0.0035</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col28" class="data row3 col28" >-0.25</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col29" class="data row3 col29" >-0.13</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow3_col30" class="data row3 col30" >-0.12</td> 
    </tr>    <tr> 
        <th id="T_e4735428_48da_11e9_a17a_48d224c0b2dflevel0_row4" class="row_heading level0 row4" >BsmtFinSF2</th> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col0" class="data row4 col0" >-0.0092</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col1" class="data row4 col1" >0.11</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col2" class="data row4 col2" >-0.071</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col3" class="data row4 col3" >-0.05</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col4" class="data row4 col4" >1</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col5" class="data row4 col5" >-0.21</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col6" class="data row4 col6" >0.1</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col7" class="data row4 col7" >0.097</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col8" class="data row4 col8" >-0.099</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col9" class="data row4 col9" >0.015</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col10" class="data row4 col10" >-0.0097</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col11" class="data row4 col11" >0.16</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col12" class="data row4 col12" >0.071</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col13" class="data row4 col13" >-0.076</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col14" class="data row4 col14" >-0.032</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col15" class="data row4 col15" >-0.016</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col16" class="data row4 col16" >-0.041</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col17" class="data row4 col17" >-0.035</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col18" class="data row4 col18" >0.047</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col19" class="data row4 col19" >-0.038</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col20" class="data row4 col20" >-0.018</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col21" class="data row4 col21" >0.068</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col22" class="data row4 col22" >0.003</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col23" class="data row4 col23" >0.036</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col24" class="data row4 col24" >-0.03</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col25" class="data row4 col25" >0.089</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col26" class="data row4 col26" >0.042</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col27" class="data row4 col27" >0.0049</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col28" class="data row4 col28" >0.05</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col29" class="data row4 col29" >0.07</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow4_col30" class="data row4 col30" >-0.011</td> 
    </tr>    <tr> 
        <th id="T_e4735428_48da_11e9_a17a_48d224c0b2dflevel0_row5" class="row_heading level0 row5" >BsmtUnfSF</th> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col0" class="data row5 col0" >0.16</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col1" class="data row5 col1" >-0.0026</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col2" class="data row5 col2" >0.11</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col3" class="data row5 col3" >-0.5</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col4" class="data row5 col4" >-0.21</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col5" class="data row5 col5" >1</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col6" class="data row5 col6" >0.42</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col7" class="data row5 col7" >0.32</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col8" class="data row5 col8" >0.0047</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col9" class="data row5 col9" >0.028</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col10" class="data row5 col10" >0.24</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col11" class="data row5 col11" >-0.42</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col12" class="data row5 col12" >-0.096</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col13" class="data row5 col13" >0.29</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col14" class="data row5 col14" >-0.041</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col15" class="data row5 col15" >0.17</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col16" class="data row5 col16" >0.03</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col17" class="data row5 col17" >0.25</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col18" class="data row5 col18" >0.051</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col19" class="data row5 col19" >0.21</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col20" class="data row5 col20" >0.18</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col21" class="data row5 col21" >-0.0053</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col22" class="data row5 col22" >0.13</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col23" class="data row5 col23" >-0.0026</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col24" class="data row5 col24" >0.021</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col25" class="data row5 col25" >-0.013</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col26" class="data row5 col26" >-0.035</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col27" class="data row5 col27" >-0.024</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col28" class="data row5 col28" >-0.15</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col29" class="data row5 col29" >-0.18</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow5_col30" class="data row5 col30" >-0.0062</td> 
    </tr>    <tr> 
        <th id="T_e4735428_48da_11e9_a17a_48d224c0b2dflevel0_row6" class="row_heading level0 row6" >TotalBsmtSF</th> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col0" class="data row6 col0" >0.24</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col1" class="data row6 col1" >0.26</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col2" class="data row6 col2" >0.36</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col3" class="data row6 col3" >0.52</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col4" class="data row6 col4" >0.1</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col5" class="data row6 col5" >0.42</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col6" class="data row6 col6" >1</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col7" class="data row6 col7" >0.82</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col8" class="data row6 col8" >-0.17</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col9" class="data row6 col9" >-0.033</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col10" class="data row6 col10" >0.46</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col11" class="data row6 col11" >0.31</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col12" class="data row6 col12" >-0.00057</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col13" class="data row6 col13" >0.32</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col14" class="data row6 col14" >-0.048</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col15" class="data row6 col15" >0.051</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col16" class="data row6 col16" >-0.069</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col17" class="data row6 col17" >0.29</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col18" class="data row6 col18" >0.34</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col19" class="data row6 col19" >0.44</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col20" class="data row6 col20" >0.49</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col21" class="data row6 col21" >0.23</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col22" class="data row6 col22" >0.25</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col23" class="data row6 col23" >-0.096</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col24" class="data row6 col24" >0.037</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col25" class="data row6 col25" >0.084</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col26" class="data row6 col26" >0.13</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col27" class="data row6 col27" >-0.019</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col28" class="data row6 col28" >-0.39</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col29" class="data row6 col29" >-0.29</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow6_col30" class="data row6 col30" >-0.14</td> 
    </tr>    <tr> 
        <th id="T_e4735428_48da_11e9_a17a_48d224c0b2dflevel0_row7" class="row_heading level0 row7" >1stFlrSF</th> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col0" class="data row7 col0" >0.25</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col1" class="data row7 col1" >0.3</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col2" class="data row7 col2" >0.34</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col3" class="data row7 col3" >0.45</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col4" class="data row7 col4" >0.097</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col5" class="data row7 col5" >0.32</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col6" class="data row7 col6" >0.82</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col7" class="data row7 col7" >1</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col8" class="data row7 col8" >-0.2</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col9" class="data row7 col9" >-0.014</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col10" class="data row7 col10" >0.57</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col11" class="data row7 col11" >0.24</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col12" class="data row7 col12" >0.0018</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col13" class="data row7 col13" >0.38</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col14" class="data row7 col14" >-0.12</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col15" class="data row7 col15" >0.13</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col16" class="data row7 col16" >0.068</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col17" class="data row7 col17" >0.41</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col18" class="data row7 col18" >0.41</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col19" class="data row7 col19" >0.44</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col20" class="data row7 col20" >0.49</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col21" class="data row7 col21" >0.24</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col22" class="data row7 col22" >0.21</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col23" class="data row7 col23" >-0.066</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col24" class="data row7 col24" >0.056</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col25" class="data row7 col25" >0.089</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col26" class="data row7 col26" >0.13</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col27" class="data row7 col27" >-0.021</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col28" class="data row7 col28" >-0.28</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col29" class="data row7 col29" >-0.24</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow7_col30" class="data row7 col30" >-0.1</td> 
    </tr>    <tr> 
        <th id="T_e4735428_48da_11e9_a17a_48d224c0b2dflevel0_row8" class="row_heading level0 row8" >2ndFlrSF</th> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col0" class="data row8 col0" >0.042</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col1" class="data row8 col1" >0.051</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col2" class="data row8 col2" >0.17</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col3" class="data row8 col3" >-0.14</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col4" class="data row8 col4" >-0.099</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col5" class="data row8 col5" >0.0047</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col6" class="data row8 col6" >-0.17</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col7" class="data row8 col7" >-0.2</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col8" class="data row8 col8" >1</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col9" class="data row8 col9" >0.063</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col10" class="data row8 col10" >0.69</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col11" class="data row8 col11" >-0.17</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col12" class="data row8 col12" >-0.024</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col13" class="data row8 col13" >0.42</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col14" class="data row8 col14" >0.61</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col15" class="data row8 col15" >0.5</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col16" class="data row8 col16" >0.059</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col17" class="data row8 col17" >0.62</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col18" class="data row8 col18" >0.2</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col19" class="data row8 col19" >0.18</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col20" class="data row8 col20" >0.14</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col21" class="data row8 col21" >0.092</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col22" class="data row8 col22" >0.21</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col23" class="data row8 col23" >0.062</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col24" class="data row8 col24" >-0.024</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col25" class="data row8 col25" >0.041</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col26" class="data row8 col26" >0.082</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col27" class="data row8 col27" >0.016</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col28" class="data row8 col28" >-0.011</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col29" class="data row8 col29" >-0.14</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow8_col30" class="data row8 col30" >-0.067</td> 
    </tr>    <tr> 
        <th id="T_e4735428_48da_11e9_a17a_48d224c0b2dflevel0_row9" class="row_heading level0 row9" >LowQualFinSF</th> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col0" class="data row9 col0" >0.05</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col1" class="data row9 col1" >0.0048</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col2" class="data row9 col2" >-0.069</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col3" class="data row9 col3" >-0.065</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col4" class="data row9 col4" >0.015</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col5" class="data row9 col5" >0.028</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col6" class="data row9 col6" >-0.033</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col7" class="data row9 col7" >-0.014</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col8" class="data row9 col8" >0.063</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col9" class="data row9 col9" >1</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col10" class="data row9 col10" >0.13</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col11" class="data row9 col11" >-0.047</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col12" class="data row9 col12" >-0.0059</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col13" class="data row9 col13" >-0.00064</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col14" class="data row9 col14" >-0.027</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col15" class="data row9 col15" >0.11</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col16" class="data row9 col16" >0.0075</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col17" class="data row9 col17" >0.13</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col18" class="data row9 col18" >-0.021</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col19" class="data row9 col19" >-0.094</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col20" class="data row9 col20" >-0.068</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col21" class="data row9 col21" >-0.025</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col22" class="data row9 col22" >0.018</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col23" class="data row9 col23" >0.061</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col24" class="data row9 col24" >-0.0043</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col25" class="data row9 col25" >0.027</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col26" class="data row9 col26" >0.062</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col27" class="data row9 col27" >-0.0038</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col28" class="data row9 col28" >0.18</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col29" class="data row9 col29" >0.061</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow9_col30" class="data row9 col30" >0.076</td> 
    </tr>    <tr> 
        <th id="T_e4735428_48da_11e9_a17a_48d224c0b2dflevel0_row10" class="row_heading level0 row10" >GrLivArea</th> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col0" class="data row10 col0" >0.22</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col1" class="data row10 col1" >0.26</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col2" class="data row10 col2" >0.39</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col3" class="data row10 col3" >0.21</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col4" class="data row10 col4" >-0.0097</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col5" class="data row10 col5" >0.24</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col6" class="data row10 col6" >0.46</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col7" class="data row10 col7" >0.57</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col8" class="data row10 col8" >0.69</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col9" class="data row10 col9" >0.13</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col10" class="data row10 col10" >1</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col11" class="data row10 col11" >0.035</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col12" class="data row10 col12" >-0.019</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col13" class="data row10 col13" >0.63</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col14" class="data row10 col14" >0.42</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col15" class="data row10 col15" >0.52</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col16" class="data row10 col16" >0.1</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col17" class="data row10 col17" >0.83</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col18" class="data row10 col18" >0.46</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col19" class="data row10 col19" >0.47</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col20" class="data row10 col20" >0.47</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col21" class="data row10 col21" >0.25</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col22" class="data row10 col22" >0.33</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col23" class="data row10 col23" >0.0091</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col24" class="data row10 col24" >0.021</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col25" class="data row10 col25" >0.1</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col26" class="data row10 col26" >0.17</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col27" class="data row10 col27" >-0.0024</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col28" class="data row10 col28" >-0.2</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col29" class="data row10 col29" >-0.29</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow10_col30" class="data row10 col30" >-0.12</td> 
    </tr>    <tr> 
        <th id="T_e4735428_48da_11e9_a17a_48d224c0b2dflevel0_row11" class="row_heading level0 row11" >BsmtFullBath</th> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col0" class="data row11 col0" >0.011</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col1" class="data row11 col1" >0.16</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col2" class="data row11 col2" >0.083</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col3" class="data row11 col3" >0.65</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col4" class="data row11 col4" >0.16</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col5" class="data row11 col5" >-0.42</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col6" class="data row11 col6" >0.31</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col7" class="data row11 col7" >0.24</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col8" class="data row11 col8" >-0.17</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col9" class="data row11 col9" >-0.047</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col10" class="data row11 col10" >0.035</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col11" class="data row11 col11" >1</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col12" class="data row11 col12" >-0.15</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col13" class="data row11 col13" >-0.064</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col14" class="data row11 col14" >-0.03</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col15" class="data row11 col15" >-0.15</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col16" class="data row11 col16" >-0.042</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col17" class="data row11 col17" >-0.053</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col18" class="data row11 col18" >0.14</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col19" class="data row11 col19" >0.13</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col20" class="data row11 col20" >0.18</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col21" class="data row11 col21" >0.18</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col22" class="data row11 col22" >0.067</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col23" class="data row11 col23" >-0.05</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col24" class="data row11 col24" >-0.00017</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col25" class="data row11 col25" >0.023</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col26" class="data row11 col26" >0.068</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col27" class="data row11 col27" >-0.023</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col28" class="data row11 col28" >-0.19</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col29" class="data row11 col29" >-0.12</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow11_col30" class="data row11 col30" >-0.1</td> 
    </tr>    <tr> 
        <th id="T_e4735428_48da_11e9_a17a_48d224c0b2dflevel0_row12" class="row_heading level0 row12" >BsmtHalfBath</th> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col0" class="data row12 col0" >-0.028</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col1" class="data row12 col1" >0.048</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col2" class="data row12 col2" >0.027</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col3" class="data row12 col3" >0.067</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col4" class="data row12 col4" >0.071</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col5" class="data row12 col5" >-0.096</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col6" class="data row12 col6" >-0.00057</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col7" class="data row12 col7" >0.0018</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col8" class="data row12 col8" >-0.024</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col9" class="data row12 col9" >-0.0059</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col10" class="data row12 col10" >-0.019</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col11" class="data row12 col11" >-0.15</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col12" class="data row12 col12" >1</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col13" class="data row12 col13" >-0.054</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col14" class="data row12 col14" >-0.012</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col15" class="data row12 col15" >0.047</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col16" class="data row12 col16" >-0.038</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col17" class="data row12 col17" >-0.024</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col18" class="data row12 col18" >0.029</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col19" class="data row12 col19" >-0.021</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col20" class="data row12 col20" >-0.025</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col21" class="data row12 col21" >0.04</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col22" class="data row12 col22" >-0.025</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col23" class="data row12 col23" >-0.0086</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col24" class="data row12 col24" >0.035</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col25" class="data row12 col25" >0.032</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col26" class="data row12 col26" >0.02</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col27" class="data row12 col27" >-0.0074</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col28" class="data row12 col28" >0.036</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col29" class="data row12 col29" >0.0092</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow12_col30" class="data row12 col30" >0.0059</td> 
    </tr>    <tr> 
        <th id="T_e4735428_48da_11e9_a17a_48d224c0b2dflevel0_row13" class="row_heading level0 row13" >FullBath</th> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col0" class="data row13 col0" >0.12</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col1" class="data row13 col1" >0.13</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col2" class="data row13 col2" >0.27</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col3" class="data row13 col3" >0.059</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col4" class="data row13 col4" >-0.076</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col5" class="data row13 col5" >0.29</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col6" class="data row13 col6" >0.32</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col7" class="data row13 col7" >0.38</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col8" class="data row13 col8" >0.42</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col9" class="data row13 col9" >-0.00064</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col10" class="data row13 col10" >0.63</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col11" class="data row13 col11" >-0.064</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col12" class="data row13 col12" >-0.054</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col13" class="data row13 col13" >1</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col14" class="data row13 col14" >0.14</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col15" class="data row13 col15" >0.36</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col16" class="data row13 col16" >0.13</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col17" class="data row13 col17" >0.55</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col18" class="data row13 col18" >0.24</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col19" class="data row13 col19" >0.47</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col20" class="data row13 col20" >0.41</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col21" class="data row13 col21" >0.19</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col22" class="data row13 col22" >0.26</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col23" class="data row13 col23" >-0.11</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col24" class="data row13 col24" >0.035</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col25" class="data row13 col25" >-0.008</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col26" class="data row13 col26" >0.05</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col27" class="data row13 col27" >-0.014</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col28" class="data row13 col28" >-0.47</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col29" class="data row13 col29" >-0.44</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow13_col30" class="data row13 col30" >-0.25</td> 
    </tr>    <tr> 
        <th id="T_e4735428_48da_11e9_a17a_48d224c0b2dflevel0_row14" class="row_heading level0 row14" >HalfBath</th> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col0" class="data row14 col0" >-0.013</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col1" class="data row14 col1" >0.014</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col2" class="data row14 col2" >0.2</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col3" class="data row14 col3" >0.0051</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col4" class="data row14 col4" >-0.032</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col5" class="data row14 col5" >-0.041</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col6" class="data row14 col6" >-0.048</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col7" class="data row14 col7" >-0.12</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col8" class="data row14 col8" >0.61</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col9" class="data row14 col9" >-0.027</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col10" class="data row14 col10" >0.42</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col11" class="data row14 col11" >-0.03</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col12" class="data row14 col12" >-0.012</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col13" class="data row14 col13" >0.14</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col14" class="data row14 col14" >1</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col15" class="data row14 col15" >0.23</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col16" class="data row14 col16" >-0.068</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col17" class="data row14 col17" >0.34</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col18" class="data row14 col18" >0.2</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col19" class="data row14 col19" >0.22</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col20" class="data row14 col20" >0.16</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col21" class="data row14 col21" >0.11</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col22" class="data row14 col22" >0.2</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col23" class="data row14 col23" >-0.095</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col24" class="data row14 col24" >-0.0049</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col25" class="data row14 col25" >0.073</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col26" class="data row14 col26" >0.022</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col27" class="data row14 col27" >0.0014</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col28" class="data row14 col28" >-0.24</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col29" class="data row14 col29" >-0.18</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow14_col30" class="data row14 col30" >-0.15</td> 
    </tr>    <tr> 
        <th id="T_e4735428_48da_11e9_a17a_48d224c0b2dflevel0_row15" class="row_heading level0 row15" >BedroomAbvGr</th> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col0" class="data row15 col0" >0.14</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col1" class="data row15 col1" >0.12</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col2" class="data row15 col2" >0.1</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col3" class="data row15 col3" >-0.11</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col4" class="data row15 col4" >-0.016</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col5" class="data row15 col5" >0.17</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col6" class="data row15 col6" >0.051</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col7" class="data row15 col7" >0.13</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col8" class="data row15 col8" >0.5</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col9" class="data row15 col9" >0.11</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col10" class="data row15 col10" >0.52</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col11" class="data row15 col11" >-0.15</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col12" class="data row15 col12" >0.047</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col13" class="data row15 col13" >0.36</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col14" class="data row15 col14" >0.23</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col15" class="data row15 col15" >1</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col16" class="data row15 col16" >0.2</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col17" class="data row15 col17" >0.68</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col18" class="data row15 col18" >0.11</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col19" class="data row15 col19" >0.086</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col20" class="data row15 col20" >0.065</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col21" class="data row15 col21" >0.047</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col22" class="data row15 col22" >0.094</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col23" class="data row15 col23" >0.042</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col24" class="data row15 col24" >-0.024</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col25" class="data row15 col25" >0.044</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col26" class="data row15 col26" >0.071</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col27" class="data row15 col27" >0.0078</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col28" class="data row15 col28" >0.069</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col29" class="data row15 col29" >0.038</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow15_col30" class="data row15 col30" >0.017</td> 
    </tr>    <tr> 
        <th id="T_e4735428_48da_11e9_a17a_48d224c0b2dflevel0_row16" class="row_heading level0 row16" >KitchenAbvGr</th> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col0" class="data row16 col0" >0.034</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col1" class="data row16 col1" >-0.018</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col2" class="data row16 col2" >-0.039</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col3" class="data row16 col3" >-0.081</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col4" class="data row16 col4" >-0.041</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col5" class="data row16 col5" >0.03</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col6" class="data row16 col6" >-0.069</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col7" class="data row16 col7" >0.068</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col8" class="data row16 col8" >0.059</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col9" class="data row16 col9" >0.0075</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col10" class="data row16 col10" >0.1</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col11" class="data row16 col11" >-0.042</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col12" class="data row16 col12" >-0.038</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col13" class="data row16 col13" >0.13</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col14" class="data row16 col14" >-0.068</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col15" class="data row16 col15" >0.2</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col16" class="data row16 col16" >1</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col17" class="data row16 col17" >0.26</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col18" class="data row16 col18" >-0.12</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col19" class="data row16 col19" >-0.051</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col20" class="data row16 col20" >-0.064</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col21" class="data row16 col21" >-0.09</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col22" class="data row16 col22" >-0.07</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col23" class="data row16 col23" >0.037</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col24" class="data row16 col24" >-0.025</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col25" class="data row16 col25" >-0.052</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col26" class="data row16 col26" >-0.015</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col27" class="data row16 col27" >0.062</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col28" class="data row16 col28" >0.18</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col29" class="data row16 col29" >0.15</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow16_col30" class="data row16 col30" >0.12</td> 
    </tr>    <tr> 
        <th id="T_e4735428_48da_11e9_a17a_48d224c0b2dflevel0_row17" class="row_heading level0 row17" >TotRmsAbvGrd</th> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col0" class="data row17 col0" >0.22</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col1" class="data row17 col1" >0.19</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col2" class="data row17 col2" >0.28</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col3" class="data row17 col3" >0.045</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col4" class="data row17 col4" >-0.035</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col5" class="data row17 col5" >0.25</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col6" class="data row17 col6" >0.29</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col7" class="data row17 col7" >0.41</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col8" class="data row17 col8" >0.62</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col9" class="data row17 col9" >0.13</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col10" class="data row17 col10" >0.83</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col11" class="data row17 col11" >-0.053</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col12" class="data row17 col12" >-0.024</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col13" class="data row17 col13" >0.55</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col14" class="data row17 col14" >0.34</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col15" class="data row17 col15" >0.68</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col16" class="data row17 col16" >0.26</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col17" class="data row17 col17" >1</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col18" class="data row17 col18" >0.33</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col19" class="data row17 col19" >0.36</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col20" class="data row17 col20" >0.34</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col21" class="data row17 col21" >0.17</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col22" class="data row17 col22" >0.23</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col23" class="data row17 col23" >0.0042</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col24" class="data row17 col24" >-0.0067</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col25" class="data row17 col25" >0.059</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col26" class="data row17 col26" >0.084</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col27" class="data row17 col27" >0.025</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col28" class="data row17 col28" >-0.097</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col29" class="data row17 col29" >-0.19</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow17_col30" class="data row17 col30" >-0.057</td> 
    </tr>    <tr> 
        <th id="T_e4735428_48da_11e9_a17a_48d224c0b2dflevel0_row18" class="row_heading level0 row18" >Fireplaces</th> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col0" class="data row18 col0" >0.044</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col1" class="data row18 col1" >0.27</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col2" class="data row18 col2" >0.25</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col3" class="data row18 col3" >0.26</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col4" class="data row18 col4" >0.047</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col5" class="data row18 col5" >0.051</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col6" class="data row18 col6" >0.34</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col7" class="data row18 col7" >0.41</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col8" class="data row18 col8" >0.2</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col9" class="data row18 col9" >-0.021</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col10" class="data row18 col10" >0.46</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col11" class="data row18 col11" >0.14</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col12" class="data row18 col12" >0.029</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col13" class="data row18 col13" >0.24</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col14" class="data row18 col14" >0.2</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col15" class="data row18 col15" >0.11</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col16" class="data row18 col16" >-0.12</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col17" class="data row18 col17" >0.33</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col18" class="data row18 col18" >1</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col19" class="data row18 col19" >0.3</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col20" class="data row18 col20" >0.27</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col21" class="data row18 col21" >0.2</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col22" class="data row18 col22" >0.17</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col23" class="data row18 col23" >-0.025</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col24" class="data row18 col24" >0.011</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col25" class="data row18 col25" >0.18</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col26" class="data row18 col26" >0.095</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col27" class="data row18 col27" >0.0014</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col28" class="data row18 col28" >-0.15</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col29" class="data row18 col29" >-0.11</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow18_col30" class="data row18 col30" >-0.11</td> 
    </tr>    <tr> 
        <th id="T_e4735428_48da_11e9_a17a_48d224c0b2dflevel0_row19" class="row_heading level0 row19" >GarageCars</th> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col0" class="data row19 col0" >0.17</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col1" class="data row19 col1" >0.15</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col2" class="data row19 col2" >0.36</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col3" class="data row19 col3" >0.22</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col4" class="data row19 col4" >-0.038</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col5" class="data row19 col5" >0.21</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col6" class="data row19 col6" >0.44</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col7" class="data row19 col7" >0.44</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col8" class="data row19 col8" >0.18</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col9" class="data row19 col9" >-0.094</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col10" class="data row19 col10" >0.47</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col11" class="data row19 col11" >0.13</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col12" class="data row19 col12" >-0.021</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col13" class="data row19 col13" >0.47</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col14" class="data row19 col14" >0.22</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col15" class="data row19 col15" >0.086</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col16" class="data row19 col16" >-0.051</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col17" class="data row19 col17" >0.36</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col18" class="data row19 col18" >0.3</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col19" class="data row19 col19" >1</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col20" class="data row19 col20" >0.88</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col21" class="data row19 col21" >0.23</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col22" class="data row19 col22" >0.21</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col23" class="data row19 col23" >-0.15</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col24" class="data row19 col24" >0.036</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col25" class="data row19 col25" >0.051</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col26" class="data row19 col26" >0.021</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col27" class="data row19 col27" >-0.043</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col28" class="data row19 col28" >-0.54</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col29" class="data row19 col29" >-0.42</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow19_col30" class="data row19 col30" >-0.48</td> 
    </tr>    <tr> 
        <th id="T_e4735428_48da_11e9_a17a_48d224c0b2dflevel0_row20" class="row_heading level0 row20" >GarageArea</th> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col0" class="data row20 col0" >0.2</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col1" class="data row20 col1" >0.18</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col2" class="data row20 col2" >0.37</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col3" class="data row20 col3" >0.3</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col4" class="data row20 col4" >-0.018</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col5" class="data row20 col5" >0.18</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col6" class="data row20 col6" >0.49</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col7" class="data row20 col7" >0.49</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col8" class="data row20 col8" >0.14</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col9" class="data row20 col9" >-0.068</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col10" class="data row20 col10" >0.47</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col11" class="data row20 col11" >0.18</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col12" class="data row20 col12" >-0.025</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col13" class="data row20 col13" >0.41</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col14" class="data row20 col14" >0.16</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col15" class="data row20 col15" >0.065</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col16" class="data row20 col16" >-0.064</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col17" class="data row20 col17" >0.34</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col18" class="data row20 col18" >0.27</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col19" class="data row20 col19" >0.88</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col20" class="data row20 col20" >1</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col21" class="data row20 col21" >0.22</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col22" class="data row20 col22" >0.24</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col23" class="data row20 col23" >-0.12</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col24" class="data row20 col24" >0.035</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col25" class="data row20 col25" >0.051</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col26" class="data row20 col26" >0.061</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col27" class="data row20 col27" >-0.027</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col28" class="data row20 col28" >-0.48</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col29" class="data row20 col29" >-0.37</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow20_col30" class="data row20 col30" >-0.44</td> 
    </tr>    <tr> 
        <th id="T_e4735428_48da_11e9_a17a_48d224c0b2dflevel0_row21" class="row_heading level0 row21" >WoodDeckSF</th> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col0" class="data row21 col0" >-0.017</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col1" class="data row21 col1" >0.17</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col2" class="data row21 col2" >0.16</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col3" class="data row21 col3" >0.2</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col4" class="data row21 col4" >0.068</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col5" class="data row21 col5" >-0.0053</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col6" class="data row21 col6" >0.23</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col7" class="data row21 col7" >0.24</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col8" class="data row21 col8" >0.092</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col9" class="data row21 col9" >-0.025</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col10" class="data row21 col10" >0.25</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col11" class="data row21 col11" >0.18</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col12" class="data row21 col12" >0.04</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col13" class="data row21 col13" >0.19</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col14" class="data row21 col14" >0.11</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col15" class="data row21 col15" >0.047</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col16" class="data row21 col16" >-0.09</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col17" class="data row21 col17" >0.17</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col18" class="data row21 col18" >0.2</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col19" class="data row21 col19" >0.23</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col20" class="data row21 col20" >0.22</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col21" class="data row21 col21" >1</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col22" class="data row21 col22" >0.059</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col23" class="data row21 col23" >-0.13</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col24" class="data row21 col24" >-0.033</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col25" class="data row21 col25" >-0.074</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col26" class="data row21 col26" >0.073</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col27" class="data row21 col27" >-0.0095</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col28" class="data row21 col28" >-0.22</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col29" class="data row21 col29" >-0.2</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow21_col30" class="data row21 col30" >-0.2</td> 
    </tr>    <tr> 
        <th id="T_e4735428_48da_11e9_a17a_48d224c0b2dflevel0_row22" class="row_heading level0 row22" >OpenPorchSF</th> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col0" class="data row22 col0" >0.07</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col1" class="data row22 col1" >0.085</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col2" class="data row22 col2" >0.12</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col3" class="data row22 col3" >0.11</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col4" class="data row22 col4" >0.003</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col5" class="data row22 col5" >0.13</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col6" class="data row22 col6" >0.25</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col7" class="data row22 col7" >0.21</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col8" class="data row22 col8" >0.21</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col9" class="data row22 col9" >0.018</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col10" class="data row22 col10" >0.33</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col11" class="data row22 col11" >0.067</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col12" class="data row22 col12" >-0.025</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col13" class="data row22 col13" >0.26</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col14" class="data row22 col14" >0.2</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col15" class="data row22 col15" >0.094</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col16" class="data row22 col16" >-0.07</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col17" class="data row22 col17" >0.23</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col18" class="data row22 col18" >0.17</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col19" class="data row22 col19" >0.21</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col20" class="data row22 col20" >0.24</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col21" class="data row22 col21" >0.059</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col22" class="data row22 col22" >1</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col23" class="data row22 col23" >-0.093</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col24" class="data row22 col24" >-0.0059</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col25" class="data row22 col25" >0.074</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col26" class="data row22 col26" >0.061</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col27" class="data row22 col27" >-0.019</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col28" class="data row22 col28" >-0.19</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col29" class="data row22 col29" >-0.23</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow22_col30" class="data row22 col30" >-0.055</td> 
    </tr>    <tr> 
        <th id="T_e4735428_48da_11e9_a17a_48d224c0b2dflevel0_row23" class="row_heading level0 row23" >EnclosedPorch</th> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col0" class="data row23 col0" >0.027</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col1" class="data row23 col1" >-0.018</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col2" class="data row23 col2" >-0.11</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col3" class="data row23 col3" >-0.1</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col4" class="data row23 col4" >0.036</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col5" class="data row23 col5" >-0.0026</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col6" class="data row23 col6" >-0.096</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col7" class="data row23 col7" >-0.066</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col8" class="data row23 col8" >0.062</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col9" class="data row23 col9" >0.061</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col10" class="data row23 col10" >0.0091</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col11" class="data row23 col11" >-0.05</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col12" class="data row23 col12" >-0.0086</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col13" class="data row23 col13" >-0.11</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col14" class="data row23 col14" >-0.095</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col15" class="data row23 col15" >0.042</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col16" class="data row23 col16" >0.037</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col17" class="data row23 col17" >0.0042</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col18" class="data row23 col18" >-0.025</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col19" class="data row23 col19" >-0.15</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col20" class="data row23 col20" >-0.12</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col21" class="data row23 col21" >-0.13</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col22" class="data row23 col22" >-0.093</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col23" class="data row23 col23" >1</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col24" class="data row23 col24" >-0.037</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col25" class="data row23 col25" >-0.083</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col26" class="data row23 col26" >0.054</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col27" class="data row23 col27" >0.018</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col28" class="data row23 col28" >0.39</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col29" class="data row23 col29" >0.19</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow23_col30" class="data row23 col30" >0.18</td> 
    </tr>    <tr> 
        <th id="T_e4735428_48da_11e9_a17a_48d224c0b2dflevel0_row24" class="row_heading level0 row24" >3SsnPorch</th> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col0" class="data row24 col0" >0.024</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col1" class="data row24 col1" >0.02</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col2" class="data row24 col2" >0.019</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col3" class="data row24 col3" >0.026</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col4" class="data row24 col4" >-0.03</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col5" class="data row24 col5" >0.021</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col6" class="data row24 col6" >0.037</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col7" class="data row24 col7" >0.056</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col8" class="data row24 col8" >-0.024</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col9" class="data row24 col9" >-0.0043</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col10" class="data row24 col10" >0.021</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col11" class="data row24 col11" >-0.00017</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col12" class="data row24 col12" >0.035</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col13" class="data row24 col13" >0.035</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col14" class="data row24 col14" >-0.0049</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col15" class="data row24 col15" >-0.024</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col16" class="data row24 col16" >-0.025</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col17" class="data row24 col17" >-0.0067</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col18" class="data row24 col18" >0.011</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col19" class="data row24 col19" >0.036</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col20" class="data row24 col20" >0.035</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col21" class="data row24 col21" >-0.033</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col22" class="data row24 col22" >-0.0059</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col23" class="data row24 col23" >-0.037</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col24" class="data row24 col24" >1</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col25" class="data row24 col25" >-0.031</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col26" class="data row24 col26" >-0.008</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col27" class="data row24 col27" >0.00035</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col28" class="data row24 col28" >-0.031</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col29" class="data row24 col29" >-0.044</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow24_col30" class="data row24 col30" >-0.0059</td> 
    </tr>    <tr> 
        <th id="T_e4735428_48da_11e9_a17a_48d224c0b2dflevel0_row25" class="row_heading level0 row25" >ScreenPorch</th> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col0" class="data row25 col0" >0.023</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col1" class="data row25 col1" >0.043</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col2" class="data row25 col2" >0.062</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col3" class="data row25 col3" >0.062</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col4" class="data row25 col4" >0.089</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col5" class="data row25 col5" >-0.013</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col6" class="data row25 col6" >0.084</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col7" class="data row25 col7" >0.089</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col8" class="data row25 col8" >0.041</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col9" class="data row25 col9" >0.027</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col10" class="data row25 col10" >0.1</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col11" class="data row25 col11" >0.023</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col12" class="data row25 col12" >0.032</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col13" class="data row25 col13" >-0.008</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col14" class="data row25 col14" >0.073</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col15" class="data row25 col15" >0.044</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col16" class="data row25 col16" >-0.052</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col17" class="data row25 col17" >0.059</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col18" class="data row25 col18" >0.18</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col19" class="data row25 col19" >0.051</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col20" class="data row25 col20" >0.051</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col21" class="data row25 col21" >-0.074</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col22" class="data row25 col22" >0.074</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col23" class="data row25 col23" >-0.083</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col24" class="data row25 col24" >-0.031</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col25" class="data row25 col25" >1</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col26" class="data row25 col26" >0.051</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col27" class="data row25 col27" >0.032</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col28" class="data row25 col28" >0.051</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col29" class="data row25 col29" >0.039</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow25_col30" class="data row25 col30" >0.019</td> 
    </tr>    <tr> 
        <th id="T_e4735428_48da_11e9_a17a_48d224c0b2dflevel0_row26" class="row_heading level0 row26" >PoolArea</th> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col0" class="data row26 col0" >0.11</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col1" class="data row26 col1" >0.078</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col2" class="data row26 col2" >0.012</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col3" class="data row26 col3" >0.14</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col4" class="data row26 col4" >0.042</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col5" class="data row26 col5" >-0.035</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col6" class="data row26 col6" >0.13</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col7" class="data row26 col7" >0.13</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col8" class="data row26 col8" >0.082</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col9" class="data row26 col9" >0.062</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col10" class="data row26 col10" >0.17</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col11" class="data row26 col11" >0.068</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col12" class="data row26 col12" >0.02</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col13" class="data row26 col13" >0.05</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col14" class="data row26 col14" >0.022</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col15" class="data row26 col15" >0.071</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col16" class="data row26 col16" >-0.015</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col17" class="data row26 col17" >0.084</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col18" class="data row26 col18" >0.095</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col19" class="data row26 col19" >0.021</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col20" class="data row26 col20" >0.061</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col21" class="data row26 col21" >0.073</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col22" class="data row26 col22" >0.061</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col23" class="data row26 col23" >0.054</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col24" class="data row26 col24" >-0.008</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col25" class="data row26 col25" >0.051</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col26" class="data row26 col26" >1</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col27" class="data row26 col27" >0.03</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col28" class="data row26 col28" >-0.0076</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col29" class="data row26 col29" >-0.0097</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow26_col30" class="data row26 col30" >0.013</td> 
    </tr>    <tr> 
        <th id="T_e4735428_48da_11e9_a17a_48d224c0b2dflevel0_row27" class="row_heading level0 row27" >MiscVal</th> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col0" class="data row27 col0" >-0.06</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col1" class="data row27 col1" >0.038</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col2" class="data row27 col2" >-0.03</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col3" class="data row27 col3" >0.0035</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col4" class="data row27 col4" >0.0049</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col5" class="data row27 col5" >-0.024</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col6" class="data row27 col6" >-0.019</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col7" class="data row27 col7" >-0.021</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col8" class="data row27 col8" >0.016</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col9" class="data row27 col9" >-0.0038</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col10" class="data row27 col10" >-0.0024</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col11" class="data row27 col11" >-0.023</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col12" class="data row27 col12" >-0.0074</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col13" class="data row27 col13" >-0.014</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col14" class="data row27 col14" >0.0014</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col15" class="data row27 col15" >0.0078</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col16" class="data row27 col16" >0.062</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col17" class="data row27 col17" >0.025</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col18" class="data row27 col18" >0.0014</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col19" class="data row27 col19" >-0.043</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col20" class="data row27 col20" >-0.027</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col21" class="data row27 col21" >-0.0095</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col22" class="data row27 col22" >-0.019</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col23" class="data row27 col23" >0.018</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col24" class="data row27 col24" >0.00035</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col25" class="data row27 col25" >0.032</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col26" class="data row27 col26" >0.03</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col27" class="data row27 col27" >1</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col28" class="data row27 col28" >0.034</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col29" class="data row27 col29" >0.011</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow27_col30" class="data row27 col30" >0.0092</td> 
    </tr>    <tr> 
        <th id="T_e4735428_48da_11e9_a17a_48d224c0b2dflevel0_row28" class="row_heading level0 row28" >Age_House</th> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col0" class="data row28 col0" >-0.037</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col1" class="data row28 col1" >-0.015</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col2" class="data row28 col2" >-0.31</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col3" class="data row28 col3" >-0.25</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col4" class="data row28 col4" >0.05</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col5" class="data row28 col5" >-0.15</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col6" class="data row28 col6" >-0.39</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col7" class="data row28 col7" >-0.28</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col8" class="data row28 col8" >-0.011</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col9" class="data row28 col9" >0.18</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col10" class="data row28 col10" >-0.2</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col11" class="data row28 col11" >-0.19</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col12" class="data row28 col12" >0.036</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col13" class="data row28 col13" >-0.47</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col14" class="data row28 col14" >-0.24</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col15" class="data row28 col15" >0.069</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col16" class="data row28 col16" >0.18</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col17" class="data row28 col17" >-0.097</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col18" class="data row28 col18" >-0.15</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col19" class="data row28 col19" >-0.54</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col20" class="data row28 col20" >-0.48</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col21" class="data row28 col21" >-0.22</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col22" class="data row28 col22" >-0.19</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col23" class="data row28 col23" >0.39</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col24" class="data row28 col24" >-0.031</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col25" class="data row28 col25" >0.051</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col26" class="data row28 col26" >-0.0076</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col27" class="data row28 col27" >0.034</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col28" class="data row28 col28" >1</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col29" class="data row28 col29" >0.59</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow28_col30" class="data row28 col30" >0.47</td> 
    </tr>    <tr> 
        <th id="T_e4735428_48da_11e9_a17a_48d224c0b2dflevel0_row29" class="row_heading level0 row29" >Age_Remod</th> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col0" class="data row29 col0" >-0.079</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col1" class="data row29 col1" >-0.015</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col2" class="data row29 col2" >-0.18</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col3" class="data row29 col3" >-0.13</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col4" class="data row29 col4" >0.07</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col5" class="data row29 col5" >-0.18</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col6" class="data row29 col6" >-0.29</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col7" class="data row29 col7" >-0.24</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col8" class="data row29 col8" >-0.14</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col9" class="data row29 col9" >0.061</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col10" class="data row29 col10" >-0.29</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col11" class="data row29 col11" >-0.12</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col12" class="data row29 col12" >0.0092</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col13" class="data row29 col13" >-0.44</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col14" class="data row29 col14" >-0.18</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col15" class="data row29 col15" >0.038</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col16" class="data row29 col16" >0.15</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col17" class="data row29 col17" >-0.19</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col18" class="data row29 col18" >-0.11</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col19" class="data row29 col19" >-0.42</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col20" class="data row29 col20" >-0.37</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col21" class="data row29 col21" >-0.2</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col22" class="data row29 col22" >-0.23</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col23" class="data row29 col23" >0.19</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col24" class="data row29 col24" >-0.044</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col25" class="data row29 col25" >0.039</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col26" class="data row29 col26" >-0.0097</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col27" class="data row29 col27" >0.011</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col28" class="data row29 col28" >0.59</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col29" class="data row29 col29" >1</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow29_col30" class="data row29 col30" >0.3</td> 
    </tr>    <tr> 
        <th id="T_e4735428_48da_11e9_a17a_48d224c0b2dflevel0_row30" class="row_heading level0 row30" >Age_Garage</th> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col0" class="data row30 col0" >0.079</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col1" class="data row30 col1" >0.0028</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col2" class="data row30 col2" >-0.14</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col3" class="data row30 col3" >-0.12</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col4" class="data row30 col4" >-0.011</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col5" class="data row30 col5" >-0.0062</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col6" class="data row30 col6" >-0.14</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col7" class="data row30 col7" >-0.1</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col8" class="data row30 col8" >-0.067</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col9" class="data row30 col9" >0.076</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col10" class="data row30 col10" >-0.12</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col11" class="data row30 col11" >-0.1</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col12" class="data row30 col12" >0.0059</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col13" class="data row30 col13" >-0.25</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col14" class="data row30 col14" >-0.15</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col15" class="data row30 col15" >0.017</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col16" class="data row30 col16" >0.12</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col17" class="data row30 col17" >-0.057</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col18" class="data row30 col18" >-0.11</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col19" class="data row30 col19" >-0.48</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col20" class="data row30 col20" >-0.44</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col21" class="data row30 col21" >-0.2</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col22" class="data row30 col22" >-0.055</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col23" class="data row30 col23" >0.18</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col24" class="data row30 col24" >-0.0059</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col25" class="data row30 col25" >0.019</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col26" class="data row30 col26" >0.013</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col27" class="data row30 col27" >0.0092</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col28" class="data row30 col28" >0.47</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col29" class="data row30 col29" >0.3</td> 
        <td id="T_e4735428_48da_11e9_a17a_48d224c0b2dfrow30_col30" class="data row30 col30" >1</td> 
    </tr></tbody> 
</table> 



As we can see, the correlation matrix is large and the task to find correlated variables might prove tedious. So, we will use some basic programming to extract correlated variable pairs and ultimately the variable to drop.


```python
corr_var = []
for c in corr_mat.columns:
    for r in corr_mat.index:
        if ((corr_mat.loc[c, r] >= 0.5) | (corr_mat.loc[c, r] <= -0.5)) & (c != r):
            corr_var.append(list([c, r]))
            
for i in range(len(corr_var)):
    corr_var[i].sort()
    
temp = []
for e in corr_var:
    if e not in temp:
        temp.append(e)

corr_var = temp
del(temp) # removing unnecessary variable

# extracting data for dataframe
corr_var_1, corr_var_2, corr_val = [], [], []
for e in corr_var:
    corr_var_1.append(e[0])
    corr_var_2.append(e[1])
    corr_val.append(round(corr_mat.loc[e[0], e[1]], 2))

rcum_1, rcum_2 = [], []
for e in corr_var_1:
    rcum_1.append(round((corr_mat[e].sum() - 1), 2))
    
for e in corr_var_2:
    rcum_2.append(round((corr_mat[e].sum() - 1), 2))

# creating dataframe
corr_df = pd.DataFrame({'r': corr_val, 'Var_1': corr_var_1, 'rcum_Var_1':rcum_1, 'Var_2':corr_var_2, 'rcum_Var_2':rcum_2})
corr_df['Var_to_Remove'] = np.where((corr_df['rcum_Var_1']) > (corr_df['rcum_Var_2']), corr_df['Var_1'], corr_df['Var_2'])
corr_df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>r</th>
      <th>Var_1</th>
      <th>rcum_Var_1</th>
      <th>Var_2</th>
      <th>rcum_Var_2</th>
      <th>Var_to_Remove</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0.52</td>
      <td>BsmtFinSF1</td>
      <td>2.34</td>
      <td>TotalBsmtSF</td>
      <td>4.87</td>
      <td>TotalBsmtSF</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0.65</td>
      <td>BsmtFinSF1</td>
      <td>2.34</td>
      <td>BsmtFullBath</td>
      <td>0.82</td>
      <td>BsmtFinSF1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0.82</td>
      <td>1stFlrSF</td>
      <td>5.38</td>
      <td>TotalBsmtSF</td>
      <td>4.87</td>
      <td>1stFlrSF</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0.57</td>
      <td>1stFlrSF</td>
      <td>5.38</td>
      <td>GrLivArea</td>
      <td>7.32</td>
      <td>GrLivArea</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0.69</td>
      <td>2ndFlrSF</td>
      <td>3.20</td>
      <td>GrLivArea</td>
      <td>7.32</td>
      <td>GrLivArea</td>
    </tr>
    <tr>
      <th>5</th>
      <td>0.61</td>
      <td>2ndFlrSF</td>
      <td>3.20</td>
      <td>HalfBath</td>
      <td>1.88</td>
      <td>2ndFlrSF</td>
    </tr>
    <tr>
      <th>6</th>
      <td>0.50</td>
      <td>2ndFlrSF</td>
      <td>3.20</td>
      <td>BedroomAbvGr</td>
      <td>3.74</td>
      <td>BedroomAbvGr</td>
    </tr>
    <tr>
      <th>7</th>
      <td>0.62</td>
      <td>2ndFlrSF</td>
      <td>3.20</td>
      <td>TotRmsAbvGrd</td>
      <td>6.22</td>
      <td>TotRmsAbvGrd</td>
    </tr>
    <tr>
      <th>8</th>
      <td>0.63</td>
      <td>FullBath</td>
      <td>3.97</td>
      <td>GrLivArea</td>
      <td>7.32</td>
      <td>GrLivArea</td>
    </tr>
    <tr>
      <th>9</th>
      <td>0.52</td>
      <td>BedroomAbvGr</td>
      <td>3.74</td>
      <td>GrLivArea</td>
      <td>7.32</td>
      <td>GrLivArea</td>
    </tr>
    <tr>
      <th>10</th>
      <td>0.83</td>
      <td>GrLivArea</td>
      <td>7.32</td>
      <td>TotRmsAbvGrd</td>
      <td>6.22</td>
      <td>GrLivArea</td>
    </tr>
    <tr>
      <th>11</th>
      <td>0.55</td>
      <td>FullBath</td>
      <td>3.97</td>
      <td>TotRmsAbvGrd</td>
      <td>6.22</td>
      <td>TotRmsAbvGrd</td>
    </tr>
    <tr>
      <th>12</th>
      <td>0.68</td>
      <td>BedroomAbvGr</td>
      <td>3.74</td>
      <td>TotRmsAbvGrd</td>
      <td>6.22</td>
      <td>TotRmsAbvGrd</td>
    </tr>
    <tr>
      <th>13</th>
      <td>0.88</td>
      <td>GarageArea</td>
      <td>4.12</td>
      <td>GarageCars</td>
      <td>3.81</td>
      <td>GarageArea</td>
    </tr>
    <tr>
      <th>14</th>
      <td>-0.54</td>
      <td>Age_House</td>
      <td>-2.21</td>
      <td>GarageCars</td>
      <td>3.81</td>
      <td>GarageCars</td>
    </tr>
    <tr>
      <th>15</th>
      <td>0.59</td>
      <td>Age_House</td>
      <td>-2.21</td>
      <td>Age_Remod</td>
      <td>-2.42</td>
      <td>Age_House</td>
    </tr>
  </tbody>
</table>
</div>




```python
var_drop = list(set(corr_df['Var_to_Remove']))
print(train.shape, test.shape, sep = '\n')
train = train.drop(var_drop, axis = 1)
test  = test.drop(var_drop, axis = 1)
print(train.shape, test.shape, sep = '\n')
```

    (1459, 71) (1446, 70) 
    
    (1459, 61)
    (1446, 60)
    

We will also update the list of numeric variables accordingly.


```python
for e in var_drop:
    numeric.remove(e)
```

#### 2.3.2 Skewed Variables

We will now plot distributions for variables having skewness greater than 0.75.


```python
from scipy.stats import skew
skew_val = train[numeric].skew()
skew_75 = list(skew_val[skew_val > 0.75].index)
print(skew_75)
skew_val[skew_75].sort_values(ascending = False)
```

    ['LotArea', 'MasVnrArea', 'BsmtFinSF2', 'BsmtUnfSF', 'LowQualFinSF', 'BsmtHalfBath', 'KitchenAbvGr', 'WoodDeckSF', 'OpenPorchSF', 'EnclosedPorch', '3SsnPorch', 'ScreenPorch', 'PoolArea', 'MiscVal', 'Age_Garage']
    




    MiscVal          24.468441
    PoolArea         14.823236
    LotArea          12.203431
    3SsnPorch        10.300725
    LowQualFinSF      9.008149
    KitchenAbvGr      4.486640
    BsmtFinSF2        4.253594
    ScreenPorch       4.120572
    BsmtHalfBath      4.101759
    EnclosedPorch     3.088518
    MasVnrArea        2.676551
    OpenPorchSF       2.363530
    WoodDeckSF        1.540947
    BsmtUnfSF         0.919312
    Age_Garage        0.764418
    dtype: float64




```python
plt.style.use('seaborn')
train[skew_75].hist(figsize = (24, 30)); # ; for supressing the array information
```


![png](output_91_0.png)


Looking at the distribution of these highly skewed variables, some of them are tending towards singularity i.e. tending to have a high percentage of similar values. Let's check the count and numeric distribution of those variables that have skewness over 5.


```python
for e in skew_val[skew_val > 5].index:
    print(e, ('-'*len(e)), (train[e].value_counts().head() / len(train)) * 100, sep = '\n')
    print('\n#############################################\n')
```

    LotArea
    -------
    7200     1.713502
    9600     1.644962
    6000     1.165182
    9000     0.959561
    10800    0.959561
    Name: LotArea, dtype: float64
    
    #############################################
    
    LowQualFinSF
    ------------
    0      98.217958
    80      0.205620
    360     0.137080
    528     0.068540
    53      0.068540
    Name: LowQualFinSF, dtype: float64
    
    #############################################
    
    3SsnPorch
    ---------
    0      98.355038
    168     0.205620
    216     0.137080
    144     0.137080
    180     0.137080
    Name: 3SsnPorch, dtype: float64
    
    #############################################
    
    PoolArea
    --------
    0      99.520219
    738     0.068540
    648     0.068540
    576     0.068540
    555     0.068540
    Name: PoolArea, dtype: float64
    
    #############################################
    
    MiscVal
    -------
    0      96.435915
    400     0.753941
    500     0.548321
    700     0.342700
    450     0.274160
    Name: MiscVal, dtype: float64
    
    #############################################
    
    

As can be seen, we have four variables with over 95% of distribution being occupied by 0. We will remove these variables from our data set.


```python
train = train.drop(['LowQualFinSF', '3SsnPorch', 'PoolArea', 'MiscVal'], axis = 1)
train.shape
```




    (1459, 57)




```python
test = test.drop(['LowQualFinSF', '3SsnPorch', 'PoolArea', 'MiscVal'], axis = 1)
test.shape
```




    (1446, 56)



We will now transform the remaining skewed variables using the 'log + 1' transformation.


```python
for e in ['LowQualFinSF', '3SsnPorch', 'PoolArea', 'MiscVal']:
    skew_75.remove(e)

for e in skew_75:
    train[e] = np.log1p(train[e])
    test[e] = np.log1p(test[e])
    
train[skew_75].hist(figsize = (16, 20));
```


![png](output_98_0.png)


Now that we have cleaned our data, we will rename our dataset to df and create the df_x and df_y sets as well as extract column names to work with our data more efficiently.


```python
train_id = train['Id'] # extracting for future use, if needed
df = train.drop(['Id'], axis = 1)
df_y = df['SalePrice']
df_x = df.drop(['SalePrice'], axis = 1)
cols = df_x.columns
cols_num, cols_cat = [], []
for e in cols:
    if df_x[e].dtype in ('float64', 'int64'):
        cols_num.append(e)
    else:
        cols_cat.append(e)
```

### 3. Exploratory Data Analysis
#### 3.1 Categorical Variables


```python
plt.rcParams['figure.figsize'] = [20, 10]
for e in cols_cat:
    sns.barplot(x = df_x[e], y = df_y);
    plt.show()
```


![png](output_102_0.png)



![png](output_102_1.png)



![png](output_102_2.png)



![png](output_102_3.png)



![png](output_102_4.png)



![png](output_102_5.png)



![png](output_102_6.png)



![png](output_102_7.png)



![png](output_102_8.png)



![png](output_102_9.png)



![png](output_102_10.png)



![png](output_102_11.png)



![png](output_102_12.png)



![png](output_102_13.png)



![png](output_102_14.png)



![png](output_102_15.png)



![png](output_102_16.png)



![png](output_102_17.png)



![png](output_102_18.png)



![png](output_102_19.png)



![png](output_102_20.png)



![png](output_102_21.png)



![png](output_102_22.png)



![png](output_102_23.png)



![png](output_102_24.png)



![png](output_102_25.png)



![png](output_102_26.png)



![png](output_102_27.png)



![png](output_102_28.png)



![png](output_102_29.png)



![png](output_102_30.png)



![png](output_102_31.png)



![png](output_102_32.png)



![png](output_102_33.png)



![png](output_102_34.png)



![png](output_102_35.png)



![png](output_102_36.png)



![png](output_102_37.png)


#### 3.2 Numerical Variables


```python
plt.rcParams['figure.figsize'] = [10, 10]
for e in cols_num:
    sns.regplot(x = df_x[e], y = df_y, line_kws = {'color':'red'});
    plt.show()
```


![png](output_104_0.png)



![png](output_104_1.png)



![png](output_104_2.png)



![png](output_104_3.png)



![png](output_104_4.png)



![png](output_104_5.png)



![png](output_104_6.png)



![png](output_104_7.png)



![png](output_104_8.png)



![png](output_104_9.png)



![png](output_104_10.png)



![png](output_104_11.png)



![png](output_104_12.png)



![png](output_104_13.png)



![png](output_104_14.png)



![png](output_104_15.png)



![png](output_104_16.png)


All the graphs above are pretty self-explanatory and the trend seems to be inline with what the popular market beliefs are (older the house, lower the cost and so on). We will now move on to build our base model.

### 4. Model Building

We will be using Linear Regression for this particular problem. Before building our model though, we will need to prep our data set a bit more so as to pass it on to our models.

#### 4.1 Data Prep for Model
#### 4.1.1 Dummy Variables
The linear regression model in the scipy library needs all data in numeric form. So, we will have to convert our categorical variables into dummy variables. Let's go ahead and do that.


```python
test.shape
```




    (1446, 56)




```python
df = pd.get_dummies(df, columns = cols_cat, drop_first = True)
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>LotFrontage</th>
      <th>LotArea</th>
      <th>MasVnrArea</th>
      <th>BsmtFinSF2</th>
      <th>BsmtUnfSF</th>
      <th>BsmtFullBath</th>
      <th>BsmtHalfBath</th>
      <th>FullBath</th>
      <th>HalfBath</th>
      <th>KitchenAbvGr</th>
      <th>Fireplaces</th>
      <th>WoodDeckSF</th>
      <th>OpenPorchSF</th>
      <th>EnclosedPorch</th>
      <th>ScreenPorch</th>
      <th>SalePrice</th>
      <th>Age_Remod</th>
      <th>Age_Garage</th>
      <th>MSSubClass_160</th>
      <th>MSSubClass_180</th>
      <th>MSSubClass_190</th>
      <th>MSSubClass_20</th>
      <th>MSSubClass_30</th>
      <th>MSSubClass_40</th>
      <th>MSSubClass_45</th>
      <th>MSSubClass_50</th>
      <th>MSSubClass_60</th>
      <th>MSSubClass_70</th>
      <th>MSSubClass_75</th>
      <th>MSSubClass_80</th>
      <th>MSSubClass_85</th>
      <th>MSSubClass_90</th>
      <th>MSZoning_FV</th>
      <th>MSZoning_R</th>
      <th>Street_Pave</th>
      <th>LotShape_Reg</th>
      <th>LandContour_N Lvl</th>
      <th>LotConfig_CulDSac</th>
      <th>LotConfig_FR</th>
      <th>LotConfig_Inside</th>
      <th>LandSlope_Low</th>
      <th>Neighborhood_Blueste</th>
      <th>Neighborhood_BrDale</th>
      <th>Neighborhood_BrkSide</th>
      <th>Neighborhood_ClearCr</th>
      <th>Neighborhood_CollgCr</th>
      <th>Neighborhood_Crawfor</th>
      <th>Neighborhood_Edwards</th>
      <th>Neighborhood_Gilbert</th>
      <th>Neighborhood_IDOTRR</th>
      <th>Neighborhood_MeadowV</th>
      <th>Neighborhood_Mitchel</th>
      <th>Neighborhood_NAmes</th>
      <th>Neighborhood_NPkVill</th>
      <th>Neighborhood_NWAmes</th>
      <th>Neighborhood_NoRidge</th>
      <th>Neighborhood_NridgHt</th>
      <th>Neighborhood_OldTown</th>
      <th>Neighborhood_SWISU</th>
      <th>Neighborhood_Sawyer</th>
      <th>Neighborhood_SawyerW</th>
      <th>Neighborhood_Somerst</th>
      <th>Neighborhood_StoneBr</th>
      <th>Neighborhood_Timber</th>
      <th>Neighborhood_Veenker</th>
      <th>Condition1_Feedr</th>
      <th>Condition1_Norm</th>
      <th>Condition1_Pos</th>
      <th>Condition1_RR</th>
      <th>BldgType_2fmCon</th>
      <th>BldgType_Duplex</th>
      <th>BldgType_Twnhs</th>
      <th>BldgType_TwnhsE</th>
      <th>HouseStyle_1.5</th>
      <th>HouseStyle_2+</th>
      <th>HouseStyle_Split</th>
      <th>OverallQual_Low</th>
      <th>OverallQual_Med</th>
      <th>OverallCond_Bad</th>
      <th>OverallCond_Good</th>
      <th>RoofStyle_Hip</th>
      <th>RoofStyle_Others</th>
      <th>Exterior1st_HdBoard</th>
      <th>Exterior1st_MetalSd</th>
      <th>Exterior1st_Others</th>
      <th>Exterior1st_Plywood</th>
      <th>Exterior1st_VinylSd</th>
      <th>Exterior1st_Wd Sdng</th>
      <th>Exterior2nd_HdBoard</th>
      <th>Exterior2nd_MetalSd</th>
      <th>Exterior2nd_Others</th>
      <th>Exterior2nd_Plywood</th>
      <th>Exterior2nd_VinylSd</th>
      <th>Exterior2nd_Wd Sdng</th>
      <th>MasVnrType_None</th>
      <th>MasVnrType_Stone</th>
      <th>ExterQual_Low</th>
      <th>ExterCond_Low</th>
      <th>Foundation_CBlock</th>
      <th>Foundation_Other</th>
      <th>Foundation_PConc</th>
      <th>BsmtQual_Low</th>
      <th>BsmtQual_None</th>
      <th>BsmtCond_Low</th>
      <th>BsmtCond_None</th>
      <th>BsmtExposure_Gd</th>
      <th>BsmtExposure_Mn</th>
      <th>BsmtExposure_No</th>
      <th>BsmtExposure_None</th>
      <th>BsmtFinType1_BLQ</th>
      <th>BsmtFinType1_GLQ</th>
      <th>BsmtFinType1_LwQ</th>
      <th>BsmtFinType1_None</th>
      <th>BsmtFinType1_Rec</th>
      <th>BsmtFinType1_Unf</th>
      <th>BsmtFinType2_BLQ</th>
      <th>BsmtFinType2_GLQ</th>
      <th>BsmtFinType2_LwQ</th>
      <th>BsmtFinType2_None</th>
      <th>BsmtFinType2_Rec</th>
      <th>BsmtFinType2_Unf</th>
      <th>HeatingQC_Low</th>
      <th>HeatingQC_Med</th>
      <th>CentralAir_Y</th>
      <th>Electrical_SBrkr</th>
      <th>KitchenQual_Low</th>
      <th>KitchenQual_Med</th>
      <th>FireplaceQu_Low</th>
      <th>FireplaceQu_None</th>
      <th>GarageType_Detchd</th>
      <th>GarageType_None</th>
      <th>GarageFinish_None</th>
      <th>GarageFinish_RFn</th>
      <th>GarageFinish_Unf</th>
      <th>GarageQual_Low</th>
      <th>GarageQual_None</th>
      <th>GarageCond_Low</th>
      <th>GarageCond_None</th>
      <th>Fence_GdWo</th>
      <th>Fence_MnPrv</th>
      <th>Fence_MnWw</th>
      <th>Fence_None</th>
      <th>SaleType_Other</th>
      <th>SaleType_WD</th>
      <th>SaleCondition_Normal</th>
      <th>SaleCondition_Other</th>
      <th>SaleCondition_Partial</th>
      <th>SznSold_Spring</th>
      <th>SznSold_Summer</th>
      <th>SznSold_Winter</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>65.0</td>
      <td>9.042040</td>
      <td>5.283204</td>
      <td>0.0</td>
      <td>5.017280</td>
      <td>1</td>
      <td>0.000000</td>
      <td>2</td>
      <td>1</td>
      <td>0.693147</td>
      <td>0</td>
      <td>0.000000</td>
      <td>4.127134</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>208500</td>
      <td>5</td>
      <td>1.791759</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>80.0</td>
      <td>9.169623</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>5.652489</td>
      <td>0</td>
      <td>0.693147</td>
      <td>2</td>
      <td>0</td>
      <td>0.693147</td>
      <td>1</td>
      <td>5.700444</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>181500</td>
      <td>31</td>
      <td>3.465736</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>68.0</td>
      <td>9.328212</td>
      <td>5.093750</td>
      <td>0.0</td>
      <td>6.075346</td>
      <td>1</td>
      <td>0.000000</td>
      <td>2</td>
      <td>1</td>
      <td>0.693147</td>
      <td>1</td>
      <td>0.000000</td>
      <td>3.761200</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>223500</td>
      <td>6</td>
      <td>2.079442</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>60.0</td>
      <td>9.164401</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>6.293419</td>
      <td>1</td>
      <td>0.000000</td>
      <td>1</td>
      <td>0</td>
      <td>0.693147</td>
      <td>1</td>
      <td>0.000000</td>
      <td>3.583519</td>
      <td>5.609472</td>
      <td>0.0</td>
      <td>140000</td>
      <td>36</td>
      <td>2.197225</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4</th>
      <td>84.0</td>
      <td>9.565284</td>
      <td>5.860786</td>
      <td>0.0</td>
      <td>6.196444</td>
      <td>1</td>
      <td>0.000000</td>
      <td>2</td>
      <td>1</td>
      <td>0.693147</td>
      <td>1</td>
      <td>5.262690</td>
      <td>4.442651</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>250000</td>
      <td>8</td>
      <td>2.197225</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.shape
```




    (1459, 150)




```python
test = pd.get_dummies(test, columns = cols_cat, drop_first = True)
```


    ---------------------------------------------------------------------------

    KeyError                                  Traceback (most recent call last)

    <ipython-input-1221-e3bcb78bc043> in <module>
    ----> 1 test = pd.get_dummies(test, columns = cols_cat, drop_first = True)
    

    C:\ProgramData\Anaconda3\lib\site-packages\pandas\core\reshape\reshape.py in get_dummies(data, prefix, prefix_sep, dummy_na, columns, sparse, drop_first, dtype)
        842                 include=dtypes_to_encode)
        843         else:
    --> 844             data_to_encode = data[columns]
        845 
        846         # validate prefixes and separator to avoid silently dropping cols
    

    C:\ProgramData\Anaconda3\lib\site-packages\pandas\core\frame.py in __getitem__(self, key)
       2680         if isinstance(key, (Series, np.ndarray, Index, list)):
       2681             # either boolean or fancy integer index
    -> 2682             return self._getitem_array(key)
       2683         elif isinstance(key, DataFrame):
       2684             return self._getitem_frame(key)
    

    C:\ProgramData\Anaconda3\lib\site-packages\pandas\core\frame.py in _getitem_array(self, key)
       2724             return self._take(indexer, axis=0)
       2725         else:
    -> 2726             indexer = self.loc._convert_to_indexer(key, axis=1)
       2727             return self._take(indexer, axis=1)
       2728 
    

    C:\ProgramData\Anaconda3\lib\site-packages\pandas\core\indexing.py in _convert_to_indexer(self, obj, axis, is_setter)
       1325                 if mask.any():
       1326                     raise KeyError('{mask} not in index'
    -> 1327                                    .format(mask=objarr[mask]))
       1328 
       1329                 return com._values_from_object(indexer)
    

    KeyError: "['MSSubClass' 'MSZoning' 'Street' 'LotShape' 'LandContour' 'LotConfig'\n 'LandSlope' 'Neighborhood' 'Condition1' 'BldgType' 'HouseStyle'\n 'OverallQual' 'OverallCond' 'RoofStyle' 'Exterior1st' 'Exterior2nd'\n 'MasVnrType' 'ExterQual' 'ExterCond' 'Foundation' 'BsmtQual' 'BsmtCond'\n 'BsmtExposure' 'BsmtFinType1' 'BsmtFinType2' 'HeatingQC' 'CentralAir'\n 'Electrical' 'KitchenQual' 'FireplaceQu' 'GarageType' 'GarageFinish'\n 'GarageQual' 'GarageCond' 'Fence' 'SaleType' 'SaleCondition' 'SznSold'] not in index"


#### 4.1.2 Splitting the Data
We will now split our dataset into train and test tests.


```python
from sklearn.model_selection import train_test_split
df_train, df_test = train_test_split(df, test_size = 0.3)
print(df_train.shape, df_test.shape, sep = '\n')
```

    (1021, 150)
    (438, 150)
    

We will now split our train and test sets into x and y sets as well.


```python
df_train_y = df_train['SalePrice']
df_train_x = df_train.drop(['SalePrice'], axis = 1)
df_test_y = df_test['SalePrice']
df_test_x = df_test.drop(['SalePrice'], axis = 1)
print(df_train_x.shape, df_train_y.shape, df_test_x.shape, df_test_y.shape, sep = '\n')
```

    (1021, 149)
    (1021,)
    (438, 149)
    (438,)
    

#### 4.1.3 Adding the Constant term
We will also need to add the constant (intercept) term to each of the \_x datasets


```python
import statsmodels.api as sm
df_train_x = sm.add_constant(df_train_x)
df_train_x.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>const</th>
      <th>LotFrontage</th>
      <th>LotArea</th>
      <th>MasVnrArea</th>
      <th>BsmtFinSF2</th>
      <th>BsmtUnfSF</th>
      <th>BsmtFullBath</th>
      <th>BsmtHalfBath</th>
      <th>FullBath</th>
      <th>HalfBath</th>
      <th>KitchenAbvGr</th>
      <th>Fireplaces</th>
      <th>WoodDeckSF</th>
      <th>OpenPorchSF</th>
      <th>EnclosedPorch</th>
      <th>ScreenPorch</th>
      <th>Age_Remod</th>
      <th>Age_Garage</th>
      <th>MSSubClass_160</th>
      <th>MSSubClass_180</th>
      <th>MSSubClass_190</th>
      <th>MSSubClass_20</th>
      <th>MSSubClass_30</th>
      <th>MSSubClass_40</th>
      <th>MSSubClass_45</th>
      <th>MSSubClass_50</th>
      <th>MSSubClass_60</th>
      <th>MSSubClass_70</th>
      <th>MSSubClass_75</th>
      <th>MSSubClass_80</th>
      <th>MSSubClass_85</th>
      <th>MSSubClass_90</th>
      <th>MSZoning_FV</th>
      <th>MSZoning_R</th>
      <th>Street_Pave</th>
      <th>LotShape_Reg</th>
      <th>LandContour_N Lvl</th>
      <th>LotConfig_CulDSac</th>
      <th>LotConfig_FR</th>
      <th>LotConfig_Inside</th>
      <th>LandSlope_Low</th>
      <th>Neighborhood_Blueste</th>
      <th>Neighborhood_BrDale</th>
      <th>Neighborhood_BrkSide</th>
      <th>Neighborhood_ClearCr</th>
      <th>Neighborhood_CollgCr</th>
      <th>Neighborhood_Crawfor</th>
      <th>Neighborhood_Edwards</th>
      <th>Neighborhood_Gilbert</th>
      <th>Neighborhood_IDOTRR</th>
      <th>Neighborhood_MeadowV</th>
      <th>Neighborhood_Mitchel</th>
      <th>Neighborhood_NAmes</th>
      <th>Neighborhood_NPkVill</th>
      <th>Neighborhood_NWAmes</th>
      <th>Neighborhood_NoRidge</th>
      <th>Neighborhood_NridgHt</th>
      <th>Neighborhood_OldTown</th>
      <th>Neighborhood_SWISU</th>
      <th>Neighborhood_Sawyer</th>
      <th>Neighborhood_SawyerW</th>
      <th>Neighborhood_Somerst</th>
      <th>Neighborhood_StoneBr</th>
      <th>Neighborhood_Timber</th>
      <th>Neighborhood_Veenker</th>
      <th>Condition1_Feedr</th>
      <th>Condition1_Norm</th>
      <th>Condition1_Pos</th>
      <th>Condition1_RR</th>
      <th>BldgType_2fmCon</th>
      <th>BldgType_Duplex</th>
      <th>BldgType_Twnhs</th>
      <th>BldgType_TwnhsE</th>
      <th>HouseStyle_1.5</th>
      <th>HouseStyle_2+</th>
      <th>HouseStyle_Split</th>
      <th>OverallQual_Low</th>
      <th>OverallQual_Med</th>
      <th>OverallCond_Bad</th>
      <th>OverallCond_Good</th>
      <th>RoofStyle_Hip</th>
      <th>RoofStyle_Others</th>
      <th>Exterior1st_HdBoard</th>
      <th>Exterior1st_MetalSd</th>
      <th>Exterior1st_Others</th>
      <th>Exterior1st_Plywood</th>
      <th>Exterior1st_VinylSd</th>
      <th>Exterior1st_Wd Sdng</th>
      <th>Exterior2nd_HdBoard</th>
      <th>Exterior2nd_MetalSd</th>
      <th>Exterior2nd_Others</th>
      <th>Exterior2nd_Plywood</th>
      <th>Exterior2nd_VinylSd</th>
      <th>Exterior2nd_Wd Sdng</th>
      <th>MasVnrType_None</th>
      <th>MasVnrType_Stone</th>
      <th>ExterQual_Low</th>
      <th>ExterCond_Low</th>
      <th>Foundation_CBlock</th>
      <th>Foundation_Other</th>
      <th>Foundation_PConc</th>
      <th>BsmtQual_Low</th>
      <th>BsmtQual_None</th>
      <th>BsmtCond_Low</th>
      <th>BsmtCond_None</th>
      <th>BsmtExposure_Gd</th>
      <th>BsmtExposure_Mn</th>
      <th>BsmtExposure_No</th>
      <th>BsmtExposure_None</th>
      <th>BsmtFinType1_BLQ</th>
      <th>BsmtFinType1_GLQ</th>
      <th>BsmtFinType1_LwQ</th>
      <th>BsmtFinType1_None</th>
      <th>BsmtFinType1_Rec</th>
      <th>BsmtFinType1_Unf</th>
      <th>BsmtFinType2_BLQ</th>
      <th>BsmtFinType2_GLQ</th>
      <th>BsmtFinType2_LwQ</th>
      <th>BsmtFinType2_None</th>
      <th>BsmtFinType2_Rec</th>
      <th>BsmtFinType2_Unf</th>
      <th>HeatingQC_Low</th>
      <th>HeatingQC_Med</th>
      <th>CentralAir_Y</th>
      <th>Electrical_SBrkr</th>
      <th>KitchenQual_Low</th>
      <th>KitchenQual_Med</th>
      <th>FireplaceQu_Low</th>
      <th>FireplaceQu_None</th>
      <th>GarageType_Detchd</th>
      <th>GarageType_None</th>
      <th>GarageFinish_None</th>
      <th>GarageFinish_RFn</th>
      <th>GarageFinish_Unf</th>
      <th>GarageQual_Low</th>
      <th>GarageQual_None</th>
      <th>GarageCond_Low</th>
      <th>GarageCond_None</th>
      <th>Fence_GdWo</th>
      <th>Fence_MnPrv</th>
      <th>Fence_MnWw</th>
      <th>Fence_None</th>
      <th>SaleType_Other</th>
      <th>SaleType_WD</th>
      <th>SaleCondition_Normal</th>
      <th>SaleCondition_Other</th>
      <th>SaleCondition_Partial</th>
      <th>SznSold_Spring</th>
      <th>SznSold_Summer</th>
      <th>SznSold_Winter</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>757</th>
      <td>1.0</td>
      <td>0.0</td>
      <td>9.360225</td>
      <td>5.796058</td>
      <td>0.0</td>
      <td>5.459586</td>
      <td>0</td>
      <td>0.0</td>
      <td>2</td>
      <td>1</td>
      <td>0.693147</td>
      <td>1</td>
      <td>5.817111</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>32</td>
      <td>3.496508</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>883</th>
      <td>1.0</td>
      <td>60.0</td>
      <td>8.733111</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>6.679599</td>
      <td>1</td>
      <td>0.0</td>
      <td>1</td>
      <td>0</td>
      <td>0.693147</td>
      <td>0</td>
      <td>0.000000</td>
      <td>5.241747</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>56</td>
      <td>2.302585</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>353</th>
      <td>1.0</td>
      <td>60.0</td>
      <td>9.050289</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>6.437752</td>
      <td>0</td>
      <td>0.0</td>
      <td>1</td>
      <td>0</td>
      <td>0.693147</td>
      <td>0</td>
      <td>4.672829</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>7</td>
      <td>1.791759</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>420</th>
      <td>1.0</td>
      <td>78.0</td>
      <td>8.862342</td>
      <td>5.303305</td>
      <td>0.0</td>
      <td>3.583519</td>
      <td>2</td>
      <td>0.0</td>
      <td>2</td>
      <td>0</td>
      <td>1.098612</td>
      <td>0</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>10</td>
      <td>2.484907</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1430</th>
      <td>1.0</td>
      <td>60.0</td>
      <td>9.995656</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>6.597146</td>
      <td>0</td>
      <td>0.0</td>
      <td>2</td>
      <td>1</td>
      <td>0.693147</td>
      <td>1</td>
      <td>4.615121</td>
      <td>3.713572</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1</td>
      <td>0.693147</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
df_test_x['const'] = 1
df_test_x = pd.concat([df_test_x['const'], df_test_x.drop('const', axis = 1)], axis = 1)
df_test_x.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>const</th>
      <th>LotFrontage</th>
      <th>LotArea</th>
      <th>MasVnrArea</th>
      <th>BsmtFinSF2</th>
      <th>BsmtUnfSF</th>
      <th>BsmtFullBath</th>
      <th>BsmtHalfBath</th>
      <th>FullBath</th>
      <th>HalfBath</th>
      <th>KitchenAbvGr</th>
      <th>Fireplaces</th>
      <th>WoodDeckSF</th>
      <th>OpenPorchSF</th>
      <th>EnclosedPorch</th>
      <th>ScreenPorch</th>
      <th>Age_Remod</th>
      <th>Age_Garage</th>
      <th>MSSubClass_160</th>
      <th>MSSubClass_180</th>
      <th>MSSubClass_190</th>
      <th>MSSubClass_20</th>
      <th>MSSubClass_30</th>
      <th>MSSubClass_40</th>
      <th>MSSubClass_45</th>
      <th>MSSubClass_50</th>
      <th>MSSubClass_60</th>
      <th>MSSubClass_70</th>
      <th>MSSubClass_75</th>
      <th>MSSubClass_80</th>
      <th>MSSubClass_85</th>
      <th>MSSubClass_90</th>
      <th>MSZoning_FV</th>
      <th>MSZoning_R</th>
      <th>Street_Pave</th>
      <th>LotShape_Reg</th>
      <th>LandContour_N Lvl</th>
      <th>LotConfig_CulDSac</th>
      <th>LotConfig_FR</th>
      <th>LotConfig_Inside</th>
      <th>LandSlope_Low</th>
      <th>Neighborhood_Blueste</th>
      <th>Neighborhood_BrDale</th>
      <th>Neighborhood_BrkSide</th>
      <th>Neighborhood_ClearCr</th>
      <th>Neighborhood_CollgCr</th>
      <th>Neighborhood_Crawfor</th>
      <th>Neighborhood_Edwards</th>
      <th>Neighborhood_Gilbert</th>
      <th>Neighborhood_IDOTRR</th>
      <th>Neighborhood_MeadowV</th>
      <th>Neighborhood_Mitchel</th>
      <th>Neighborhood_NAmes</th>
      <th>Neighborhood_NPkVill</th>
      <th>Neighborhood_NWAmes</th>
      <th>Neighborhood_NoRidge</th>
      <th>Neighborhood_NridgHt</th>
      <th>Neighborhood_OldTown</th>
      <th>Neighborhood_SWISU</th>
      <th>Neighborhood_Sawyer</th>
      <th>Neighborhood_SawyerW</th>
      <th>Neighborhood_Somerst</th>
      <th>Neighborhood_StoneBr</th>
      <th>Neighborhood_Timber</th>
      <th>Neighborhood_Veenker</th>
      <th>Condition1_Feedr</th>
      <th>Condition1_Norm</th>
      <th>Condition1_Pos</th>
      <th>Condition1_RR</th>
      <th>BldgType_2fmCon</th>
      <th>BldgType_Duplex</th>
      <th>BldgType_Twnhs</th>
      <th>BldgType_TwnhsE</th>
      <th>HouseStyle_1.5</th>
      <th>HouseStyle_2+</th>
      <th>HouseStyle_Split</th>
      <th>OverallQual_Low</th>
      <th>OverallQual_Med</th>
      <th>OverallCond_Bad</th>
      <th>OverallCond_Good</th>
      <th>RoofStyle_Hip</th>
      <th>RoofStyle_Others</th>
      <th>Exterior1st_HdBoard</th>
      <th>Exterior1st_MetalSd</th>
      <th>Exterior1st_Others</th>
      <th>Exterior1st_Plywood</th>
      <th>Exterior1st_VinylSd</th>
      <th>Exterior1st_Wd Sdng</th>
      <th>Exterior2nd_HdBoard</th>
      <th>Exterior2nd_MetalSd</th>
      <th>Exterior2nd_Others</th>
      <th>Exterior2nd_Plywood</th>
      <th>Exterior2nd_VinylSd</th>
      <th>Exterior2nd_Wd Sdng</th>
      <th>MasVnrType_None</th>
      <th>MasVnrType_Stone</th>
      <th>ExterQual_Low</th>
      <th>ExterCond_Low</th>
      <th>Foundation_CBlock</th>
      <th>Foundation_Other</th>
      <th>Foundation_PConc</th>
      <th>BsmtQual_Low</th>
      <th>BsmtQual_None</th>
      <th>BsmtCond_Low</th>
      <th>BsmtCond_None</th>
      <th>BsmtExposure_Gd</th>
      <th>BsmtExposure_Mn</th>
      <th>BsmtExposure_No</th>
      <th>BsmtExposure_None</th>
      <th>BsmtFinType1_BLQ</th>
      <th>BsmtFinType1_GLQ</th>
      <th>BsmtFinType1_LwQ</th>
      <th>BsmtFinType1_None</th>
      <th>BsmtFinType1_Rec</th>
      <th>BsmtFinType1_Unf</th>
      <th>BsmtFinType2_BLQ</th>
      <th>BsmtFinType2_GLQ</th>
      <th>BsmtFinType2_LwQ</th>
      <th>BsmtFinType2_None</th>
      <th>BsmtFinType2_Rec</th>
      <th>BsmtFinType2_Unf</th>
      <th>HeatingQC_Low</th>
      <th>HeatingQC_Med</th>
      <th>CentralAir_Y</th>
      <th>Electrical_SBrkr</th>
      <th>KitchenQual_Low</th>
      <th>KitchenQual_Med</th>
      <th>FireplaceQu_Low</th>
      <th>FireplaceQu_None</th>
      <th>GarageType_Detchd</th>
      <th>GarageType_None</th>
      <th>GarageFinish_None</th>
      <th>GarageFinish_RFn</th>
      <th>GarageFinish_Unf</th>
      <th>GarageQual_Low</th>
      <th>GarageQual_None</th>
      <th>GarageCond_Low</th>
      <th>GarageCond_None</th>
      <th>Fence_GdWo</th>
      <th>Fence_MnPrv</th>
      <th>Fence_MnWw</th>
      <th>Fence_None</th>
      <th>SaleType_Other</th>
      <th>SaleType_WD</th>
      <th>SaleCondition_Normal</th>
      <th>SaleCondition_Other</th>
      <th>SaleCondition_Partial</th>
      <th>SznSold_Spring</th>
      <th>SznSold_Summer</th>
      <th>SznSold_Winter</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>477</th>
      <td>1</td>
      <td>105.0</td>
      <td>9.524713</td>
      <td>6.650279</td>
      <td>0.0</td>
      <td>7.675082</td>
      <td>0</td>
      <td>0.0</td>
      <td>2</td>
      <td>1</td>
      <td>0.693147</td>
      <td>1</td>
      <td>6.028279</td>
      <td>4.442651</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>1</td>
      <td>0.693147</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>310</th>
      <td>1</td>
      <td>0.0</td>
      <td>8.947156</td>
      <td>4.727388</td>
      <td>0.0</td>
      <td>5.192957</td>
      <td>0</td>
      <td>0.0</td>
      <td>2</td>
      <td>1</td>
      <td>0.693147</td>
      <td>1</td>
      <td>5.252273</td>
      <td>4.158883</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>12</td>
      <td>2.639057</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>797</th>
      <td>1</td>
      <td>57.0</td>
      <td>8.946114</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>5.318120</td>
      <td>0</td>
      <td>0.0</td>
      <td>1</td>
      <td>0</td>
      <td>0.693147</td>
      <td>0</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>55</td>
      <td>4.025352</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>794</th>
      <td>1</td>
      <td>0.0</td>
      <td>9.290352</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>6.569481</td>
      <td>0</td>
      <td>0.0</td>
      <td>2</td>
      <td>1</td>
      <td>0.693147</td>
      <td>1</td>
      <td>4.969813</td>
      <td>3.850148</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>12</td>
      <td>2.708050</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>246</th>
      <td>1</td>
      <td>69.0</td>
      <td>9.120744</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>6.928538</td>
      <td>0</td>
      <td>0.0</td>
      <td>2</td>
      <td>0</td>
      <td>1.098612</td>
      <td>0</td>
      <td>0.000000</td>
      <td>4.110874</td>
      <td>4.727388</td>
      <td>0.0</td>
      <td>56</td>
      <td>4.574711</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>



#### 4.2 Base Model
We will now build our base model. It will be a Linear Regression model built using the OLS method in statsmodel.api library.


```python
lm_base = sm.OLS(df_train_y, df_train_x).fit()
lm_base.summary()
```




<table class="simpletable">
<caption>OLS Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>        <td>SalePrice</td>    <th>  R-squared:         </th> <td>   0.875</td> 
</tr>
<tr>
  <th>Model:</th>                   <td>OLS</td>       <th>  Adj. R-squared:    </th> <td>   0.855</td> 
</tr>
<tr>
  <th>Method:</th>             <td>Least Squares</td>  <th>  F-statistic:       </th> <td>   43.38</td> 
</tr>
<tr>
  <th>Date:</th>             <td>Sun, 17 Mar 2019</td> <th>  Prob (F-statistic):</th> <td>2.22e-314</td>
</tr>
<tr>
  <th>Time:</th>                 <td>23:23:05</td>     <th>  Log-Likelihood:    </th> <td> -11906.</td> 
</tr>
<tr>
  <th>No. Observations:</th>      <td>  1021</td>      <th>  AIC:               </th> <td>2.410e+04</td>
</tr>
<tr>
  <th>Df Residuals:</th>          <td>   878</td>      <th>  BIC:               </th> <td>2.480e+04</td>
</tr>
<tr>
  <th>Df Model:</th>              <td>   142</td>      <th>                     </th>     <td> </td>    
</tr>
<tr>
  <th>Covariance Type:</th>      <td>nonrobust</td>    <th>                     </th>     <td> </td>    
</tr>
</table>
<table class="simpletable">
<tr>
            <td></td>               <th>coef</th>     <th>std err</th>      <th>t</th>      <th>P>|t|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>const</th>                 <td>-3.046e+04</td> <td> 6.22e+04</td> <td>   -0.490</td> <td> 0.624</td> <td>-1.52e+05</td> <td> 9.15e+04</td>
</tr>
<tr>
  <th>LotFrontage</th>           <td>  109.6984</td> <td>   34.535</td> <td>    3.176</td> <td> 0.002</td> <td>   41.918</td> <td>  177.478</td>
</tr>
<tr>
  <th>LotArea</th>               <td> 2.016e+04</td> <td> 3585.483</td> <td>    5.622</td> <td> 0.000</td> <td> 1.31e+04</td> <td> 2.72e+04</td>
</tr>
<tr>
  <th>MasVnrArea</th>            <td> 1419.1178</td> <td> 1760.097</td> <td>    0.806</td> <td> 0.420</td> <td>-2035.370</td> <td> 4873.606</td>
</tr>
<tr>
  <th>BsmtFinSF2</th>            <td> 3737.6124</td> <td> 4021.644</td> <td>    0.929</td> <td> 0.353</td> <td>-4155.547</td> <td> 1.16e+04</td>
</tr>
<tr>
  <th>BsmtUnfSF</th>             <td>  144.7045</td> <td>  885.135</td> <td>    0.163</td> <td> 0.870</td> <td>-1592.522</td> <td> 1881.931</td>
</tr>
<tr>
  <th>BsmtFullBath</th>          <td> 9263.4818</td> <td> 2838.292</td> <td>    3.264</td> <td> 0.001</td> <td> 3692.852</td> <td> 1.48e+04</td>
</tr>
<tr>
  <th>BsmtHalfBath</th>          <td>  915.9854</td> <td> 6816.208</td> <td>    0.134</td> <td> 0.893</td> <td>-1.25e+04</td> <td> 1.43e+04</td>
</tr>
<tr>
  <th>FullBath</th>              <td> 2.502e+04</td> <td> 3085.132</td> <td>    8.109</td> <td> 0.000</td> <td>  1.9e+04</td> <td> 3.11e+04</td>
</tr>
<tr>
  <th>HalfBath</th>              <td> 1.276e+04</td> <td> 3003.678</td> <td>    4.249</td> <td> 0.000</td> <td> 6866.531</td> <td> 1.87e+04</td>
</tr>
<tr>
  <th>KitchenAbvGr</th>          <td>-1.328e+04</td> <td> 1.99e+04</td> <td>   -0.666</td> <td> 0.505</td> <td>-5.24e+04</td> <td> 2.58e+04</td>
</tr>
<tr>
  <th>Fireplaces</th>            <td> 2.009e+04</td> <td> 4010.338</td> <td>    5.009</td> <td> 0.000</td> <td> 1.22e+04</td> <td>  2.8e+04</td>
</tr>
<tr>
  <th>WoodDeckSF</th>            <td>  701.2025</td> <td>  453.133</td> <td>    1.547</td> <td> 0.122</td> <td> -188.147</td> <td> 1590.552</td>
</tr>
<tr>
  <th>OpenPorchSF</th>           <td> 1500.3706</td> <td>  597.598</td> <td>    2.511</td> <td> 0.012</td> <td>  327.483</td> <td> 2673.258</td>
</tr>
<tr>
  <th>EnclosedPorch</th>         <td> -497.2964</td> <td>  695.185</td> <td>   -0.715</td> <td> 0.475</td> <td>-1861.714</td> <td>  867.121</td>
</tr>
<tr>
  <th>ScreenPorch</th>           <td> 1534.7793</td> <td>  765.186</td> <td>    2.006</td> <td> 0.045</td> <td>   32.972</td> <td> 3036.586</td>
</tr>
<tr>
  <th>Age_Remod</th>             <td> -121.6045</td> <td>   80.709</td> <td>   -1.507</td> <td> 0.132</td> <td> -280.011</td> <td>   36.801</td>
</tr>
<tr>
  <th>Age_Garage</th>            <td>-2787.9947</td> <td> 1355.902</td> <td>   -2.056</td> <td> 0.040</td> <td>-5449.183</td> <td> -126.807</td>
</tr>
<tr>
  <th>MSSubClass_160</th>        <td> 1554.4236</td> <td> 1.36e+04</td> <td>    0.114</td> <td> 0.909</td> <td>-2.52e+04</td> <td> 2.83e+04</td>
</tr>
<tr>
  <th>MSSubClass_180</th>        <td>-2509.6222</td> <td> 1.91e+04</td> <td>   -0.132</td> <td> 0.895</td> <td>-3.99e+04</td> <td> 3.49e+04</td>
</tr>
<tr>
  <th>MSSubClass_190</th>        <td>-7897.3071</td> <td> 1.16e+04</td> <td>   -0.678</td> <td> 0.498</td> <td>-3.07e+04</td> <td>  1.5e+04</td>
</tr>
<tr>
  <th>MSSubClass_20</th>         <td> 1544.2473</td> <td> 2.01e+04</td> <td>    0.077</td> <td> 0.939</td> <td>-3.79e+04</td> <td>  4.1e+04</td>
</tr>
<tr>
  <th>MSSubClass_30</th>         <td>-1.642e+04</td> <td> 2.09e+04</td> <td>   -0.787</td> <td> 0.432</td> <td>-5.74e+04</td> <td> 2.46e+04</td>
</tr>
<tr>
  <th>MSSubClass_40</th>         <td>  3.49e+04</td> <td> 2.97e+04</td> <td>    1.174</td> <td> 0.241</td> <td>-2.34e+04</td> <td> 9.32e+04</td>
</tr>
<tr>
  <th>MSSubClass_45</th>         <td>-3640.7601</td> <td> 2.61e+04</td> <td>   -0.139</td> <td> 0.889</td> <td>-5.49e+04</td> <td> 4.76e+04</td>
</tr>
<tr>
  <th>MSSubClass_50</th>         <td> 5529.2156</td> <td> 2.34e+04</td> <td>    0.237</td> <td> 0.813</td> <td>-4.03e+04</td> <td> 5.14e+04</td>
</tr>
<tr>
  <th>MSSubClass_60</th>         <td> 1725.3454</td> <td> 2.29e+04</td> <td>    0.075</td> <td> 0.940</td> <td>-4.32e+04</td> <td> 4.67e+04</td>
</tr>
<tr>
  <th>MSSubClass_70</th>         <td> 7602.6677</td> <td> 2.34e+04</td> <td>    0.324</td> <td> 0.746</td> <td>-3.84e+04</td> <td> 5.36e+04</td>
</tr>
<tr>
  <th>MSSubClass_75</th>         <td> 2.187e+04</td> <td> 2.56e+04</td> <td>    0.853</td> <td> 0.394</td> <td>-2.84e+04</td> <td> 7.22e+04</td>
</tr>
<tr>
  <th>MSSubClass_80</th>         <td> 1753.3205</td> <td> 2.48e+04</td> <td>    0.071</td> <td> 0.944</td> <td>-4.69e+04</td> <td> 5.04e+04</td>
</tr>
<tr>
  <th>MSSubClass_85</th>         <td>  103.2180</td> <td> 2.59e+04</td> <td>    0.004</td> <td> 0.997</td> <td>-5.08e+04</td> <td>  5.1e+04</td>
</tr>
<tr>
  <th>MSSubClass_90</th>         <td> 2146.4545</td> <td> 1.15e+04</td> <td>    0.187</td> <td> 0.852</td> <td>-2.04e+04</td> <td> 2.47e+04</td>
</tr>
<tr>
  <th>MSZoning_FV</th>           <td> 3.607e+04</td> <td> 1.77e+04</td> <td>    2.042</td> <td> 0.041</td> <td> 1401.151</td> <td> 7.07e+04</td>
</tr>
<tr>
  <th>MSZoning_R</th>            <td> 2.927e+04</td> <td> 1.44e+04</td> <td>    2.028</td> <td> 0.043</td> <td>  940.505</td> <td> 5.76e+04</td>
</tr>
<tr>
  <th>Street_Pave</th>           <td>  2.44e+04</td> <td> 1.48e+04</td> <td>    1.645</td> <td> 0.100</td> <td>-4709.922</td> <td> 5.35e+04</td>
</tr>
<tr>
  <th>LotShape_Reg</th>          <td> -694.2787</td> <td> 2570.016</td> <td>   -0.270</td> <td> 0.787</td> <td>-5738.371</td> <td> 4349.814</td>
</tr>
<tr>
  <th>LandContour_N Lvl</th>     <td> 1658.5779</td> <td> 4301.754</td> <td>    0.386</td> <td> 0.700</td> <td>-6784.344</td> <td> 1.01e+04</td>
</tr>
<tr>
  <th>LotConfig_CulDSac</th>     <td> 1.201e+04</td> <td> 4924.192</td> <td>    2.439</td> <td> 0.015</td> <td> 2346.921</td> <td> 2.17e+04</td>
</tr>
<tr>
  <th>LotConfig_FR</th>          <td>-1.278e+04</td> <td> 5523.383</td> <td>   -2.313</td> <td> 0.021</td> <td>-2.36e+04</td> <td>-1937.571</td>
</tr>
<tr>
  <th>LotConfig_Inside</th>      <td>-2132.7620</td> <td> 2698.154</td> <td>   -0.790</td> <td> 0.429</td> <td>-7428.347</td> <td> 3162.823</td>
</tr>
<tr>
  <th>LandSlope_Low</th>         <td> 2123.1336</td> <td> 5773.261</td> <td>    0.368</td> <td> 0.713</td> <td>-9207.870</td> <td> 1.35e+04</td>
</tr>
<tr>
  <th>Neighborhood_Blueste</th>  <td>-1.459e+04</td> <td> 2.71e+04</td> <td>   -0.538</td> <td> 0.591</td> <td>-6.78e+04</td> <td> 3.87e+04</td>
</tr>
<tr>
  <th>Neighborhood_BrDale</th>   <td> 1741.8507</td> <td> 1.64e+04</td> <td>    0.106</td> <td> 0.915</td> <td>-3.04e+04</td> <td> 3.39e+04</td>
</tr>
<tr>
  <th>Neighborhood_BrkSide</th>  <td>-1.884e+04</td> <td> 1.33e+04</td> <td>   -1.414</td> <td> 0.158</td> <td> -4.5e+04</td> <td> 7311.986</td>
</tr>
<tr>
  <th>Neighborhood_ClearCr</th>  <td>-7266.5273</td> <td> 1.43e+04</td> <td>   -0.507</td> <td> 0.612</td> <td>-3.54e+04</td> <td> 2.09e+04</td>
</tr>
<tr>
  <th>Neighborhood_CollgCr</th>  <td>-2.092e+04</td> <td> 1.16e+04</td> <td>   -1.808</td> <td> 0.071</td> <td>-4.36e+04</td> <td> 1786.279</td>
</tr>
<tr>
  <th>Neighborhood_Crawfor</th>  <td>-2562.9075</td> <td> 1.31e+04</td> <td>   -0.196</td> <td> 0.845</td> <td>-2.83e+04</td> <td> 2.32e+04</td>
</tr>
<tr>
  <th>Neighborhood_Edwards</th>  <td>-4.289e+04</td> <td> 1.23e+04</td> <td>   -3.490</td> <td> 0.001</td> <td> -6.7e+04</td> <td>-1.88e+04</td>
</tr>
<tr>
  <th>Neighborhood_Gilbert</th>  <td>-2.927e+04</td> <td> 1.22e+04</td> <td>   -2.394</td> <td> 0.017</td> <td>-5.33e+04</td> <td>-5269.965</td>
</tr>
<tr>
  <th>Neighborhood_IDOTRR</th>   <td>-3.052e+04</td> <td> 1.41e+04</td> <td>   -2.164</td> <td> 0.031</td> <td>-5.82e+04</td> <td>-2837.605</td>
</tr>
<tr>
  <th>Neighborhood_MeadowV</th>  <td>-8802.3089</td> <td> 1.74e+04</td> <td>   -0.506</td> <td> 0.613</td> <td>-4.29e+04</td> <td> 2.53e+04</td>
</tr>
<tr>
  <th>Neighborhood_Mitchel</th>  <td>-2.845e+04</td> <td> 1.25e+04</td> <td>   -2.269</td> <td> 0.024</td> <td>-5.31e+04</td> <td>-3838.753</td>
</tr>
<tr>
  <th>Neighborhood_NAmes</th>    <td> -3.25e+04</td> <td> 1.21e+04</td> <td>   -2.687</td> <td> 0.007</td> <td>-5.62e+04</td> <td>-8760.277</td>
</tr>
<tr>
  <th>Neighborhood_NPkVill</th>  <td> 2179.2977</td> <td> 1.83e+04</td> <td>    0.119</td> <td> 0.905</td> <td>-3.38e+04</td> <td> 3.82e+04</td>
</tr>
<tr>
  <th>Neighborhood_NWAmes</th>   <td>-1.239e+04</td> <td> 1.27e+04</td> <td>   -0.979</td> <td> 0.328</td> <td>-3.72e+04</td> <td> 1.24e+04</td>
</tr>
<tr>
  <th>Neighborhood_NoRidge</th>  <td> 3.645e+04</td> <td> 1.33e+04</td> <td>    2.748</td> <td> 0.006</td> <td> 1.04e+04</td> <td> 6.25e+04</td>
</tr>
<tr>
  <th>Neighborhood_NridgHt</th>  <td> 2.112e+04</td> <td> 1.22e+04</td> <td>    1.734</td> <td> 0.083</td> <td>-2784.477</td> <td>  4.5e+04</td>
</tr>
<tr>
  <th>Neighborhood_OldTown</th>  <td>-3.285e+04</td> <td> 1.28e+04</td> <td>   -2.559</td> <td> 0.011</td> <td> -5.8e+04</td> <td>-7653.093</td>
</tr>
<tr>
  <th>Neighborhood_SWISU</th>    <td>-2.845e+04</td> <td> 1.44e+04</td> <td>   -1.975</td> <td> 0.049</td> <td>-5.67e+04</td> <td> -174.261</td>
</tr>
<tr>
  <th>Neighborhood_Sawyer</th>   <td>-2.854e+04</td> <td> 1.24e+04</td> <td>   -2.295</td> <td> 0.022</td> <td>-5.29e+04</td> <td>-4132.352</td>
</tr>
<tr>
  <th>Neighborhood_SawyerW</th>  <td>-1.602e+04</td> <td> 1.22e+04</td> <td>   -1.311</td> <td> 0.190</td> <td>   -4e+04</td> <td> 7956.513</td>
</tr>
<tr>
  <th>Neighborhood_Somerst</th>  <td>-1.279e+04</td> <td> 1.43e+04</td> <td>   -0.895</td> <td> 0.371</td> <td>-4.08e+04</td> <td> 1.52e+04</td>
</tr>
<tr>
  <th>Neighborhood_StoneBr</th>  <td> 3.169e+04</td> <td> 1.31e+04</td> <td>    2.410</td> <td> 0.016</td> <td> 5883.745</td> <td> 5.75e+04</td>
</tr>
<tr>
  <th>Neighborhood_Timber</th>   <td>-2.441e+04</td> <td> 1.29e+04</td> <td>   -1.891</td> <td> 0.059</td> <td>-4.97e+04</td> <td>  931.035</td>
</tr>
<tr>
  <th>Neighborhood_Veenker</th>  <td>-1.002e+04</td> <td>  1.6e+04</td> <td>   -0.627</td> <td> 0.531</td> <td>-4.14e+04</td> <td> 2.13e+04</td>
</tr>
<tr>
  <th>Condition1_Feedr</th>      <td>-2093.0381</td> <td> 7507.757</td> <td>   -0.279</td> <td> 0.780</td> <td>-1.68e+04</td> <td> 1.26e+04</td>
</tr>
<tr>
  <th>Condition1_Norm</th>       <td> 5137.3938</td> <td> 6277.901</td> <td>    0.818</td> <td> 0.413</td> <td>-7184.052</td> <td> 1.75e+04</td>
</tr>
<tr>
  <th>Condition1_Pos</th>        <td> 8441.1842</td> <td> 1.03e+04</td> <td>    0.820</td> <td> 0.412</td> <td>-1.18e+04</td> <td> 2.86e+04</td>
</tr>
<tr>
  <th>Condition1_RR</th>         <td>-1.001e+04</td> <td> 9006.945</td> <td>   -1.112</td> <td> 0.267</td> <td>-2.77e+04</td> <td> 7663.205</td>
</tr>
<tr>
  <th>BldgType_2fmCon</th>       <td>-7897.3071</td> <td> 1.16e+04</td> <td>   -0.678</td> <td> 0.498</td> <td>-3.07e+04</td> <td>  1.5e+04</td>
</tr>
<tr>
  <th>BldgType_Duplex</th>       <td> 2146.4545</td> <td> 1.15e+04</td> <td>    0.187</td> <td> 0.852</td> <td>-2.04e+04</td> <td> 2.47e+04</td>
</tr>
<tr>
  <th>BldgType_Twnhs</th>        <td>    -2e+04</td> <td> 2.12e+04</td> <td>   -0.942</td> <td> 0.347</td> <td>-6.17e+04</td> <td> 2.17e+04</td>
</tr>
<tr>
  <th>BldgType_TwnhsE</th>       <td>-2.124e+04</td> <td> 1.99e+04</td> <td>   -1.065</td> <td> 0.287</td> <td>-6.04e+04</td> <td> 1.79e+04</td>
</tr>
<tr>
  <th>HouseStyle_1.5</th>        <td> 1606.5515</td> <td> 1.14e+04</td> <td>    0.141</td> <td> 0.888</td> <td>-2.07e+04</td> <td> 2.39e+04</td>
</tr>
<tr>
  <th>HouseStyle_2+</th>         <td> 2076.9679</td> <td> 1.05e+04</td> <td>    0.197</td> <td> 0.844</td> <td>-1.86e+04</td> <td> 2.28e+04</td>
</tr>
<tr>
  <th>HouseStyle_Split</th>      <td>-4919.5536</td> <td> 1.36e+04</td> <td>   -0.362</td> <td> 0.717</td> <td>-3.16e+04</td> <td> 2.18e+04</td>
</tr>
<tr>
  <th>OverallQual_Low</th>       <td>-3.674e+04</td> <td> 6196.474</td> <td>   -5.929</td> <td> 0.000</td> <td>-4.89e+04</td> <td>-2.46e+04</td>
</tr>
<tr>
  <th>OverallQual_Med</th>       <td>-3.581e+04</td> <td> 4216.136</td> <td>   -8.494</td> <td> 0.000</td> <td>-4.41e+04</td> <td>-2.75e+04</td>
</tr>
<tr>
  <th>OverallCond_Bad</th>       <td>-1.049e+04</td> <td> 5047.046</td> <td>   -2.078</td> <td> 0.038</td> <td>-2.04e+04</td> <td> -580.848</td>
</tr>
<tr>
  <th>OverallCond_Good</th>      <td> 5648.4504</td> <td> 2935.964</td> <td>    1.924</td> <td> 0.055</td> <td> -113.877</td> <td> 1.14e+04</td>
</tr>
<tr>
  <th>RoofStyle_Hip</th>         <td> 1.249e+04</td> <td> 2855.961</td> <td>    4.374</td> <td> 0.000</td> <td> 6886.314</td> <td> 1.81e+04</td>
</tr>
<tr>
  <th>RoofStyle_Others</th>      <td> -560.0809</td> <td> 8006.758</td> <td>   -0.070</td> <td> 0.944</td> <td>-1.63e+04</td> <td> 1.52e+04</td>
</tr>
<tr>
  <th>Exterior1st_HdBoard</th>   <td>-6223.2974</td> <td> 2.01e+04</td> <td>   -0.309</td> <td> 0.757</td> <td>-4.57e+04</td> <td> 3.33e+04</td>
</tr>
<tr>
  <th>Exterior1st_MetalSd</th>   <td> -459.0584</td> <td> 2.21e+04</td> <td>   -0.021</td> <td> 0.983</td> <td>-4.38e+04</td> <td> 4.29e+04</td>
</tr>
<tr>
  <th>Exterior1st_Others</th>    <td> 2743.6940</td> <td> 1.92e+04</td> <td>    0.143</td> <td> 0.886</td> <td>-3.49e+04</td> <td> 4.04e+04</td>
</tr>
<tr>
  <th>Exterior1st_Plywood</th>   <td>  532.8733</td> <td> 2.01e+04</td> <td>    0.026</td> <td> 0.979</td> <td> -3.9e+04</td> <td>    4e+04</td>
</tr>
<tr>
  <th>Exterior1st_VinylSd</th>   <td>-1.104e+04</td> <td> 2.16e+04</td> <td>   -0.511</td> <td> 0.609</td> <td>-5.34e+04</td> <td> 3.13e+04</td>
</tr>
<tr>
  <th>Exterior1st_Wd Sdng</th>   <td>-5193.5393</td> <td> 1.93e+04</td> <td>   -0.269</td> <td> 0.788</td> <td>-4.31e+04</td> <td> 3.27e+04</td>
</tr>
<tr>
  <th>Exterior2nd_HdBoard</th>   <td> 4779.1151</td> <td> 2.04e+04</td> <td>    0.234</td> <td> 0.815</td> <td>-3.53e+04</td> <td> 4.49e+04</td>
</tr>
<tr>
  <th>Exterior2nd_MetalSd</th>   <td> 1.081e+04</td> <td> 2.25e+04</td> <td>    0.481</td> <td> 0.630</td> <td>-3.33e+04</td> <td> 5.49e+04</td>
</tr>
<tr>
  <th>Exterior2nd_Others</th>    <td> 9780.4346</td> <td> 1.93e+04</td> <td>    0.508</td> <td> 0.612</td> <td> -2.8e+04</td> <td> 4.76e+04</td>
</tr>
<tr>
  <th>Exterior2nd_Plywood</th>   <td> 3100.6109</td> <td> 2.01e+04</td> <td>    0.154</td> <td> 0.878</td> <td>-3.64e+04</td> <td> 4.26e+04</td>
</tr>
<tr>
  <th>Exterior2nd_VinylSd</th>   <td> 1.789e+04</td> <td> 2.18e+04</td> <td>    0.822</td> <td> 0.411</td> <td>-2.48e+04</td> <td> 6.06e+04</td>
</tr>
<tr>
  <th>Exterior2nd_Wd Sdng</th>   <td> 1.489e+04</td> <td> 1.95e+04</td> <td>    0.762</td> <td> 0.446</td> <td>-2.35e+04</td> <td> 5.32e+04</td>
</tr>
<tr>
  <th>MasVnrType_None</th>       <td> 3516.0745</td> <td> 9334.693</td> <td>    0.377</td> <td> 0.707</td> <td>-1.48e+04</td> <td> 2.18e+04</td>
</tr>
<tr>
  <th>MasVnrType_Stone</th>      <td> 6587.1451</td> <td> 4452.447</td> <td>    1.479</td> <td> 0.139</td> <td>-2151.537</td> <td> 1.53e+04</td>
</tr>
<tr>
  <th>ExterQual_Low</th>         <td>-4204.9730</td> <td> 3889.139</td> <td>   -1.081</td> <td> 0.280</td> <td>-1.18e+04</td> <td> 3428.122</td>
</tr>
<tr>
  <th>ExterCond_Low</th>         <td>-1239.8265</td> <td> 3851.394</td> <td>   -0.322</td> <td> 0.748</td> <td>-8798.840</td> <td> 6319.187</td>
</tr>
<tr>
  <th>Foundation_CBlock</th>     <td> 1319.6755</td> <td> 4871.306</td> <td>    0.271</td> <td> 0.787</td> <td>-8241.088</td> <td> 1.09e+04</td>
</tr>
<tr>
  <th>Foundation_Other</th>      <td> 1.624e+04</td> <td> 1.03e+04</td> <td>    1.581</td> <td> 0.114</td> <td>-3915.854</td> <td> 3.64e+04</td>
</tr>
<tr>
  <th>Foundation_PConc</th>      <td> 4626.6909</td> <td> 5268.222</td> <td>    0.878</td> <td> 0.380</td> <td>-5713.088</td> <td>  1.5e+04</td>
</tr>
<tr>
  <th>BsmtQual_Low</th>          <td>-1776.1120</td> <td> 3814.398</td> <td>   -0.466</td> <td> 0.642</td> <td>-9262.515</td> <td> 5710.291</td>
</tr>
<tr>
  <th>BsmtQual_None</th>         <td> -401.6540</td> <td> 1.75e+04</td> <td>   -0.023</td> <td> 0.982</td> <td>-3.47e+04</td> <td> 3.39e+04</td>
</tr>
<tr>
  <th>BsmtCond_Low</th>          <td> 2562.6733</td> <td> 5023.990</td> <td>    0.510</td> <td> 0.610</td> <td>-7297.758</td> <td> 1.24e+04</td>
</tr>
<tr>
  <th>BsmtCond_None</th>         <td> -401.6540</td> <td> 1.75e+04</td> <td>   -0.023</td> <td> 0.982</td> <td>-3.47e+04</td> <td> 3.39e+04</td>
</tr>
<tr>
  <th>BsmtExposure_Gd</th>       <td> 2.633e+04</td> <td> 4614.181</td> <td>    5.706</td> <td> 0.000</td> <td> 1.73e+04</td> <td> 3.54e+04</td>
</tr>
<tr>
  <th>BsmtExposure_Mn</th>       <td> 3454.7625</td> <td> 4688.207</td> <td>    0.737</td> <td> 0.461</td> <td>-5746.638</td> <td> 1.27e+04</td>
</tr>
<tr>
  <th>BsmtExposure_No</th>       <td>-2451.5380</td> <td> 3432.093</td> <td>   -0.714</td> <td> 0.475</td> <td>-9187.603</td> <td> 4284.527</td>
</tr>
<tr>
  <th>BsmtExposure_None</th>     <td>-1.175e+04</td> <td> 3.09e+04</td> <td>   -0.380</td> <td> 0.704</td> <td>-7.25e+04</td> <td>  4.9e+04</td>
</tr>
<tr>
  <th>BsmtFinType1_BLQ</th>      <td>-1117.1050</td> <td> 4332.218</td> <td>   -0.258</td> <td> 0.797</td> <td>-9619.818</td> <td> 7385.608</td>
</tr>
<tr>
  <th>BsmtFinType1_GLQ</th>      <td> 4229.8553</td> <td> 3805.812</td> <td>    1.111</td> <td> 0.267</td> <td>-3239.696</td> <td> 1.17e+04</td>
</tr>
<tr>
  <th>BsmtFinType1_LwQ</th>      <td>-9407.7994</td> <td> 5924.264</td> <td>   -1.588</td> <td> 0.113</td> <td> -2.1e+04</td> <td> 2219.574</td>
</tr>
<tr>
  <th>BsmtFinType1_None</th>     <td> -401.6540</td> <td> 1.75e+04</td> <td>   -0.023</td> <td> 0.982</td> <td>-3.47e+04</td> <td> 3.39e+04</td>
</tr>
<tr>
  <th>BsmtFinType1_Rec</th>      <td>-3902.6060</td> <td> 4676.270</td> <td>   -0.835</td> <td> 0.404</td> <td>-1.31e+04</td> <td> 5275.366</td>
</tr>
<tr>
  <th>BsmtFinType1_Unf</th>      <td>-9742.4491</td> <td> 4076.351</td> <td>   -2.390</td> <td> 0.017</td> <td>-1.77e+04</td> <td>-1741.919</td>
</tr>
<tr>
  <th>BsmtFinType2_BLQ</th>      <td>-2368.8778</td> <td> 1.27e+04</td> <td>   -0.187</td> <td> 0.852</td> <td>-2.72e+04</td> <td> 2.25e+04</td>
</tr>
<tr>
  <th>BsmtFinType2_GLQ</th>      <td>-2069.1355</td> <td> 1.45e+04</td> <td>   -0.143</td> <td> 0.886</td> <td>-3.04e+04</td> <td> 2.63e+04</td>
</tr>
<tr>
  <th>BsmtFinType2_LwQ</th>      <td> -858.6167</td> <td> 1.21e+04</td> <td>   -0.071</td> <td> 0.943</td> <td>-2.46e+04</td> <td> 2.29e+04</td>
</tr>
<tr>
  <th>BsmtFinType2_None</th>     <td> 4022.5831</td> <td> 3.31e+04</td> <td>    0.122</td> <td> 0.903</td> <td>-6.08e+04</td> <td> 6.89e+04</td>
</tr>
<tr>
  <th>BsmtFinType2_Rec</th>      <td>-6054.6993</td> <td> 1.17e+04</td> <td>   -0.518</td> <td> 0.605</td> <td> -2.9e+04</td> <td> 1.69e+04</td>
</tr>
<tr>
  <th>BsmtFinType2_Unf</th>      <td> 1.846e+04</td> <td> 2.58e+04</td> <td>    0.716</td> <td> 0.474</td> <td>-3.21e+04</td> <td> 6.91e+04</td>
</tr>
<tr>
  <th>HeatingQC_Low</th>         <td>-3571.9392</td> <td> 3225.104</td> <td>   -1.108</td> <td> 0.268</td> <td>-9901.752</td> <td> 2757.874</td>
</tr>
<tr>
  <th>HeatingQC_Med</th>         <td>-2228.0452</td> <td> 3189.133</td> <td>   -0.699</td> <td> 0.485</td> <td>-8487.260</td> <td> 4031.170</td>
</tr>
<tr>
  <th>CentralAir_Y</th>          <td> 9341.5933</td> <td> 5425.815</td> <td>    1.722</td> <td> 0.085</td> <td>-1307.488</td> <td>    2e+04</td>
</tr>
<tr>
  <th>Electrical_SBrkr</th>      <td>-4762.2581</td> <td> 4327.629</td> <td>   -1.100</td> <td> 0.271</td> <td>-1.33e+04</td> <td> 3731.448</td>
</tr>
<tr>
  <th>KitchenQual_Low</th>       <td>-4.981e+04</td> <td> 5629.836</td> <td>   -8.848</td> <td> 0.000</td> <td>-6.09e+04</td> <td>-3.88e+04</td>
</tr>
<tr>
  <th>KitchenQual_Med</th>       <td>-4.882e+04</td> <td> 4845.131</td> <td>  -10.075</td> <td> 0.000</td> <td>-5.83e+04</td> <td>-3.93e+04</td>
</tr>
<tr>
  <th>FireplaceQu_Low</th>       <td>-2444.6315</td> <td> 3268.257</td> <td>   -0.748</td> <td> 0.455</td> <td>-8859.141</td> <td> 3969.878</td>
</tr>
<tr>
  <th>FireplaceQu_None</th>      <td> 1.308e+04</td> <td> 5386.351</td> <td>    2.429</td> <td> 0.015</td> <td> 2511.238</td> <td> 2.37e+04</td>
</tr>
<tr>
  <th>GarageType_Detchd</th>     <td> 1668.1616</td> <td> 3416.983</td> <td>    0.488</td> <td> 0.626</td> <td>-5038.246</td> <td> 8374.570</td>
</tr>
<tr>
  <th>GarageType_None</th>       <td>-6441.8085</td> <td> 4083.959</td> <td>   -1.577</td> <td> 0.115</td> <td>-1.45e+04</td> <td> 1573.653</td>
</tr>
<tr>
  <th>GarageFinish_None</th>     <td>-6441.8085</td> <td> 4083.959</td> <td>   -1.577</td> <td> 0.115</td> <td>-1.45e+04</td> <td> 1573.653</td>
</tr>
<tr>
  <th>GarageFinish_RFn</th>      <td>-3286.3597</td> <td> 3076.672</td> <td>   -1.068</td> <td> 0.286</td> <td>-9324.850</td> <td> 2752.131</td>
</tr>
<tr>
  <th>GarageFinish_Unf</th>      <td>-6053.3233</td> <td> 3830.048</td> <td>   -1.580</td> <td> 0.114</td> <td>-1.36e+04</td> <td> 1463.795</td>
</tr>
<tr>
  <th>GarageQual_Low</th>        <td>-3.463e+04</td> <td> 1.18e+04</td> <td>   -2.945</td> <td> 0.003</td> <td>-5.77e+04</td> <td>-1.15e+04</td>
</tr>
<tr>
  <th>GarageQual_None</th>       <td>-6441.8085</td> <td> 4083.959</td> <td>   -1.577</td> <td> 0.115</td> <td>-1.45e+04</td> <td> 1573.653</td>
</tr>
<tr>
  <th>GarageCond_Low</th>        <td> 1.901e+04</td> <td> 1.38e+04</td> <td>    1.375</td> <td> 0.169</td> <td>-8122.266</td> <td> 4.61e+04</td>
</tr>
<tr>
  <th>GarageCond_None</th>       <td>-6441.8085</td> <td> 4083.959</td> <td>   -1.577</td> <td> 0.115</td> <td>-1.45e+04</td> <td> 1573.653</td>
</tr>
<tr>
  <th>Fence_GdWo</th>            <td>-7931.0896</td> <td> 7763.556</td> <td>   -1.022</td> <td> 0.307</td> <td>-2.32e+04</td> <td> 7306.205</td>
</tr>
<tr>
  <th>Fence_MnPrv</th>           <td>-8587.6500</td> <td> 6161.759</td> <td>   -1.394</td> <td> 0.164</td> <td>-2.07e+04</td> <td> 3505.846</td>
</tr>
<tr>
  <th>Fence_MnWw</th>            <td>-1.829e+04</td> <td> 1.17e+04</td> <td>   -1.567</td> <td> 0.118</td> <td>-4.12e+04</td> <td> 4622.403</td>
</tr>
<tr>
  <th>Fence_None</th>            <td>-8802.7455</td> <td> 5358.041</td> <td>   -1.643</td> <td> 0.101</td> <td>-1.93e+04</td> <td> 1713.318</td>
</tr>
<tr>
  <th>SaleType_Other</th>        <td>  869.2007</td> <td> 3.31e+04</td> <td>    0.026</td> <td> 0.979</td> <td> -6.4e+04</td> <td> 6.58e+04</td>
</tr>
<tr>
  <th>SaleType_WD</th>           <td>-9732.7361</td> <td> 3.26e+04</td> <td>   -0.298</td> <td> 0.766</td> <td>-7.38e+04</td> <td> 5.43e+04</td>
</tr>
<tr>
  <th>SaleCondition_Normal</th>  <td> 3430.5494</td> <td> 4234.914</td> <td>    0.810</td> <td> 0.418</td> <td>-4881.188</td> <td> 1.17e+04</td>
</tr>
<tr>
  <th>SaleCondition_Other</th>   <td> 1386.3249</td> <td> 8033.239</td> <td>    0.173</td> <td> 0.863</td> <td>-1.44e+04</td> <td> 1.72e+04</td>
</tr>
<tr>
  <th>SaleCondition_Partial</th> <td> 1.926e+04</td> <td> 3.26e+04</td> <td>    0.592</td> <td> 0.554</td> <td>-4.46e+04</td> <td> 8.32e+04</td>
</tr>
<tr>
  <th>SznSold_Spring</th>        <td> 5431.0331</td> <td> 3180.379</td> <td>    1.708</td> <td> 0.088</td> <td> -811.001</td> <td> 1.17e+04</td>
</tr>
<tr>
  <th>SznSold_Summer</th>        <td> 4882.6695</td> <td> 3041.695</td> <td>    1.605</td> <td> 0.109</td> <td>-1087.173</td> <td> 1.09e+04</td>
</tr>
<tr>
  <th>SznSold_Winter</th>        <td> 1315.3595</td> <td> 3913.652</td> <td>    0.336</td> <td> 0.737</td> <td>-6365.846</td> <td> 8996.565</td>
</tr>
</table>
<table class="simpletable">
<tr>
  <th>Omnibus:</th>       <td>433.958</td> <th>  Durbin-Watson:     </th> <td>   2.020</td> 
</tr>
<tr>
  <th>Prob(Omnibus):</th> <td> 0.000</td>  <th>  Jarque-Bera (JB):  </th> <td>18179.842</td>
</tr>
<tr>
  <th>Skew:</th>          <td> 1.224</td>  <th>  Prob(JB):          </th> <td>    0.00</td> 
</tr>
<tr>
  <th>Kurtosis:</th>      <td>23.527</td>  <th>  Cond. No.          </th> <td>1.12e+16</td> 
</tr>
</table><br/><br/>Warnings:<br/>[1] Standard Errors assume that the covariance matrix of the errors is correctly specified.<br/>[2] The smallest eigenvalue is 3.99e-26. This might indicate that there are<br/>strong multicollinearity problems or that the design matrix is singular.



Let's now calculate the RMSE for this model.


```python
# Function to calculate RMSE 
import math
def rmse(lm, X, y):
    predicted = lm.predict(X)
    actual = y
    mse = ((predicted - actual)**2).sum() / len(X)
    rmse = math.sqrt(mse)
    return round(rmse, 4)

# Function to calculate RMSE when predicted and actual values are taken on a logarithmic scale
def rmse_log_scale(lm, X, y):
    predicted = lm.predict(X)
    actual = y
    mse = ((predicted.apply(math.log) - actual.apply(math.log))**2).sum() / len(X)
    rmse = math.sqrt(mse)
    return round(rmse, 4)

rmse_base = rmse(lm_base, df_test_x, df_test_y)
rmse_base_log_scale = rmse_log_scale(lm_base, df_test_x, df_test_y)
print(rmse_base, rmse_base_log_scale, sep = '\n')
```

    38323.7447
    0.1744
    

That's a decent base model all things considered. 
>* A good R-squared value at .87 and an Adjusted R-squared (.85) that isn't too low.
>* The F-statistic which is hovering a little over 40 could be better though.
>* A decent RMSE (Yes, it is 38000+ which looks high but that's on a scale of house sale prices which is in the order of 10^5. Taking the sale price on a logarithmic scale gives us an RMSE of 0.1744 which is good for the base model.

But there's also warning - 
>The smallest eigenvalue is 4.17e-26. This might indicate that there are
strong multicollinearity problems or that the design matrix is singular.  

This is an indication that multicollinearity still persists. We will deal with it later, if needed. Because for our second iteration of the model we will get rid of all the insignificant variables.

#### 4.3 Model No. 2
#### 4.3.1 Removing Insignificant Variables
We will first get a list of all variables with their p-values.


```python
results_as_html = lm_base.summary().tables[1].as_html()
results_df = pd.read_html(results_as_html, header=0, index_col=0)[0]
results_df = results_df.reset_index()

def p_sig(val):
    if val >= 0.05:
        color = "red"
    else:
        color = "black"
    return 'color: %s' % color

results_df.sort_values(['index', 'P>|t|'], ascending = False).style.applymap(p_sig, subset = ['P>|t|'])
```




<style  type="text/css" >
    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow0_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow1_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow2_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow3_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow4_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow5_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow6_col4 {
            color:  black;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow7_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow8_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow9_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow10_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow11_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow12_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow13_col4 {
            color:  black;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow14_col4 {
            color:  black;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow15_col4 {
            color:  black;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow16_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow17_col4 {
            color:  black;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow18_col4 {
            color:  black;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow19_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow20_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow21_col4 {
            color:  black;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow22_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow23_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow24_col4 {
            color:  black;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow25_col4 {
            color:  black;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow26_col4 {
            color:  black;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow27_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow28_col4 {
            color:  black;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow29_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow30_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow31_col4 {
            color:  black;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow32_col4 {
            color:  black;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow33_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow34_col4 {
            color:  black;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow35_col4 {
            color:  black;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow36_col4 {
            color:  black;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow37_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow38_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow39_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow40_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow41_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow42_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow43_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow44_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow45_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow46_col4 {
            color:  black;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow47_col4 {
            color:  black;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow48_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow49_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow50_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow51_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow52_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow53_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow54_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow55_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow56_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow57_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow58_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow59_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow60_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow61_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow62_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow63_col4 {
            color:  black;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow64_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow65_col4 {
            color:  black;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow66_col4 {
            color:  black;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow67_col4 {
            color:  black;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow68_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow69_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow70_col4 {
            color:  black;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow71_col4 {
            color:  black;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow72_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow73_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow74_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow75_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow76_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow77_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow78_col4 {
            color:  black;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow79_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow80_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow81_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow82_col4 {
            color:  black;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow83_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow84_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow85_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow86_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow87_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow88_col4 {
            color:  black;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow89_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow90_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow91_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow92_col4 {
            color:  black;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow93_col4 {
            color:  black;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow94_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow95_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow96_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow97_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow98_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow99_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow100_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow101_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow102_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow103_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow104_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow105_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow106_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow107_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow108_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow109_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow110_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow111_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow112_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow113_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow114_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow115_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow116_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow117_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow118_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow119_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow120_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow121_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow122_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow123_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow124_col4 {
            color:  black;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow125_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow126_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow127_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow128_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow129_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow130_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow131_col4 {
            color:  black;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow132_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow133_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow134_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow135_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow136_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow137_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow138_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow139_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow140_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow141_col4 {
            color:  black;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow142_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow143_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow144_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow145_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow146_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow147_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow148_col4 {
            color:  red;
        }    #T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow149_col4 {
            color:  black;
        }</style>  
<table id="T_874f8c76_48dd_11e9_8883_48d224c0b2df" > 
<thead>    <tr> 
        <th class="blank level0" ></th> 
        <th class="col_heading level0 col0" >index</th> 
        <th class="col_heading level0 col1" >coef</th> 
        <th class="col_heading level0 col2" >std err</th> 
        <th class="col_heading level0 col3" >t</th> 
        <th class="col_heading level0 col4" >P>|t|</th> 
        <th class="col_heading level0 col5" >[0.025</th> 
        <th class="col_heading level0 col6" >0.975]</th> 
    </tr></thead> 
<tbody>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row0" class="row_heading level0 row0" >0</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow0_col0" class="data row0 col0" >const</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow0_col1" class="data row0 col1" >-30460</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow0_col2" class="data row0 col2" >62200</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow0_col3" class="data row0 col3" >-0.49</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow0_col4" class="data row0 col4" >0.624</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow0_col5" class="data row0 col5" >-152000</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow0_col6" class="data row0 col6" >91500</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row1" class="row_heading level0 row1" >12</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow1_col0" class="data row1 col0" >WoodDeckSF</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow1_col1" class="data row1 col1" >701.202</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow1_col2" class="data row1 col2" >453.133</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow1_col3" class="data row1 col3" >1.547</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow1_col4" class="data row1 col4" >0.122</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow1_col5" class="data row1 col5" >-188.147</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow1_col6" class="data row1 col6" >1590.55</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row2" class="row_heading level0 row2" >149</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow2_col0" class="data row2 col0" >SznSold_Winter</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow2_col1" class="data row2 col1" >1315.36</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow2_col2" class="data row2 col2" >3913.65</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow2_col3" class="data row2 col3" >0.336</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow2_col4" class="data row2 col4" >0.737</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow2_col5" class="data row2 col5" >-6365.85</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow2_col6" class="data row2 col6" >8996.57</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row3" class="row_heading level0 row3" >148</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow3_col0" class="data row3 col0" >SznSold_Summer</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow3_col1" class="data row3 col1" >4882.67</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow3_col2" class="data row3 col2" >3041.7</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow3_col3" class="data row3 col3" >1.605</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow3_col4" class="data row3 col4" >0.109</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow3_col5" class="data row3 col5" >-1087.17</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow3_col6" class="data row3 col6" >10900</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row4" class="row_heading level0 row4" >147</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow4_col0" class="data row4 col0" >SznSold_Spring</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow4_col1" class="data row4 col1" >5431.03</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow4_col2" class="data row4 col2" >3180.38</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow4_col3" class="data row4 col3" >1.708</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow4_col4" class="data row4 col4" >0.088</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow4_col5" class="data row4 col5" >-811.001</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow4_col6" class="data row4 col6" >11700</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row5" class="row_heading level0 row5" >34</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow5_col0" class="data row5 col0" >Street_Pave</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow5_col1" class="data row5 col1" >24400</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow5_col2" class="data row5 col2" >14800</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow5_col3" class="data row5 col3" >1.645</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow5_col4" class="data row5 col4" >0.1</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow5_col5" class="data row5 col5" >-4709.92</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow5_col6" class="data row5 col6" >53500</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row6" class="row_heading level0 row6" >15</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow6_col0" class="data row6 col0" >ScreenPorch</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow6_col1" class="data row6 col1" >1534.78</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow6_col2" class="data row6 col2" >765.186</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow6_col3" class="data row6 col3" >2.006</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow6_col4" class="data row6 col4" >0.045</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow6_col5" class="data row6 col5" >32.972</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow6_col6" class="data row6 col6" >3036.59</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row7" class="row_heading level0 row7" >143</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow7_col0" class="data row7 col0" >SaleType_WD</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow7_col1" class="data row7 col1" >-9732.74</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow7_col2" class="data row7 col2" >32600</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow7_col3" class="data row7 col3" >-0.298</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow7_col4" class="data row7 col4" >0.766</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow7_col5" class="data row7 col5" >-73800</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow7_col6" class="data row7 col6" >54300</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row8" class="row_heading level0 row8" >142</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow8_col0" class="data row8 col0" >SaleType_Other</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow8_col1" class="data row8 col1" >869.201</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow8_col2" class="data row8 col2" >33100</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow8_col3" class="data row8 col3" >0.026</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow8_col4" class="data row8 col4" >0.979</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow8_col5" class="data row8 col5" >-64000</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow8_col6" class="data row8 col6" >65800</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row9" class="row_heading level0 row9" >146</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow9_col0" class="data row9 col0" >SaleCondition_Partial</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow9_col1" class="data row9 col1" >19260</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow9_col2" class="data row9 col2" >32600</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow9_col3" class="data row9 col3" >0.592</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow9_col4" class="data row9 col4" >0.554</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow9_col5" class="data row9 col5" >-44600</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow9_col6" class="data row9 col6" >83200</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row10" class="row_heading level0 row10" >145</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow10_col0" class="data row10 col0" >SaleCondition_Other</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow10_col1" class="data row10 col1" >1386.32</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow10_col2" class="data row10 col2" >8033.24</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow10_col3" class="data row10 col3" >0.173</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow10_col4" class="data row10 col4" >0.863</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow10_col5" class="data row10 col5" >-14400</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow10_col6" class="data row10 col6" >17200</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row11" class="row_heading level0 row11" >144</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow11_col0" class="data row11 col0" >SaleCondition_Normal</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow11_col1" class="data row11 col1" >3430.55</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow11_col2" class="data row11 col2" >4234.91</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow11_col3" class="data row11 col3" >0.81</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow11_col4" class="data row11 col4" >0.418</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow11_col5" class="data row11 col5" >-4881.19</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow11_col6" class="data row11 col6" >11700</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row12" class="row_heading level0 row12" >81</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow12_col0" class="data row12 col0" >RoofStyle_Others</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow12_col1" class="data row12 col1" >-560.081</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow12_col2" class="data row12 col2" >8006.76</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow12_col3" class="data row12 col3" >-0.07</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow12_col4" class="data row12 col4" >0.944</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow12_col5" class="data row12 col5" >-16300</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow12_col6" class="data row12 col6" >15200</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row13" class="row_heading level0 row13" >80</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow13_col0" class="data row13 col0" >RoofStyle_Hip</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow13_col1" class="data row13 col1" >12490</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow13_col2" class="data row13 col2" >2855.96</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow13_col3" class="data row13 col3" >4.374</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow13_col4" class="data row13 col4" >0</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow13_col5" class="data row13 col5" >6886.31</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow13_col6" class="data row13 col6" >18100</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row14" class="row_heading level0 row14" >77</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow14_col0" class="data row14 col0" >OverallQual_Med</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow14_col1" class="data row14 col1" >-35810</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow14_col2" class="data row14 col2" >4216.14</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow14_col3" class="data row14 col3" >-8.494</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow14_col4" class="data row14 col4" >0</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow14_col5" class="data row14 col5" >-44100</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow14_col6" class="data row14 col6" >-27500</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row15" class="row_heading level0 row15" >76</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow15_col0" class="data row15 col0" >OverallQual_Low</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow15_col1" class="data row15 col1" >-36740</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow15_col2" class="data row15 col2" >6196.47</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow15_col3" class="data row15 col3" >-5.929</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow15_col4" class="data row15 col4" >0</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow15_col5" class="data row15 col5" >-48900</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow15_col6" class="data row15 col6" >-24600</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row16" class="row_heading level0 row16" >79</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow16_col0" class="data row16 col0" >OverallCond_Good</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow16_col1" class="data row16 col1" >5648.45</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow16_col2" class="data row16 col2" >2935.96</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow16_col3" class="data row16 col3" >1.924</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow16_col4" class="data row16 col4" >0.055</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow16_col5" class="data row16 col5" >-113.877</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow16_col6" class="data row16 col6" >11400</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row17" class="row_heading level0 row17" >78</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow17_col0" class="data row17 col0" >OverallCond_Bad</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow17_col1" class="data row17 col1" >-10490</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow17_col2" class="data row17 col2" >5047.05</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow17_col3" class="data row17 col3" >-2.078</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow17_col4" class="data row17 col4" >0.038</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow17_col5" class="data row17 col5" >-20400</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow17_col6" class="data row17 col6" >-580.848</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row18" class="row_heading level0 row18" >13</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow18_col0" class="data row18 col0" >OpenPorchSF</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow18_col1" class="data row18 col1" >1500.37</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow18_col2" class="data row18 col2" >597.598</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow18_col3" class="data row18 col3" >2.511</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow18_col4" class="data row18 col4" >0.012</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow18_col5" class="data row18 col5" >327.483</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow18_col6" class="data row18 col6" >2673.26</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row19" class="row_heading level0 row19" >64</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow19_col0" class="data row19 col0" >Neighborhood_Veenker</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow19_col1" class="data row19 col1" >-10020</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow19_col2" class="data row19 col2" >16000</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow19_col3" class="data row19 col3" >-0.627</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow19_col4" class="data row19 col4" >0.531</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow19_col5" class="data row19 col5" >-41400</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow19_col6" class="data row19 col6" >21300</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row20" class="row_heading level0 row20" >63</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow20_col0" class="data row20 col0" >Neighborhood_Timber</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow20_col1" class="data row20 col1" >-24410</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow20_col2" class="data row20 col2" >12900</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow20_col3" class="data row20 col3" >-1.891</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow20_col4" class="data row20 col4" >0.059</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow20_col5" class="data row20 col5" >-49700</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow20_col6" class="data row20 col6" >931.035</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row21" class="row_heading level0 row21" >62</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow21_col0" class="data row21 col0" >Neighborhood_StoneBr</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow21_col1" class="data row21 col1" >31690</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow21_col2" class="data row21 col2" >13100</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow21_col3" class="data row21 col3" >2.41</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow21_col4" class="data row21 col4" >0.016</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow21_col5" class="data row21 col5" >5883.74</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow21_col6" class="data row21 col6" >57500</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row22" class="row_heading level0 row22" >61</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow22_col0" class="data row22 col0" >Neighborhood_Somerst</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow22_col1" class="data row22 col1" >-12790</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow22_col2" class="data row22 col2" >14300</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow22_col3" class="data row22 col3" >-0.895</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow22_col4" class="data row22 col4" >0.371</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow22_col5" class="data row22 col5" >-40800</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow22_col6" class="data row22 col6" >15200</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row23" class="row_heading level0 row23" >60</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow23_col0" class="data row23 col0" >Neighborhood_SawyerW</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow23_col1" class="data row23 col1" >-16020</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow23_col2" class="data row23 col2" >12200</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow23_col3" class="data row23 col3" >-1.311</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow23_col4" class="data row23 col4" >0.19</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow23_col5" class="data row23 col5" >-40000</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow23_col6" class="data row23 col6" >7956.51</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row24" class="row_heading level0 row24" >59</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow24_col0" class="data row24 col0" >Neighborhood_Sawyer</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow24_col1" class="data row24 col1" >-28540</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow24_col2" class="data row24 col2" >12400</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow24_col3" class="data row24 col3" >-2.295</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow24_col4" class="data row24 col4" >0.022</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow24_col5" class="data row24 col5" >-52900</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow24_col6" class="data row24 col6" >-4132.35</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row25" class="row_heading level0 row25" >58</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow25_col0" class="data row25 col0" >Neighborhood_SWISU</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow25_col1" class="data row25 col1" >-28450</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow25_col2" class="data row25 col2" >14400</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow25_col3" class="data row25 col3" >-1.975</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow25_col4" class="data row25 col4" >0.049</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow25_col5" class="data row25 col5" >-56700</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow25_col6" class="data row25 col6" >-174.261</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row26" class="row_heading level0 row26" >57</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow26_col0" class="data row26 col0" >Neighborhood_OldTown</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow26_col1" class="data row26 col1" >-32850</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow26_col2" class="data row26 col2" >12800</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow26_col3" class="data row26 col3" >-2.559</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow26_col4" class="data row26 col4" >0.011</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow26_col5" class="data row26 col5" >-58000</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow26_col6" class="data row26 col6" >-7653.09</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row27" class="row_heading level0 row27" >56</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow27_col0" class="data row27 col0" >Neighborhood_NridgHt</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow27_col1" class="data row27 col1" >21120</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow27_col2" class="data row27 col2" >12200</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow27_col3" class="data row27 col3" >1.734</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow27_col4" class="data row27 col4" >0.083</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow27_col5" class="data row27 col5" >-2784.48</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow27_col6" class="data row27 col6" >45000</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row28" class="row_heading level0 row28" >55</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow28_col0" class="data row28 col0" >Neighborhood_NoRidge</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow28_col1" class="data row28 col1" >36450</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow28_col2" class="data row28 col2" >13300</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow28_col3" class="data row28 col3" >2.748</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow28_col4" class="data row28 col4" >0.006</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow28_col5" class="data row28 col5" >10400</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow28_col6" class="data row28 col6" >62500</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row29" class="row_heading level0 row29" >54</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow29_col0" class="data row29 col0" >Neighborhood_NWAmes</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow29_col1" class="data row29 col1" >-12390</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow29_col2" class="data row29 col2" >12700</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow29_col3" class="data row29 col3" >-0.979</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow29_col4" class="data row29 col4" >0.328</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow29_col5" class="data row29 col5" >-37200</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow29_col6" class="data row29 col6" >12400</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row30" class="row_heading level0 row30" >53</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow30_col0" class="data row30 col0" >Neighborhood_NPkVill</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow30_col1" class="data row30 col1" >2179.3</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow30_col2" class="data row30 col2" >18300</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow30_col3" class="data row30 col3" >0.119</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow30_col4" class="data row30 col4" >0.905</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow30_col5" class="data row30 col5" >-33800</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow30_col6" class="data row30 col6" >38200</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row31" class="row_heading level0 row31" >52</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow31_col0" class="data row31 col0" >Neighborhood_NAmes</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow31_col1" class="data row31 col1" >-32500</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow31_col2" class="data row31 col2" >12100</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow31_col3" class="data row31 col3" >-2.687</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow31_col4" class="data row31 col4" >0.007</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow31_col5" class="data row31 col5" >-56200</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow31_col6" class="data row31 col6" >-8760.28</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row32" class="row_heading level0 row32" >51</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow32_col0" class="data row32 col0" >Neighborhood_Mitchel</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow32_col1" class="data row32 col1" >-28450</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow32_col2" class="data row32 col2" >12500</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow32_col3" class="data row32 col3" >-2.269</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow32_col4" class="data row32 col4" >0.024</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow32_col5" class="data row32 col5" >-53100</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow32_col6" class="data row32 col6" >-3838.75</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row33" class="row_heading level0 row33" >50</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow33_col0" class="data row33 col0" >Neighborhood_MeadowV</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow33_col1" class="data row33 col1" >-8802.31</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow33_col2" class="data row33 col2" >17400</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow33_col3" class="data row33 col3" >-0.506</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow33_col4" class="data row33 col4" >0.613</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow33_col5" class="data row33 col5" >-42900</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow33_col6" class="data row33 col6" >25300</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row34" class="row_heading level0 row34" >49</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow34_col0" class="data row34 col0" >Neighborhood_IDOTRR</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow34_col1" class="data row34 col1" >-30520</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow34_col2" class="data row34 col2" >14100</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow34_col3" class="data row34 col3" >-2.164</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow34_col4" class="data row34 col4" >0.031</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow34_col5" class="data row34 col5" >-58200</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow34_col6" class="data row34 col6" >-2837.61</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row35" class="row_heading level0 row35" >48</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow35_col0" class="data row35 col0" >Neighborhood_Gilbert</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow35_col1" class="data row35 col1" >-29270</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow35_col2" class="data row35 col2" >12200</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow35_col3" class="data row35 col3" >-2.394</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow35_col4" class="data row35 col4" >0.017</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow35_col5" class="data row35 col5" >-53300</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow35_col6" class="data row35 col6" >-5269.97</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row36" class="row_heading level0 row36" >47</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow36_col0" class="data row36 col0" >Neighborhood_Edwards</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow36_col1" class="data row36 col1" >-42890</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow36_col2" class="data row36 col2" >12300</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow36_col3" class="data row36 col3" >-3.49</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow36_col4" class="data row36 col4" >0.001</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow36_col5" class="data row36 col5" >-67000</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow36_col6" class="data row36 col6" >-18800</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row37" class="row_heading level0 row37" >46</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow37_col0" class="data row37 col0" >Neighborhood_Crawfor</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow37_col1" class="data row37 col1" >-2562.91</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow37_col2" class="data row37 col2" >13100</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow37_col3" class="data row37 col3" >-0.196</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow37_col4" class="data row37 col4" >0.845</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow37_col5" class="data row37 col5" >-28300</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow37_col6" class="data row37 col6" >23200</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row38" class="row_heading level0 row38" >45</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow38_col0" class="data row38 col0" >Neighborhood_CollgCr</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow38_col1" class="data row38 col1" >-20920</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow38_col2" class="data row38 col2" >11600</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow38_col3" class="data row38 col3" >-1.808</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow38_col4" class="data row38 col4" >0.071</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow38_col5" class="data row38 col5" >-43600</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow38_col6" class="data row38 col6" >1786.28</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row39" class="row_heading level0 row39" >44</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow39_col0" class="data row39 col0" >Neighborhood_ClearCr</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow39_col1" class="data row39 col1" >-7266.53</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow39_col2" class="data row39 col2" >14300</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow39_col3" class="data row39 col3" >-0.507</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow39_col4" class="data row39 col4" >0.612</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow39_col5" class="data row39 col5" >-35400</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow39_col6" class="data row39 col6" >20900</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row40" class="row_heading level0 row40" >43</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow40_col0" class="data row40 col0" >Neighborhood_BrkSide</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow40_col1" class="data row40 col1" >-18840</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow40_col2" class="data row40 col2" >13300</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow40_col3" class="data row40 col3" >-1.414</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow40_col4" class="data row40 col4" >0.158</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow40_col5" class="data row40 col5" >-45000</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow40_col6" class="data row40 col6" >7311.99</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row41" class="row_heading level0 row41" >42</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow41_col0" class="data row41 col0" >Neighborhood_BrDale</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow41_col1" class="data row41 col1" >1741.85</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow41_col2" class="data row41 col2" >16400</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow41_col3" class="data row41 col3" >0.106</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow41_col4" class="data row41 col4" >0.915</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow41_col5" class="data row41 col5" >-30400</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow41_col6" class="data row41 col6" >33900</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row42" class="row_heading level0 row42" >41</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow42_col0" class="data row42 col0" >Neighborhood_Blueste</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow42_col1" class="data row42 col1" >-14590</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow42_col2" class="data row42 col2" >27100</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow42_col3" class="data row42 col3" >-0.538</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow42_col4" class="data row42 col4" >0.591</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow42_col5" class="data row42 col5" >-67800</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow42_col6" class="data row42 col6" >38700</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row43" class="row_heading level0 row43" >95</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow43_col0" class="data row43 col0" >MasVnrType_Stone</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow43_col1" class="data row43 col1" >6587.15</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow43_col2" class="data row43 col2" >4452.45</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow43_col3" class="data row43 col3" >1.479</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow43_col4" class="data row43 col4" >0.139</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow43_col5" class="data row43 col5" >-2151.54</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow43_col6" class="data row43 col6" >15300</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row44" class="row_heading level0 row44" >94</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow44_col0" class="data row44 col0" >MasVnrType_None</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow44_col1" class="data row44 col1" >3516.07</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow44_col2" class="data row44 col2" >9334.69</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow44_col3" class="data row44 col3" >0.377</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow44_col4" class="data row44 col4" >0.707</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow44_col5" class="data row44 col5" >-14800</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow44_col6" class="data row44 col6" >21800</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row45" class="row_heading level0 row45" >3</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow45_col0" class="data row45 col0" >MasVnrArea</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow45_col1" class="data row45 col1" >1419.12</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow45_col2" class="data row45 col2" >1760.1</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow45_col3" class="data row45 col3" >0.806</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow45_col4" class="data row45 col4" >0.42</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow45_col5" class="data row45 col5" >-2035.37</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow45_col6" class="data row45 col6" >4873.61</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row46" class="row_heading level0 row46" >33</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow46_col0" class="data row46 col0" >MSZoning_R</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow46_col1" class="data row46 col1" >29270</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow46_col2" class="data row46 col2" >14400</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow46_col3" class="data row46 col3" >2.028</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow46_col4" class="data row46 col4" >0.043</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow46_col5" class="data row46 col5" >940.505</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow46_col6" class="data row46 col6" >57600</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row47" class="row_heading level0 row47" >32</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow47_col0" class="data row47 col0" >MSZoning_FV</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow47_col1" class="data row47 col1" >36070</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow47_col2" class="data row47 col2" >17700</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow47_col3" class="data row47 col3" >2.042</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow47_col4" class="data row47 col4" >0.041</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow47_col5" class="data row47 col5" >1401.15</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow47_col6" class="data row47 col6" >70700</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row48" class="row_heading level0 row48" >31</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow48_col0" class="data row48 col0" >MSSubClass_90</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow48_col1" class="data row48 col1" >2146.45</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow48_col2" class="data row48 col2" >11500</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow48_col3" class="data row48 col3" >0.187</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow48_col4" class="data row48 col4" >0.852</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow48_col5" class="data row48 col5" >-20400</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow48_col6" class="data row48 col6" >24700</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row49" class="row_heading level0 row49" >30</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow49_col0" class="data row49 col0" >MSSubClass_85</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow49_col1" class="data row49 col1" >103.218</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow49_col2" class="data row49 col2" >25900</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow49_col3" class="data row49 col3" >0.004</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow49_col4" class="data row49 col4" >0.997</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow49_col5" class="data row49 col5" >-50800</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow49_col6" class="data row49 col6" >51000</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row50" class="row_heading level0 row50" >29</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow50_col0" class="data row50 col0" >MSSubClass_80</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow50_col1" class="data row50 col1" >1753.32</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow50_col2" class="data row50 col2" >24800</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow50_col3" class="data row50 col3" >0.071</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow50_col4" class="data row50 col4" >0.944</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow50_col5" class="data row50 col5" >-46900</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow50_col6" class="data row50 col6" >50400</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row51" class="row_heading level0 row51" >28</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow51_col0" class="data row51 col0" >MSSubClass_75</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow51_col1" class="data row51 col1" >21870</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow51_col2" class="data row51 col2" >25600</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow51_col3" class="data row51 col3" >0.853</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow51_col4" class="data row51 col4" >0.394</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow51_col5" class="data row51 col5" >-28400</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow51_col6" class="data row51 col6" >72200</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row52" class="row_heading level0 row52" >27</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow52_col0" class="data row52 col0" >MSSubClass_70</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow52_col1" class="data row52 col1" >7602.67</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow52_col2" class="data row52 col2" >23400</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow52_col3" class="data row52 col3" >0.324</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow52_col4" class="data row52 col4" >0.746</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow52_col5" class="data row52 col5" >-38400</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow52_col6" class="data row52 col6" >53600</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row53" class="row_heading level0 row53" >26</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow53_col0" class="data row53 col0" >MSSubClass_60</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow53_col1" class="data row53 col1" >1725.35</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow53_col2" class="data row53 col2" >22900</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow53_col3" class="data row53 col3" >0.075</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow53_col4" class="data row53 col4" >0.94</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow53_col5" class="data row53 col5" >-43200</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow53_col6" class="data row53 col6" >46700</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row54" class="row_heading level0 row54" >25</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow54_col0" class="data row54 col0" >MSSubClass_50</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow54_col1" class="data row54 col1" >5529.22</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow54_col2" class="data row54 col2" >23400</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow54_col3" class="data row54 col3" >0.237</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow54_col4" class="data row54 col4" >0.813</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow54_col5" class="data row54 col5" >-40300</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow54_col6" class="data row54 col6" >51400</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row55" class="row_heading level0 row55" >24</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow55_col0" class="data row55 col0" >MSSubClass_45</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow55_col1" class="data row55 col1" >-3640.76</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow55_col2" class="data row55 col2" >26100</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow55_col3" class="data row55 col3" >-0.139</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow55_col4" class="data row55 col4" >0.889</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow55_col5" class="data row55 col5" >-54900</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow55_col6" class="data row55 col6" >47600</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row56" class="row_heading level0 row56" >23</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow56_col0" class="data row56 col0" >MSSubClass_40</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow56_col1" class="data row56 col1" >34900</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow56_col2" class="data row56 col2" >29700</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow56_col3" class="data row56 col3" >1.174</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow56_col4" class="data row56 col4" >0.241</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow56_col5" class="data row56 col5" >-23400</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow56_col6" class="data row56 col6" >93200</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row57" class="row_heading level0 row57" >22</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow57_col0" class="data row57 col0" >MSSubClass_30</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow57_col1" class="data row57 col1" >-16420</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow57_col2" class="data row57 col2" >20900</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow57_col3" class="data row57 col3" >-0.787</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow57_col4" class="data row57 col4" >0.432</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow57_col5" class="data row57 col5" >-57400</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow57_col6" class="data row57 col6" >24600</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row58" class="row_heading level0 row58" >21</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow58_col0" class="data row58 col0" >MSSubClass_20</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow58_col1" class="data row58 col1" >1544.25</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow58_col2" class="data row58 col2" >20100</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow58_col3" class="data row58 col3" >0.077</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow58_col4" class="data row58 col4" >0.939</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow58_col5" class="data row58 col5" >-37900</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow58_col6" class="data row58 col6" >41000</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row59" class="row_heading level0 row59" >20</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow59_col0" class="data row59 col0" >MSSubClass_190</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow59_col1" class="data row59 col1" >-7897.31</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow59_col2" class="data row59 col2" >11600</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow59_col3" class="data row59 col3" >-0.678</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow59_col4" class="data row59 col4" >0.498</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow59_col5" class="data row59 col5" >-30700</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow59_col6" class="data row59 col6" >15000</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row60" class="row_heading level0 row60" >19</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow60_col0" class="data row60 col0" >MSSubClass_180</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow60_col1" class="data row60 col1" >-2509.62</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow60_col2" class="data row60 col2" >19100</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow60_col3" class="data row60 col3" >-0.132</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow60_col4" class="data row60 col4" >0.895</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow60_col5" class="data row60 col5" >-39900</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow60_col6" class="data row60 col6" >34900</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row61" class="row_heading level0 row61" >18</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow61_col0" class="data row61 col0" >MSSubClass_160</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow61_col1" class="data row61 col1" >1554.42</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow61_col2" class="data row61 col2" >13600</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow61_col3" class="data row61 col3" >0.114</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow61_col4" class="data row61 col4" >0.909</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow61_col5" class="data row61 col5" >-25200</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow61_col6" class="data row61 col6" >28300</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row62" class="row_heading level0 row62" >35</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow62_col0" class="data row62 col0" >LotShape_Reg</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow62_col1" class="data row62 col1" >-694.279</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow62_col2" class="data row62 col2" >2570.02</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow62_col3" class="data row62 col3" >-0.27</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow62_col4" class="data row62 col4" >0.787</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow62_col5" class="data row62 col5" >-5738.37</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow62_col6" class="data row62 col6" >4349.81</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row63" class="row_heading level0 row63" >1</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow63_col0" class="data row63 col0" >LotFrontage</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow63_col1" class="data row63 col1" >109.698</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow63_col2" class="data row63 col2" >34.535</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow63_col3" class="data row63 col3" >3.176</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow63_col4" class="data row63 col4" >0.002</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow63_col5" class="data row63 col5" >41.918</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow63_col6" class="data row63 col6" >177.478</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row64" class="row_heading level0 row64" >39</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow64_col0" class="data row64 col0" >LotConfig_Inside</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow64_col1" class="data row64 col1" >-2132.76</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow64_col2" class="data row64 col2" >2698.15</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow64_col3" class="data row64 col3" >-0.79</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow64_col4" class="data row64 col4" >0.429</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow64_col5" class="data row64 col5" >-7428.35</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow64_col6" class="data row64 col6" >3162.82</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row65" class="row_heading level0 row65" >38</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow65_col0" class="data row65 col0" >LotConfig_FR</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow65_col1" class="data row65 col1" >-12780</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow65_col2" class="data row65 col2" >5523.38</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow65_col3" class="data row65 col3" >-2.313</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow65_col4" class="data row65 col4" >0.021</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow65_col5" class="data row65 col5" >-23600</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow65_col6" class="data row65 col6" >-1937.57</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row66" class="row_heading level0 row66" >37</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow66_col0" class="data row66 col0" >LotConfig_CulDSac</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow66_col1" class="data row66 col1" >12010</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow66_col2" class="data row66 col2" >4924.19</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow66_col3" class="data row66 col3" >2.439</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow66_col4" class="data row66 col4" >0.015</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow66_col5" class="data row66 col5" >2346.92</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow66_col6" class="data row66 col6" >21700</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row67" class="row_heading level0 row67" >2</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow67_col0" class="data row67 col0" >LotArea</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow67_col1" class="data row67 col1" >20160</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow67_col2" class="data row67 col2" >3585.48</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow67_col3" class="data row67 col3" >5.622</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow67_col4" class="data row67 col4" >0</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow67_col5" class="data row67 col5" >13100</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow67_col6" class="data row67 col6" >27200</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row68" class="row_heading level0 row68" >40</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow68_col0" class="data row68 col0" >LandSlope_Low</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow68_col1" class="data row68 col1" >2123.13</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow68_col2" class="data row68 col2" >5773.26</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow68_col3" class="data row68 col3" >0.368</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow68_col4" class="data row68 col4" >0.713</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow68_col5" class="data row68 col5" >-9207.87</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow68_col6" class="data row68 col6" >13500</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row69" class="row_heading level0 row69" >36</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow69_col0" class="data row69 col0" >LandContour_N Lvl</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow69_col1" class="data row69 col1" >1658.58</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow69_col2" class="data row69 col2" >4301.75</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow69_col3" class="data row69 col3" >0.386</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow69_col4" class="data row69 col4" >0.7</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow69_col5" class="data row69 col5" >-6784.34</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow69_col6" class="data row69 col6" >10100</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row70" class="row_heading level0 row70" >126</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow70_col0" class="data row70 col0" >KitchenQual_Med</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow70_col1" class="data row70 col1" >-48820</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow70_col2" class="data row70 col2" >4845.13</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow70_col3" class="data row70 col3" >-10.075</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow70_col4" class="data row70 col4" >0</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow70_col5" class="data row70 col5" >-58300</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow70_col6" class="data row70 col6" >-39300</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row71" class="row_heading level0 row71" >125</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow71_col0" class="data row71 col0" >KitchenQual_Low</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow71_col1" class="data row71 col1" >-49810</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow71_col2" class="data row71 col2" >5629.84</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow71_col3" class="data row71 col3" >-8.848</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow71_col4" class="data row71 col4" >0</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow71_col5" class="data row71 col5" >-60900</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow71_col6" class="data row71 col6" >-38800</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row72" class="row_heading level0 row72" >10</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow72_col0" class="data row72 col0" >KitchenAbvGr</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow72_col1" class="data row72 col1" >-13280</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow72_col2" class="data row72 col2" >19900</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow72_col3" class="data row72 col3" >-0.666</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow72_col4" class="data row72 col4" >0.505</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow72_col5" class="data row72 col5" >-52400</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow72_col6" class="data row72 col6" >25800</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row73" class="row_heading level0 row73" >75</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow73_col0" class="data row73 col0" >HouseStyle_Split</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow73_col1" class="data row73 col1" >-4919.55</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow73_col2" class="data row73 col2" >13600</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow73_col3" class="data row73 col3" >-0.362</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow73_col4" class="data row73 col4" >0.717</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow73_col5" class="data row73 col5" >-31600</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow73_col6" class="data row73 col6" >21800</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row74" class="row_heading level0 row74" >74</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow74_col0" class="data row74 col0" >HouseStyle_2+</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow74_col1" class="data row74 col1" >2076.97</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow74_col2" class="data row74 col2" >10500</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow74_col3" class="data row74 col3" >0.197</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow74_col4" class="data row74 col4" >0.844</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow74_col5" class="data row74 col5" >-18600</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow74_col6" class="data row74 col6" >22800</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row75" class="row_heading level0 row75" >73</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow75_col0" class="data row75 col0" >HouseStyle_1.5</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow75_col1" class="data row75 col1" >1606.55</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow75_col2" class="data row75 col2" >11400</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow75_col3" class="data row75 col3" >0.141</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow75_col4" class="data row75 col4" >0.888</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow75_col5" class="data row75 col5" >-20700</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow75_col6" class="data row75 col6" >23900</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row76" class="row_heading level0 row76" >122</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow76_col0" class="data row76 col0" >HeatingQC_Med</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow76_col1" class="data row76 col1" >-2228.05</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow76_col2" class="data row76 col2" >3189.13</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow76_col3" class="data row76 col3" >-0.699</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow76_col4" class="data row76 col4" >0.485</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow76_col5" class="data row76 col5" >-8487.26</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow76_col6" class="data row76 col6" >4031.17</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row77" class="row_heading level0 row77" >121</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow77_col0" class="data row77 col0" >HeatingQC_Low</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow77_col1" class="data row77 col1" >-3571.94</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow77_col2" class="data row77 col2" >3225.1</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow77_col3" class="data row77 col3" >-1.108</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow77_col4" class="data row77 col4" >0.268</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow77_col5" class="data row77 col5" >-9901.75</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow77_col6" class="data row77 col6" >2757.87</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row78" class="row_heading level0 row78" >9</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow78_col0" class="data row78 col0" >HalfBath</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow78_col1" class="data row78 col1" >12760</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow78_col2" class="data row78 col2" >3003.68</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow78_col3" class="data row78 col3" >4.249</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow78_col4" class="data row78 col4" >0</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow78_col5" class="data row78 col5" >6866.53</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow78_col6" class="data row78 col6" >18700</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row79" class="row_heading level0 row79" >130</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow79_col0" class="data row79 col0" >GarageType_None</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow79_col1" class="data row79 col1" >-6441.81</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow79_col2" class="data row79 col2" >4083.96</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow79_col3" class="data row79 col3" >-1.577</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow79_col4" class="data row79 col4" >0.115</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow79_col5" class="data row79 col5" >-14500</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow79_col6" class="data row79 col6" >1573.65</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row80" class="row_heading level0 row80" >129</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow80_col0" class="data row80 col0" >GarageType_Detchd</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow80_col1" class="data row80 col1" >1668.16</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow80_col2" class="data row80 col2" >3416.98</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow80_col3" class="data row80 col3" >0.488</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow80_col4" class="data row80 col4" >0.626</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow80_col5" class="data row80 col5" >-5038.25</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow80_col6" class="data row80 col6" >8374.57</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row81" class="row_heading level0 row81" >135</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow81_col0" class="data row81 col0" >GarageQual_None</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow81_col1" class="data row81 col1" >-6441.81</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow81_col2" class="data row81 col2" >4083.96</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow81_col3" class="data row81 col3" >-1.577</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow81_col4" class="data row81 col4" >0.115</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow81_col5" class="data row81 col5" >-14500</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow81_col6" class="data row81 col6" >1573.65</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row82" class="row_heading level0 row82" >134</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow82_col0" class="data row82 col0" >GarageQual_Low</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow82_col1" class="data row82 col1" >-34630</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow82_col2" class="data row82 col2" >11800</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow82_col3" class="data row82 col3" >-2.945</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow82_col4" class="data row82 col4" >0.003</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow82_col5" class="data row82 col5" >-57700</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow82_col6" class="data row82 col6" >-11500</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row83" class="row_heading level0 row83" >133</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow83_col0" class="data row83 col0" >GarageFinish_Unf</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow83_col1" class="data row83 col1" >-6053.32</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow83_col2" class="data row83 col2" >3830.05</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow83_col3" class="data row83 col3" >-1.58</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow83_col4" class="data row83 col4" >0.114</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow83_col5" class="data row83 col5" >-13600</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow83_col6" class="data row83 col6" >1463.8</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row84" class="row_heading level0 row84" >132</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow84_col0" class="data row84 col0" >GarageFinish_RFn</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow84_col1" class="data row84 col1" >-3286.36</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow84_col2" class="data row84 col2" >3076.67</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow84_col3" class="data row84 col3" >-1.068</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow84_col4" class="data row84 col4" >0.286</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow84_col5" class="data row84 col5" >-9324.85</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow84_col6" class="data row84 col6" >2752.13</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row85" class="row_heading level0 row85" >131</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow85_col0" class="data row85 col0" >GarageFinish_None</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow85_col1" class="data row85 col1" >-6441.81</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow85_col2" class="data row85 col2" >4083.96</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow85_col3" class="data row85 col3" >-1.577</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow85_col4" class="data row85 col4" >0.115</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow85_col5" class="data row85 col5" >-14500</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow85_col6" class="data row85 col6" >1573.65</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row86" class="row_heading level0 row86" >137</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow86_col0" class="data row86 col0" >GarageCond_None</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow86_col1" class="data row86 col1" >-6441.81</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow86_col2" class="data row86 col2" >4083.96</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow86_col3" class="data row86 col3" >-1.577</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow86_col4" class="data row86 col4" >0.115</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow86_col5" class="data row86 col5" >-14500</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow86_col6" class="data row86 col6" >1573.65</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row87" class="row_heading level0 row87" >136</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow87_col0" class="data row87 col0" >GarageCond_Low</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow87_col1" class="data row87 col1" >19010</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow87_col2" class="data row87 col2" >13800</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow87_col3" class="data row87 col3" >1.375</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow87_col4" class="data row87 col4" >0.169</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow87_col5" class="data row87 col5" >-8122.27</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow87_col6" class="data row87 col6" >46100</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row88" class="row_heading level0 row88" >8</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow88_col0" class="data row88 col0" >FullBath</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow88_col1" class="data row88 col1" >25020</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow88_col2" class="data row88 col2" >3085.13</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow88_col3" class="data row88 col3" >8.109</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow88_col4" class="data row88 col4" >0</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow88_col5" class="data row88 col5" >19000</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow88_col6" class="data row88 col6" >31100</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row89" class="row_heading level0 row89" >100</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow89_col0" class="data row89 col0" >Foundation_PConc</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow89_col1" class="data row89 col1" >4626.69</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow89_col2" class="data row89 col2" >5268.22</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow89_col3" class="data row89 col3" >0.878</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow89_col4" class="data row89 col4" >0.38</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow89_col5" class="data row89 col5" >-5713.09</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow89_col6" class="data row89 col6" >15000</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row90" class="row_heading level0 row90" >99</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow90_col0" class="data row90 col0" >Foundation_Other</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow90_col1" class="data row90 col1" >16240</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow90_col2" class="data row90 col2" >10300</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow90_col3" class="data row90 col3" >1.581</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow90_col4" class="data row90 col4" >0.114</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow90_col5" class="data row90 col5" >-3915.85</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow90_col6" class="data row90 col6" >36400</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row91" class="row_heading level0 row91" >98</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow91_col0" class="data row91 col0" >Foundation_CBlock</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow91_col1" class="data row91 col1" >1319.68</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow91_col2" class="data row91 col2" >4871.31</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow91_col3" class="data row91 col3" >0.271</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow91_col4" class="data row91 col4" >0.787</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow91_col5" class="data row91 col5" >-8241.09</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow91_col6" class="data row91 col6" >10900</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row92" class="row_heading level0 row92" >11</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow92_col0" class="data row92 col0" >Fireplaces</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow92_col1" class="data row92 col1" >20090</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow92_col2" class="data row92 col2" >4010.34</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow92_col3" class="data row92 col3" >5.009</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow92_col4" class="data row92 col4" >0</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow92_col5" class="data row92 col5" >12200</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow92_col6" class="data row92 col6" >28000</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row93" class="row_heading level0 row93" >128</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow93_col0" class="data row93 col0" >FireplaceQu_None</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow93_col1" class="data row93 col1" >13080</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow93_col2" class="data row93 col2" >5386.35</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow93_col3" class="data row93 col3" >2.429</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow93_col4" class="data row93 col4" >0.015</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow93_col5" class="data row93 col5" >2511.24</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow93_col6" class="data row93 col6" >23700</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row94" class="row_heading level0 row94" >127</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow94_col0" class="data row94 col0" >FireplaceQu_Low</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow94_col1" class="data row94 col1" >-2444.63</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow94_col2" class="data row94 col2" >3268.26</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow94_col3" class="data row94 col3" >-0.748</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow94_col4" class="data row94 col4" >0.455</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow94_col5" class="data row94 col5" >-8859.14</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow94_col6" class="data row94 col6" >3969.88</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row95" class="row_heading level0 row95" >141</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow95_col0" class="data row95 col0" >Fence_None</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow95_col1" class="data row95 col1" >-8802.75</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow95_col2" class="data row95 col2" >5358.04</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow95_col3" class="data row95 col3" >-1.643</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow95_col4" class="data row95 col4" >0.101</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow95_col5" class="data row95 col5" >-19300</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow95_col6" class="data row95 col6" >1713.32</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row96" class="row_heading level0 row96" >140</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow96_col0" class="data row96 col0" >Fence_MnWw</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow96_col1" class="data row96 col1" >-18290</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow96_col2" class="data row96 col2" >11700</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow96_col3" class="data row96 col3" >-1.567</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow96_col4" class="data row96 col4" >0.118</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow96_col5" class="data row96 col5" >-41200</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow96_col6" class="data row96 col6" >4622.4</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row97" class="row_heading level0 row97" >139</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow97_col0" class="data row97 col0" >Fence_MnPrv</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow97_col1" class="data row97 col1" >-8587.65</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow97_col2" class="data row97 col2" >6161.76</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow97_col3" class="data row97 col3" >-1.394</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow97_col4" class="data row97 col4" >0.164</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow97_col5" class="data row97 col5" >-20700</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow97_col6" class="data row97 col6" >3505.85</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row98" class="row_heading level0 row98" >138</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow98_col0" class="data row98 col0" >Fence_GdWo</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow98_col1" class="data row98 col1" >-7931.09</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow98_col2" class="data row98 col2" >7763.56</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow98_col3" class="data row98 col3" >-1.022</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow98_col4" class="data row98 col4" >0.307</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow98_col5" class="data row98 col5" >-23200</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow98_col6" class="data row98 col6" >7306.2</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row99" class="row_heading level0 row99" >93</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow99_col0" class="data row99 col0" >Exterior2nd_Wd Sdng</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow99_col1" class="data row99 col1" >14890</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow99_col2" class="data row99 col2" >19500</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow99_col3" class="data row99 col3" >0.762</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow99_col4" class="data row99 col4" >0.446</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow99_col5" class="data row99 col5" >-23500</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow99_col6" class="data row99 col6" >53200</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row100" class="row_heading level0 row100" >92</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow100_col0" class="data row100 col0" >Exterior2nd_VinylSd</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow100_col1" class="data row100 col1" >17890</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow100_col2" class="data row100 col2" >21800</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow100_col3" class="data row100 col3" >0.822</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow100_col4" class="data row100 col4" >0.411</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow100_col5" class="data row100 col5" >-24800</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow100_col6" class="data row100 col6" >60600</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row101" class="row_heading level0 row101" >91</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow101_col0" class="data row101 col0" >Exterior2nd_Plywood</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow101_col1" class="data row101 col1" >3100.61</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow101_col2" class="data row101 col2" >20100</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow101_col3" class="data row101 col3" >0.154</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow101_col4" class="data row101 col4" >0.878</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow101_col5" class="data row101 col5" >-36400</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow101_col6" class="data row101 col6" >42600</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row102" class="row_heading level0 row102" >90</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow102_col0" class="data row102 col0" >Exterior2nd_Others</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow102_col1" class="data row102 col1" >9780.43</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow102_col2" class="data row102 col2" >19300</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow102_col3" class="data row102 col3" >0.508</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow102_col4" class="data row102 col4" >0.612</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow102_col5" class="data row102 col5" >-28000</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow102_col6" class="data row102 col6" >47600</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row103" class="row_heading level0 row103" >89</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow103_col0" class="data row103 col0" >Exterior2nd_MetalSd</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow103_col1" class="data row103 col1" >10810</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow103_col2" class="data row103 col2" >22500</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow103_col3" class="data row103 col3" >0.481</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow103_col4" class="data row103 col4" >0.63</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow103_col5" class="data row103 col5" >-33300</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow103_col6" class="data row103 col6" >54900</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row104" class="row_heading level0 row104" >88</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow104_col0" class="data row104 col0" >Exterior2nd_HdBoard</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow104_col1" class="data row104 col1" >4779.12</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow104_col2" class="data row104 col2" >20400</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow104_col3" class="data row104 col3" >0.234</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow104_col4" class="data row104 col4" >0.815</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow104_col5" class="data row104 col5" >-35300</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow104_col6" class="data row104 col6" >44900</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row105" class="row_heading level0 row105" >87</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow105_col0" class="data row105 col0" >Exterior1st_Wd Sdng</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow105_col1" class="data row105 col1" >-5193.54</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow105_col2" class="data row105 col2" >19300</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow105_col3" class="data row105 col3" >-0.269</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow105_col4" class="data row105 col4" >0.788</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow105_col5" class="data row105 col5" >-43100</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow105_col6" class="data row105 col6" >32700</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row106" class="row_heading level0 row106" >86</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow106_col0" class="data row106 col0" >Exterior1st_VinylSd</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow106_col1" class="data row106 col1" >-11040</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow106_col2" class="data row106 col2" >21600</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow106_col3" class="data row106 col3" >-0.511</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow106_col4" class="data row106 col4" >0.609</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow106_col5" class="data row106 col5" >-53400</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow106_col6" class="data row106 col6" >31300</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row107" class="row_heading level0 row107" >85</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow107_col0" class="data row107 col0" >Exterior1st_Plywood</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow107_col1" class="data row107 col1" >532.873</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow107_col2" class="data row107 col2" >20100</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow107_col3" class="data row107 col3" >0.026</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow107_col4" class="data row107 col4" >0.979</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow107_col5" class="data row107 col5" >-39000</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow107_col6" class="data row107 col6" >40000</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row108" class="row_heading level0 row108" >84</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow108_col0" class="data row108 col0" >Exterior1st_Others</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow108_col1" class="data row108 col1" >2743.69</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow108_col2" class="data row108 col2" >19200</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow108_col3" class="data row108 col3" >0.143</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow108_col4" class="data row108 col4" >0.886</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow108_col5" class="data row108 col5" >-34900</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow108_col6" class="data row108 col6" >40400</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row109" class="row_heading level0 row109" >83</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow109_col0" class="data row109 col0" >Exterior1st_MetalSd</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow109_col1" class="data row109 col1" >-459.058</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow109_col2" class="data row109 col2" >22100</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow109_col3" class="data row109 col3" >-0.021</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow109_col4" class="data row109 col4" >0.983</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow109_col5" class="data row109 col5" >-43800</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow109_col6" class="data row109 col6" >42900</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row110" class="row_heading level0 row110" >82</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow110_col0" class="data row110 col0" >Exterior1st_HdBoard</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow110_col1" class="data row110 col1" >-6223.3</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow110_col2" class="data row110 col2" >20100</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow110_col3" class="data row110 col3" >-0.309</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow110_col4" class="data row110 col4" >0.757</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow110_col5" class="data row110 col5" >-45700</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow110_col6" class="data row110 col6" >33300</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row111" class="row_heading level0 row111" >96</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow111_col0" class="data row111 col0" >ExterQual_Low</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow111_col1" class="data row111 col1" >-4204.97</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow111_col2" class="data row111 col2" >3889.14</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow111_col3" class="data row111 col3" >-1.081</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow111_col4" class="data row111 col4" >0.28</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow111_col5" class="data row111 col5" >-11800</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow111_col6" class="data row111 col6" >3428.12</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row112" class="row_heading level0 row112" >97</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow112_col0" class="data row112 col0" >ExterCond_Low</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow112_col1" class="data row112 col1" >-1239.83</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow112_col2" class="data row112 col2" >3851.39</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow112_col3" class="data row112 col3" >-0.322</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow112_col4" class="data row112 col4" >0.748</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow112_col5" class="data row112 col5" >-8798.84</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow112_col6" class="data row112 col6" >6319.19</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row113" class="row_heading level0 row113" >14</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow113_col0" class="data row113 col0" >EnclosedPorch</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow113_col1" class="data row113 col1" >-497.296</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow113_col2" class="data row113 col2" >695.185</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow113_col3" class="data row113 col3" >-0.715</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow113_col4" class="data row113 col4" >0.475</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow113_col5" class="data row113 col5" >-1861.71</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow113_col6" class="data row113 col6" >867.121</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row114" class="row_heading level0 row114" >124</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow114_col0" class="data row114 col0" >Electrical_SBrkr</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow114_col1" class="data row114 col1" >-4762.26</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow114_col2" class="data row114 col2" >4327.63</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow114_col3" class="data row114 col3" >-1.1</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow114_col4" class="data row114 col4" >0.271</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow114_col5" class="data row114 col5" >-13300</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow114_col6" class="data row114 col6" >3731.45</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row115" class="row_heading level0 row115" >68</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow115_col0" class="data row115 col0" >Condition1_RR</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow115_col1" class="data row115 col1" >-10010</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow115_col2" class="data row115 col2" >9006.94</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow115_col3" class="data row115 col3" >-1.112</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow115_col4" class="data row115 col4" >0.267</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow115_col5" class="data row115 col5" >-27700</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow115_col6" class="data row115 col6" >7663.2</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row116" class="row_heading level0 row116" >67</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow116_col0" class="data row116 col0" >Condition1_Pos</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow116_col1" class="data row116 col1" >8441.18</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow116_col2" class="data row116 col2" >10300</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow116_col3" class="data row116 col3" >0.82</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow116_col4" class="data row116 col4" >0.412</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow116_col5" class="data row116 col5" >-11800</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow116_col6" class="data row116 col6" >28600</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row117" class="row_heading level0 row117" >66</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow117_col0" class="data row117 col0" >Condition1_Norm</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow117_col1" class="data row117 col1" >5137.39</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow117_col2" class="data row117 col2" >6277.9</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow117_col3" class="data row117 col3" >0.818</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow117_col4" class="data row117 col4" >0.413</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow117_col5" class="data row117 col5" >-7184.05</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow117_col6" class="data row117 col6" >17500</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row118" class="row_heading level0 row118" >65</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow118_col0" class="data row118 col0" >Condition1_Feedr</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow118_col1" class="data row118 col1" >-2093.04</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow118_col2" class="data row118 col2" >7507.76</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow118_col3" class="data row118 col3" >-0.279</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow118_col4" class="data row118 col4" >0.78</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow118_col5" class="data row118 col5" >-16800</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow118_col6" class="data row118 col6" >12600</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row119" class="row_heading level0 row119" >123</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow119_col0" class="data row119 col0" >CentralAir_Y</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow119_col1" class="data row119 col1" >9341.59</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow119_col2" class="data row119 col2" >5425.81</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow119_col3" class="data row119 col3" >1.722</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow119_col4" class="data row119 col4" >0.085</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow119_col5" class="data row119 col5" >-1307.49</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow119_col6" class="data row119 col6" >20000</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row120" class="row_heading level0 row120" >5</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow120_col0" class="data row120 col0" >BsmtUnfSF</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow120_col1" class="data row120 col1" >144.704</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow120_col2" class="data row120 col2" >885.135</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow120_col3" class="data row120 col3" >0.163</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow120_col4" class="data row120 col4" >0.87</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow120_col5" class="data row120 col5" >-1592.52</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow120_col6" class="data row120 col6" >1881.93</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row121" class="row_heading level0 row121" >102</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow121_col0" class="data row121 col0" >BsmtQual_None</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow121_col1" class="data row121 col1" >-401.654</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow121_col2" class="data row121 col2" >17500</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow121_col3" class="data row121 col3" >-0.023</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow121_col4" class="data row121 col4" >0.982</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow121_col5" class="data row121 col5" >-34700</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow121_col6" class="data row121 col6" >33900</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row122" class="row_heading level0 row122" >101</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow122_col0" class="data row122 col0" >BsmtQual_Low</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow122_col1" class="data row122 col1" >-1776.11</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow122_col2" class="data row122 col2" >3814.4</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow122_col3" class="data row122 col3" >-0.466</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow122_col4" class="data row122 col4" >0.642</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow122_col5" class="data row122 col5" >-9262.51</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow122_col6" class="data row122 col6" >5710.29</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row123" class="row_heading level0 row123" >7</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow123_col0" class="data row123 col0" >BsmtHalfBath</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow123_col1" class="data row123 col1" >915.985</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow123_col2" class="data row123 col2" >6816.21</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow123_col3" class="data row123 col3" >0.134</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow123_col4" class="data row123 col4" >0.893</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow123_col5" class="data row123 col5" >-12500</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow123_col6" class="data row123 col6" >14300</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row124" class="row_heading level0 row124" >6</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow124_col0" class="data row124 col0" >BsmtFullBath</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow124_col1" class="data row124 col1" >9263.48</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow124_col2" class="data row124 col2" >2838.29</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow124_col3" class="data row124 col3" >3.264</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow124_col4" class="data row124 col4" >0.001</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow124_col5" class="data row124 col5" >3692.85</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow124_col6" class="data row124 col6" >14800</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row125" class="row_heading level0 row125" >120</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow125_col0" class="data row125 col0" >BsmtFinType2_Unf</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow125_col1" class="data row125 col1" >18460</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow125_col2" class="data row125 col2" >25800</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow125_col3" class="data row125 col3" >0.716</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow125_col4" class="data row125 col4" >0.474</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow125_col5" class="data row125 col5" >-32100</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow125_col6" class="data row125 col6" >69100</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row126" class="row_heading level0 row126" >119</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow126_col0" class="data row126 col0" >BsmtFinType2_Rec</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow126_col1" class="data row126 col1" >-6054.7</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow126_col2" class="data row126 col2" >11700</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow126_col3" class="data row126 col3" >-0.518</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow126_col4" class="data row126 col4" >0.605</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow126_col5" class="data row126 col5" >-29000</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow126_col6" class="data row126 col6" >16900</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row127" class="row_heading level0 row127" >118</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow127_col0" class="data row127 col0" >BsmtFinType2_None</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow127_col1" class="data row127 col1" >4022.58</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow127_col2" class="data row127 col2" >33100</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow127_col3" class="data row127 col3" >0.122</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow127_col4" class="data row127 col4" >0.903</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow127_col5" class="data row127 col5" >-60800</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow127_col6" class="data row127 col6" >68900</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row128" class="row_heading level0 row128" >117</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow128_col0" class="data row128 col0" >BsmtFinType2_LwQ</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow128_col1" class="data row128 col1" >-858.617</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow128_col2" class="data row128 col2" >12100</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow128_col3" class="data row128 col3" >-0.071</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow128_col4" class="data row128 col4" >0.943</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow128_col5" class="data row128 col5" >-24600</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow128_col6" class="data row128 col6" >22900</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row129" class="row_heading level0 row129" >116</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow129_col0" class="data row129 col0" >BsmtFinType2_GLQ</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow129_col1" class="data row129 col1" >-2069.14</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow129_col2" class="data row129 col2" >14500</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow129_col3" class="data row129 col3" >-0.143</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow129_col4" class="data row129 col4" >0.886</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow129_col5" class="data row129 col5" >-30400</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow129_col6" class="data row129 col6" >26300</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row130" class="row_heading level0 row130" >115</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow130_col0" class="data row130 col0" >BsmtFinType2_BLQ</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow130_col1" class="data row130 col1" >-2368.88</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow130_col2" class="data row130 col2" >12700</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow130_col3" class="data row130 col3" >-0.187</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow130_col4" class="data row130 col4" >0.852</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow130_col5" class="data row130 col5" >-27200</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow130_col6" class="data row130 col6" >22500</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row131" class="row_heading level0 row131" >114</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow131_col0" class="data row131 col0" >BsmtFinType1_Unf</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow131_col1" class="data row131 col1" >-9742.45</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow131_col2" class="data row131 col2" >4076.35</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow131_col3" class="data row131 col3" >-2.39</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow131_col4" class="data row131 col4" >0.017</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow131_col5" class="data row131 col5" >-17700</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow131_col6" class="data row131 col6" >-1741.92</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row132" class="row_heading level0 row132" >113</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow132_col0" class="data row132 col0" >BsmtFinType1_Rec</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow132_col1" class="data row132 col1" >-3902.61</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow132_col2" class="data row132 col2" >4676.27</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow132_col3" class="data row132 col3" >-0.835</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow132_col4" class="data row132 col4" >0.404</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow132_col5" class="data row132 col5" >-13100</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow132_col6" class="data row132 col6" >5275.37</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row133" class="row_heading level0 row133" >112</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow133_col0" class="data row133 col0" >BsmtFinType1_None</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow133_col1" class="data row133 col1" >-401.654</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow133_col2" class="data row133 col2" >17500</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow133_col3" class="data row133 col3" >-0.023</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow133_col4" class="data row133 col4" >0.982</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow133_col5" class="data row133 col5" >-34700</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow133_col6" class="data row133 col6" >33900</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row134" class="row_heading level0 row134" >111</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow134_col0" class="data row134 col0" >BsmtFinType1_LwQ</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow134_col1" class="data row134 col1" >-9407.8</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow134_col2" class="data row134 col2" >5924.26</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow134_col3" class="data row134 col3" >-1.588</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow134_col4" class="data row134 col4" >0.113</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow134_col5" class="data row134 col5" >-21000</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow134_col6" class="data row134 col6" >2219.57</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row135" class="row_heading level0 row135" >110</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow135_col0" class="data row135 col0" >BsmtFinType1_GLQ</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow135_col1" class="data row135 col1" >4229.86</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow135_col2" class="data row135 col2" >3805.81</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow135_col3" class="data row135 col3" >1.111</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow135_col4" class="data row135 col4" >0.267</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow135_col5" class="data row135 col5" >-3239.7</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow135_col6" class="data row135 col6" >11700</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row136" class="row_heading level0 row136" >109</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow136_col0" class="data row136 col0" >BsmtFinType1_BLQ</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow136_col1" class="data row136 col1" >-1117.11</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow136_col2" class="data row136 col2" >4332.22</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow136_col3" class="data row136 col3" >-0.258</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow136_col4" class="data row136 col4" >0.797</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow136_col5" class="data row136 col5" >-9619.82</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow136_col6" class="data row136 col6" >7385.61</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row137" class="row_heading level0 row137" >4</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow137_col0" class="data row137 col0" >BsmtFinSF2</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow137_col1" class="data row137 col1" >3737.61</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow137_col2" class="data row137 col2" >4021.64</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow137_col3" class="data row137 col3" >0.929</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow137_col4" class="data row137 col4" >0.353</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow137_col5" class="data row137 col5" >-4155.55</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow137_col6" class="data row137 col6" >11600</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row138" class="row_heading level0 row138" >108</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow138_col0" class="data row138 col0" >BsmtExposure_None</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow138_col1" class="data row138 col1" >-11750</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow138_col2" class="data row138 col2" >30900</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow138_col3" class="data row138 col3" >-0.38</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow138_col4" class="data row138 col4" >0.704</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow138_col5" class="data row138 col5" >-72500</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow138_col6" class="data row138 col6" >49000</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row139" class="row_heading level0 row139" >107</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow139_col0" class="data row139 col0" >BsmtExposure_No</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow139_col1" class="data row139 col1" >-2451.54</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow139_col2" class="data row139 col2" >3432.09</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow139_col3" class="data row139 col3" >-0.714</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow139_col4" class="data row139 col4" >0.475</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow139_col5" class="data row139 col5" >-9187.6</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow139_col6" class="data row139 col6" >4284.53</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row140" class="row_heading level0 row140" >106</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow140_col0" class="data row140 col0" >BsmtExposure_Mn</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow140_col1" class="data row140 col1" >3454.76</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow140_col2" class="data row140 col2" >4688.21</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow140_col3" class="data row140 col3" >0.737</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow140_col4" class="data row140 col4" >0.461</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow140_col5" class="data row140 col5" >-5746.64</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow140_col6" class="data row140 col6" >12700</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row141" class="row_heading level0 row141" >105</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow141_col0" class="data row141 col0" >BsmtExposure_Gd</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow141_col1" class="data row141 col1" >26330</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow141_col2" class="data row141 col2" >4614.18</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow141_col3" class="data row141 col3" >5.706</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow141_col4" class="data row141 col4" >0</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow141_col5" class="data row141 col5" >17300</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow141_col6" class="data row141 col6" >35400</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row142" class="row_heading level0 row142" >104</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow142_col0" class="data row142 col0" >BsmtCond_None</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow142_col1" class="data row142 col1" >-401.654</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow142_col2" class="data row142 col2" >17500</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow142_col3" class="data row142 col3" >-0.023</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow142_col4" class="data row142 col4" >0.982</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow142_col5" class="data row142 col5" >-34700</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow142_col6" class="data row142 col6" >33900</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row143" class="row_heading level0 row143" >103</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow143_col0" class="data row143 col0" >BsmtCond_Low</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow143_col1" class="data row143 col1" >2562.67</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow143_col2" class="data row143 col2" >5023.99</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow143_col3" class="data row143 col3" >0.51</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow143_col4" class="data row143 col4" >0.61</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow143_col5" class="data row143 col5" >-7297.76</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow143_col6" class="data row143 col6" >12400</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row144" class="row_heading level0 row144" >72</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow144_col0" class="data row144 col0" >BldgType_TwnhsE</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow144_col1" class="data row144 col1" >-21240</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow144_col2" class="data row144 col2" >19900</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow144_col3" class="data row144 col3" >-1.065</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow144_col4" class="data row144 col4" >0.287</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow144_col5" class="data row144 col5" >-60400</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow144_col6" class="data row144 col6" >17900</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row145" class="row_heading level0 row145" >71</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow145_col0" class="data row145 col0" >BldgType_Twnhs</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow145_col1" class="data row145 col1" >-20000</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow145_col2" class="data row145 col2" >21200</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow145_col3" class="data row145 col3" >-0.942</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow145_col4" class="data row145 col4" >0.347</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow145_col5" class="data row145 col5" >-61700</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow145_col6" class="data row145 col6" >21700</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row146" class="row_heading level0 row146" >70</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow146_col0" class="data row146 col0" >BldgType_Duplex</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow146_col1" class="data row146 col1" >2146.45</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow146_col2" class="data row146 col2" >11500</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow146_col3" class="data row146 col3" >0.187</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow146_col4" class="data row146 col4" >0.852</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow146_col5" class="data row146 col5" >-20400</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow146_col6" class="data row146 col6" >24700</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row147" class="row_heading level0 row147" >69</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow147_col0" class="data row147 col0" >BldgType_2fmCon</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow147_col1" class="data row147 col1" >-7897.31</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow147_col2" class="data row147 col2" >11600</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow147_col3" class="data row147 col3" >-0.678</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow147_col4" class="data row147 col4" >0.498</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow147_col5" class="data row147 col5" >-30700</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow147_col6" class="data row147 col6" >15000</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row148" class="row_heading level0 row148" >16</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow148_col0" class="data row148 col0" >Age_Remod</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow148_col1" class="data row148 col1" >-121.605</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow148_col2" class="data row148 col2" >80.709</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow148_col3" class="data row148 col3" >-1.507</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow148_col4" class="data row148 col4" >0.132</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow148_col5" class="data row148 col5" >-280.011</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow148_col6" class="data row148 col6" >36.801</td> 
    </tr>    <tr> 
        <th id="T_874f8c76_48dd_11e9_8883_48d224c0b2dflevel0_row149" class="row_heading level0 row149" >17</th> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow149_col0" class="data row149 col0" >Age_Garage</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow149_col1" class="data row149 col1" >-2787.99</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow149_col2" class="data row149 col2" >1355.9</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow149_col3" class="data row149 col3" >-2.056</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow149_col4" class="data row149 col4" >0.04</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow149_col5" class="data row149 col5" >-5449.18</td> 
        <td id="T_874f8c76_48dd_11e9_8883_48d224c0b2dfrow149_col6" class="data row149 col6" >-126.807</td> 
    </tr></tbody> 
</table> 



Extracting the insignificant column names into  a variable.


```python
cols_to_drop = 'SznSold_Winter	SznSold_Summer	SznSold_Spring	Street_Pave	MSZoning_R	MSZoning_FV	LotShape_Reg	LotFrontage	LandSlope_Low	LandContour_N Lvl	KitchenAbvGr	HouseStyle_Split	HouseStyle_2+	HouseStyle_1.5	HeatingQC_Med	HeatingQC_Low	GarageType_None	GarageType_Detchd	GarageQual_None	GarageQual_Low	GarageFinish_Unf	GarageFinish_RFn	GarageFinish_None	GarageCond_None	GarageCond_Low	Foundation_PConc	Foundation_Other	Foundation_CBlock	FireplaceQu_None	FireplaceQu_Low	Fence_None	Fence_MnWw	Fence_MnPrv	Fence_GdWo	Exterior2nd_Wd Sdng	Exterior2nd_VinylSd	Exterior2nd_Plywood	Exterior2nd_Others	Exterior2nd_MetalSd	Exterior2nd_HdBoard	Exterior1st_Wd Sdng	Exterior1st_VinylSd	Exterior1st_Plywood	Exterior1st_Others	Exterior1st_MetalSd	Exterior1st_HdBoard	ExterQual_Low	ExterCond_Low	EnclosedPorch	Electrical_SBrkr	Condition1_RR	Condition1_Pos	Condition1_Norm	Condition1_Feedr	CentralAir_Y	BsmtUnfSF	BsmtQual_None	BsmtQual_Low	BsmtFinType2_None	BsmtFinType2_LwQ	BsmtFinType2_GLQ	BsmtFinType2_BLQ	BsmtFinType1_Unf	BsmtFinType1_Rec	BsmtFinType1_None	BsmtFinType1_LwQ	BsmtFinType1_GLQ	BsmtFinType1_BLQ	BsmtFinSF2	BsmtCond_None	BsmtCond_Low	Age_Remod	Age_Garage'
cols_to_drop = cols_to_drop.split('\t')
print(cols_to_drop)
```

    ['SznSold_Winter', 'SznSold_Summer', 'SznSold_Spring', 'Street_Pave', 'MSZoning_R', 'MSZoning_FV', 'LotShape_Reg', 'LotFrontage', 'LandSlope_Low', 'LandContour_N Lvl', 'KitchenAbvGr', 'HouseStyle_Split', 'HouseStyle_2+', 'HouseStyle_1.5', 'HeatingQC_Med', 'HeatingQC_Low', 'GarageType_None', 'GarageType_Detchd', 'GarageQual_None', 'GarageQual_Low', 'GarageFinish_Unf', 'GarageFinish_RFn', 'GarageFinish_None', 'GarageCond_None', 'GarageCond_Low', 'Foundation_PConc', 'Foundation_Other', 'Foundation_CBlock', 'FireplaceQu_None', 'FireplaceQu_Low', 'Fence_None', 'Fence_MnWw', 'Fence_MnPrv', 'Fence_GdWo', 'Exterior2nd_Wd Sdng', 'Exterior2nd_VinylSd', 'Exterior2nd_Plywood', 'Exterior2nd_Others', 'Exterior2nd_MetalSd', 'Exterior2nd_HdBoard', 'Exterior1st_Wd Sdng', 'Exterior1st_VinylSd', 'Exterior1st_Plywood', 'Exterior1st_Others', 'Exterior1st_MetalSd', 'Exterior1st_HdBoard', 'ExterQual_Low', 'ExterCond_Low', 'EnclosedPorch', 'Electrical_SBrkr', 'Condition1_RR', 'Condition1_Pos', 'Condition1_Norm', 'Condition1_Feedr', 'CentralAir_Y', 'BsmtUnfSF', 'BsmtQual_None', 'BsmtQual_Low', 'BsmtFinType2_None', 'BsmtFinType2_LwQ', 'BsmtFinType2_GLQ', 'BsmtFinType2_BLQ', 'BsmtFinType1_Unf', 'BsmtFinType1_Rec', 'BsmtFinType1_None', 'BsmtFinType1_LwQ', 'BsmtFinType1_GLQ', 'BsmtFinType1_BLQ', 'BsmtFinSF2', 'BsmtCond_None', 'BsmtCond_Low', 'Age_Remod', 'Age_Garage']
    


```python
print(df_train_x.shape, df_test_x.shape)
df_train_x = df_train_x.drop(cols_to_drop, axis = 1)
df_test_x  = df_test_x.drop(cols_to_drop, axis = 1)
print(df_train_x.shape, df_test_x.shape)
```

    (1021, 150) (438, 150)
    (1021, 77) (438, 77)
    

#### 4.3.2 Building Model No. 2


```python
lm_2 = sm.OLS(df_train_y, df_train_x).fit()
lm_2.summary()
```




<table class="simpletable">
<caption>OLS Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>        <td>SalePrice</td>    <th>  R-squared:         </th> <td>   0.857</td> 
</tr>
<tr>
  <th>Model:</th>                   <td>OLS</td>       <th>  Adj. R-squared:    </th> <td>   0.845</td> 
</tr>
<tr>
  <th>Method:</th>             <td>Least Squares</td>  <th>  F-statistic:       </th> <td>   76.41</td> 
</tr>
<tr>
  <th>Date:</th>             <td>Sun, 17 Mar 2019</td> <th>  Prob (F-statistic):</th>  <td>  0.00</td>  
</tr>
<tr>
  <th>Time:</th>                 <td>23:23:14</td>     <th>  Log-Likelihood:    </th> <td> -11976.</td> 
</tr>
<tr>
  <th>No. Observations:</th>      <td>  1021</td>      <th>  AIC:               </th> <td>2.410e+04</td>
</tr>
<tr>
  <th>Df Residuals:</th>          <td>   946</td>      <th>  BIC:               </th> <td>2.447e+04</td>
</tr>
<tr>
  <th>Df Model:</th>              <td>    74</td>      <th>                     </th>     <td> </td>    
</tr>
<tr>
  <th>Covariance Type:</th>      <td>nonrobust</td>    <th>                     </th>     <td> </td>    
</tr>
</table>
<table class="simpletable">
<tr>
            <td></td>               <th>coef</th>     <th>std err</th>      <th>t</th>      <th>P>|t|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>const</th>                 <td> 2.592e+04</td> <td> 4.68e+04</td> <td>    0.554</td> <td> 0.580</td> <td>-6.59e+04</td> <td> 1.18e+05</td>
</tr>
<tr>
  <th>LotArea</th>               <td> 1.789e+04</td> <td> 3307.328</td> <td>    5.409</td> <td> 0.000</td> <td> 1.14e+04</td> <td> 2.44e+04</td>
</tr>
<tr>
  <th>MasVnrArea</th>            <td> 1271.8234</td> <td> 1767.567</td> <td>    0.720</td> <td> 0.472</td> <td>-2196.983</td> <td> 4740.630</td>
</tr>
<tr>
  <th>BsmtFullBath</th>          <td> 1.568e+04</td> <td> 2321.703</td> <td>    6.753</td> <td> 0.000</td> <td> 1.11e+04</td> <td> 2.02e+04</td>
</tr>
<tr>
  <th>BsmtHalfBath</th>          <td> 6068.3030</td> <td> 6598.450</td> <td>    0.920</td> <td> 0.358</td> <td>-6880.989</td> <td>  1.9e+04</td>
</tr>
<tr>
  <th>FullBath</th>              <td> 2.863e+04</td> <td> 2810.661</td> <td>   10.187</td> <td> 0.000</td> <td> 2.31e+04</td> <td> 3.41e+04</td>
</tr>
<tr>
  <th>HalfBath</th>              <td> 1.345e+04</td> <td> 2901.020</td> <td>    4.635</td> <td> 0.000</td> <td> 7752.086</td> <td> 1.91e+04</td>
</tr>
<tr>
  <th>Fireplaces</th>            <td> 1.139e+04</td> <td> 1941.559</td> <td>    5.867</td> <td> 0.000</td> <td> 7580.290</td> <td> 1.52e+04</td>
</tr>
<tr>
  <th>WoodDeckSF</th>            <td>  540.3630</td> <td>  441.405</td> <td>    1.224</td> <td> 0.221</td> <td> -325.882</td> <td> 1406.608</td>
</tr>
<tr>
  <th>OpenPorchSF</th>           <td> 1834.9505</td> <td>  583.308</td> <td>    3.146</td> <td> 0.002</td> <td>  690.223</td> <td> 2979.678</td>
</tr>
<tr>
  <th>ScreenPorch</th>           <td> 1679.6558</td> <td>  755.392</td> <td>    2.224</td> <td> 0.026</td> <td>  197.218</td> <td> 3162.094</td>
</tr>
<tr>
  <th>MSSubClass_160</th>        <td> 7376.7661</td> <td> 8987.165</td> <td>    0.821</td> <td> 0.412</td> <td>-1.03e+04</td> <td>  2.5e+04</td>
</tr>
<tr>
  <th>MSSubClass_180</th>        <td> -320.6811</td> <td> 1.47e+04</td> <td>   -0.022</td> <td> 0.983</td> <td>-2.92e+04</td> <td> 2.86e+04</td>
</tr>
<tr>
  <th>MSSubClass_190</th>        <td>-2932.7589</td> <td> 1.07e+04</td> <td>   -0.273</td> <td> 0.785</td> <td> -2.4e+04</td> <td> 1.81e+04</td>
</tr>
<tr>
  <th>MSSubClass_20</th>         <td> 1.744e+04</td> <td> 1.99e+04</td> <td>    0.876</td> <td> 0.381</td> <td>-2.16e+04</td> <td> 5.65e+04</td>
</tr>
<tr>
  <th>MSSubClass_30</th>         <td>  -78.5385</td> <td> 2.06e+04</td> <td>   -0.004</td> <td> 0.997</td> <td>-4.06e+04</td> <td> 4.04e+04</td>
</tr>
<tr>
  <th>MSSubClass_40</th>         <td> 3.992e+04</td> <td> 2.96e+04</td> <td>    1.347</td> <td> 0.178</td> <td>-1.82e+04</td> <td> 9.81e+04</td>
</tr>
<tr>
  <th>MSSubClass_45</th>         <td> 1.111e+04</td> <td> 2.34e+04</td> <td>    0.475</td> <td> 0.635</td> <td>-3.48e+04</td> <td>  5.7e+04</td>
</tr>
<tr>
  <th>MSSubClass_50</th>         <td> 2.042e+04</td> <td> 2.03e+04</td> <td>    1.008</td> <td> 0.314</td> <td>-1.93e+04</td> <td> 6.02e+04</td>
</tr>
<tr>
  <th>MSSubClass_60</th>         <td> 1.774e+04</td> <td> 2.01e+04</td> <td>    0.884</td> <td> 0.377</td> <td>-2.17e+04</td> <td> 5.72e+04</td>
</tr>
<tr>
  <th>MSSubClass_70</th>         <td> 2.151e+04</td> <td> 2.09e+04</td> <td>    1.030</td> <td> 0.303</td> <td>-1.95e+04</td> <td> 6.25e+04</td>
</tr>
<tr>
  <th>MSSubClass_75</th>         <td> 4.071e+04</td> <td> 2.29e+04</td> <td>    1.776</td> <td> 0.076</td> <td>-4277.342</td> <td> 8.57e+04</td>
</tr>
<tr>
  <th>MSSubClass_80</th>         <td>  1.08e+04</td> <td> 2.05e+04</td> <td>    0.527</td> <td> 0.598</td> <td>-2.94e+04</td> <td>  5.1e+04</td>
</tr>
<tr>
  <th>MSSubClass_85</th>         <td> 8295.3294</td> <td>  2.2e+04</td> <td>    0.377</td> <td> 0.706</td> <td>-3.49e+04</td> <td> 5.15e+04</td>
</tr>
<tr>
  <th>MSSubClass_90</th>         <td> 2720.4022</td> <td> 1.04e+04</td> <td>    0.261</td> <td> 0.794</td> <td>-1.77e+04</td> <td> 2.32e+04</td>
</tr>
<tr>
  <th>LotConfig_CulDSac</th>     <td> 9711.6164</td> <td> 4631.465</td> <td>    2.097</td> <td> 0.036</td> <td>  622.483</td> <td> 1.88e+04</td>
</tr>
<tr>
  <th>LotConfig_FR</th>          <td>-1.202e+04</td> <td> 5444.333</td> <td>   -2.207</td> <td> 0.028</td> <td>-2.27e+04</td> <td>-1333.608</td>
</tr>
<tr>
  <th>LotConfig_Inside</th>      <td>-1010.3348</td> <td> 2656.498</td> <td>   -0.380</td> <td> 0.704</td> <td>-6223.645</td> <td> 4202.975</td>
</tr>
<tr>
  <th>Neighborhood_Blueste</th>  <td>-1.535e+04</td> <td>  2.6e+04</td> <td>   -0.591</td> <td> 0.555</td> <td>-6.63e+04</td> <td> 3.57e+04</td>
</tr>
<tr>
  <th>Neighborhood_BrDale</th>   <td>-2.149e+04</td> <td> 1.57e+04</td> <td>   -1.367</td> <td> 0.172</td> <td>-5.23e+04</td> <td> 9356.864</td>
</tr>
<tr>
  <th>Neighborhood_BrkSide</th>  <td>-2.997e+04</td> <td> 1.29e+04</td> <td>   -2.333</td> <td> 0.020</td> <td>-5.52e+04</td> <td>-4755.800</td>
</tr>
<tr>
  <th>Neighborhood_ClearCr</th>  <td>-1.301e+04</td> <td>  1.4e+04</td> <td>   -0.929</td> <td> 0.353</td> <td>-4.05e+04</td> <td> 1.45e+04</td>
</tr>
<tr>
  <th>Neighborhood_CollgCr</th>  <td>-1.908e+04</td> <td> 1.14e+04</td> <td>   -1.670</td> <td> 0.095</td> <td>-4.15e+04</td> <td> 3337.248</td>
</tr>
<tr>
  <th>Neighborhood_Crawfor</th>  <td>-6327.8198</td> <td> 1.26e+04</td> <td>   -0.501</td> <td> 0.617</td> <td>-3.11e+04</td> <td> 1.85e+04</td>
</tr>
<tr>
  <th>Neighborhood_Edwards</th>  <td>-4.698e+04</td> <td> 1.21e+04</td> <td>   -3.897</td> <td> 0.000</td> <td>-7.06e+04</td> <td>-2.33e+04</td>
</tr>
<tr>
  <th>Neighborhood_Gilbert</th>  <td>-3.198e+04</td> <td> 1.21e+04</td> <td>   -2.643</td> <td> 0.008</td> <td>-5.57e+04</td> <td>-8237.582</td>
</tr>
<tr>
  <th>Neighborhood_IDOTRR</th>   <td> -4.71e+04</td> <td> 1.32e+04</td> <td>   -3.564</td> <td> 0.000</td> <td> -7.3e+04</td> <td>-2.12e+04</td>
</tr>
<tr>
  <th>Neighborhood_MeadowV</th>  <td>-2.969e+04</td> <td> 1.56e+04</td> <td>   -1.907</td> <td> 0.057</td> <td>-6.02e+04</td> <td>  870.830</td>
</tr>
<tr>
  <th>Neighborhood_Mitchel</th>  <td>-3.081e+04</td> <td> 1.23e+04</td> <td>   -2.501</td> <td> 0.013</td> <td> -5.5e+04</td> <td>-6637.349</td>
</tr>
<tr>
  <th>Neighborhood_NAmes</th>    <td>-3.699e+04</td> <td> 1.17e+04</td> <td>   -3.171</td> <td> 0.002</td> <td>-5.99e+04</td> <td>-1.41e+04</td>
</tr>
<tr>
  <th>Neighborhood_NPkVill</th>  <td>-1.876e+04</td> <td> 1.72e+04</td> <td>   -1.091</td> <td> 0.275</td> <td>-5.25e+04</td> <td>  1.5e+04</td>
</tr>
<tr>
  <th>Neighborhood_NWAmes</th>   <td>-2.433e+04</td> <td> 1.23e+04</td> <td>   -1.984</td> <td> 0.048</td> <td>-4.84e+04</td> <td> -259.363</td>
</tr>
<tr>
  <th>Neighborhood_NoRidge</th>  <td> 3.713e+04</td> <td>  1.3e+04</td> <td>    2.856</td> <td> 0.004</td> <td> 1.16e+04</td> <td> 6.26e+04</td>
</tr>
<tr>
  <th>Neighborhood_NridgHt</th>  <td> 2.314e+04</td> <td> 1.19e+04</td> <td>    1.947</td> <td> 0.052</td> <td> -188.250</td> <td> 4.65e+04</td>
</tr>
<tr>
  <th>Neighborhood_OldTown</th>  <td>-4.197e+04</td> <td> 1.23e+04</td> <td>   -3.404</td> <td> 0.001</td> <td>-6.62e+04</td> <td>-1.78e+04</td>
</tr>
<tr>
  <th>Neighborhood_SWISU</th>    <td>-4.372e+04</td> <td> 1.39e+04</td> <td>   -3.146</td> <td> 0.002</td> <td> -7.1e+04</td> <td>-1.65e+04</td>
</tr>
<tr>
  <th>Neighborhood_Sawyer</th>   <td>-3.984e+04</td> <td> 1.21e+04</td> <td>   -3.282</td> <td> 0.001</td> <td>-6.37e+04</td> <td> -1.6e+04</td>
</tr>
<tr>
  <th>Neighborhood_SawyerW</th>  <td>-2.059e+04</td> <td>  1.2e+04</td> <td>   -1.722</td> <td> 0.085</td> <td>-4.41e+04</td> <td> 2880.549</td>
</tr>
<tr>
  <th>Neighborhood_Somerst</th>  <td>-9387.1775</td> <td> 1.18e+04</td> <td>   -0.796</td> <td> 0.426</td> <td>-3.25e+04</td> <td> 1.38e+04</td>
</tr>
<tr>
  <th>Neighborhood_StoneBr</th>  <td>  2.68e+04</td> <td> 1.29e+04</td> <td>    2.073</td> <td> 0.038</td> <td> 1431.490</td> <td> 5.22e+04</td>
</tr>
<tr>
  <th>Neighborhood_Timber</th>   <td>-2.592e+04</td> <td> 1.27e+04</td> <td>   -2.041</td> <td> 0.042</td> <td>-5.08e+04</td> <td> -992.954</td>
</tr>
<tr>
  <th>Neighborhood_Veenker</th>  <td>-1.576e+04</td> <td> 1.54e+04</td> <td>   -1.021</td> <td> 0.307</td> <td>-4.61e+04</td> <td> 1.45e+04</td>
</tr>
<tr>
  <th>BldgType_2fmCon</th>       <td>-2932.7589</td> <td> 1.07e+04</td> <td>   -0.273</td> <td> 0.785</td> <td> -2.4e+04</td> <td> 1.81e+04</td>
</tr>
<tr>
  <th>BldgType_Duplex</th>       <td> 2720.4022</td> <td> 1.04e+04</td> <td>    0.261</td> <td> 0.794</td> <td>-1.77e+04</td> <td> 2.32e+04</td>
</tr>
<tr>
  <th>BldgType_Twnhs</th>        <td>-6287.4394</td> <td> 2.12e+04</td> <td>   -0.296</td> <td> 0.767</td> <td> -4.8e+04</td> <td> 3.54e+04</td>
</tr>
<tr>
  <th>BldgType_TwnhsE</th>       <td>-4794.8841</td> <td> 1.99e+04</td> <td>   -0.241</td> <td> 0.809</td> <td>-4.38e+04</td> <td> 3.42e+04</td>
</tr>
<tr>
  <th>OverallQual_Low</th>       <td>-4.728e+04</td> <td> 5858.898</td> <td>   -8.069</td> <td> 0.000</td> <td>-5.88e+04</td> <td>-3.58e+04</td>
</tr>
<tr>
  <th>OverallQual_Med</th>       <td>-4.137e+04</td> <td> 4049.899</td> <td>  -10.216</td> <td> 0.000</td> <td>-4.93e+04</td> <td>-3.34e+04</td>
</tr>
<tr>
  <th>OverallCond_Bad</th>       <td>-1.471e+04</td> <td> 4752.045</td> <td>   -3.095</td> <td> 0.002</td> <td> -2.4e+04</td> <td>-5383.509</td>
</tr>
<tr>
  <th>OverallCond_Good</th>      <td> 4929.9457</td> <td> 2726.289</td> <td>    1.808</td> <td> 0.071</td> <td> -420.328</td> <td> 1.03e+04</td>
</tr>
<tr>
  <th>RoofStyle_Hip</th>         <td> 1.078e+04</td> <td> 2808.955</td> <td>    3.838</td> <td> 0.000</td> <td> 5268.911</td> <td> 1.63e+04</td>
</tr>
<tr>
  <th>RoofStyle_Others</th>      <td>  878.7594</td> <td> 7726.929</td> <td>    0.114</td> <td> 0.909</td> <td>-1.43e+04</td> <td>  1.6e+04</td>
</tr>
<tr>
  <th>MasVnrType_None</th>       <td> 4916.3105</td> <td> 9364.925</td> <td>    0.525</td> <td> 0.600</td> <td>-1.35e+04</td> <td> 2.33e+04</td>
</tr>
<tr>
  <th>MasVnrType_Stone</th>      <td> 5348.1283</td> <td> 4332.442</td> <td>    1.234</td> <td> 0.217</td> <td>-3154.181</td> <td> 1.39e+04</td>
</tr>
<tr>
  <th>BsmtExposure_Gd</th>       <td> 2.723e+04</td> <td> 4522.973</td> <td>    6.021</td> <td> 0.000</td> <td> 1.84e+04</td> <td> 3.61e+04</td>
</tr>
<tr>
  <th>BsmtExposure_Mn</th>       <td> 2889.9088</td> <td> 4689.199</td> <td>    0.616</td> <td> 0.538</td> <td>-6312.526</td> <td> 1.21e+04</td>
</tr>
<tr>
  <th>BsmtExposure_No</th>       <td>-3138.0197</td> <td> 3411.634</td> <td>   -0.920</td> <td> 0.358</td> <td>-9833.266</td> <td> 3557.226</td>
</tr>
<tr>
  <th>BsmtExposure_None</th>     <td>-1.339e+04</td> <td> 8294.483</td> <td>   -1.615</td> <td> 0.107</td> <td>-2.97e+04</td> <td> 2882.879</td>
</tr>
<tr>
  <th>BsmtFinType2_Rec</th>      <td> -485.8286</td> <td> 6319.420</td> <td>   -0.077</td> <td> 0.939</td> <td>-1.29e+04</td> <td> 1.19e+04</td>
</tr>
<tr>
  <th>BsmtFinType2_Unf</th>      <td> 3385.3291</td> <td> 3964.071</td> <td>    0.854</td> <td> 0.393</td> <td>-4394.060</td> <td> 1.12e+04</td>
</tr>
<tr>
  <th>KitchenQual_Low</th>       <td>-6.079e+04</td> <td> 5231.180</td> <td>  -11.620</td> <td> 0.000</td> <td>-7.11e+04</td> <td>-5.05e+04</td>
</tr>
<tr>
  <th>KitchenQual_Med</th>       <td>-5.112e+04</td> <td> 4741.695</td> <td>  -10.781</td> <td> 0.000</td> <td>-6.04e+04</td> <td>-4.18e+04</td>
</tr>
<tr>
  <th>SaleType_Other</th>        <td> 6882.6476</td> <td> 3.28e+04</td> <td>    0.210</td> <td> 0.834</td> <td>-5.75e+04</td> <td> 7.12e+04</td>
</tr>
<tr>
  <th>SaleType_WD</th>           <td> 1183.6113</td> <td> 3.23e+04</td> <td>    0.037</td> <td> 0.971</td> <td>-6.23e+04</td> <td> 6.46e+04</td>
</tr>
<tr>
  <th>SaleCondition_Normal</th>  <td> 5574.6637</td> <td> 4193.565</td> <td>    1.329</td> <td> 0.184</td> <td>-2655.101</td> <td> 1.38e+04</td>
</tr>
<tr>
  <th>SaleCondition_Other</th>   <td> 3363.4474</td> <td> 7837.969</td> <td>    0.429</td> <td> 0.668</td> <td> -1.2e+04</td> <td> 1.87e+04</td>
</tr>
<tr>
  <th>SaleCondition_Partial</th> <td> 2.957e+04</td> <td> 3.23e+04</td> <td>    0.916</td> <td> 0.360</td> <td>-3.38e+04</td> <td> 9.29e+04</td>
</tr>
</table>
<table class="simpletable">
<tr>
  <th>Omnibus:</th>       <td>431.065</td> <th>  Durbin-Watson:     </th> <td>   1.998</td> 
</tr>
<tr>
  <th>Prob(Omnibus):</th> <td> 0.000</td>  <th>  Jarque-Bera (JB):  </th> <td>13695.141</td>
</tr>
<tr>
  <th>Skew:</th>          <td> 1.293</td>  <th>  Prob(JB):          </th> <td>    0.00</td> 
</tr>
<tr>
  <th>Kurtosis:</th>      <td>20.755</td>  <th>  Cond. No.          </th> <td>1.01e+16</td> 
</tr>
</table><br/><br/>Warnings:<br/>[1] Standard Errors assume that the covariance matrix of the errors is correctly specified.<br/>[2] The smallest eigenvalue is 1.09e-27. This might indicate that there are<br/>strong multicollinearity problems or that the design matrix is singular.




```python
rmse_2 = rmse(lm_2, df_test_x, df_test_y)
rmse_2_log_scale = rmse_log_scale(lm_2, df_test_x, df_test_y)
print(rmse_2, rmse_2_log_scale, sep = '\n')
```

    37868.6155
    0.1798
    

With just a bit of a decline in R-squared value (0.87 -> 0.85) and RMSE, which is quite understandable considering we have eliminated a lot of insignificant variables, we have actually made quite an improvement in our model.
>* The much better characteristic i.e. the Adjusted R-squared hasn't decreased by much (barely by 0.05)
>* Enormous gains on our F-statistic which has almost doubled from being in 40s to now in 70s.

But, there are still a few things left to fix.
>* The warning of multicollinearity still persists.
>* There are new insignificant variables now which need to be eliminated.

We will reiterate some of the previous steps and quickly get rid of the insignificant variables.

#### 4.4 Model No. 3
#### 4.4.1 Removing Insignificant Variables


```python
results_as_html = lm_2.summary().tables[1].as_html()
results_df = pd.read_html(results_as_html, header=0, index_col=0)[0]
results_df = results_df.reset_index()
results_df.sort_values(['index', 'P>|t|']).style.applymap(p_sig, subset = ['P>|t|'])
```




<style  type="text/css" >
    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow0_col4 {
            color:  red;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow1_col4 {
            color:  red;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow2_col4 {
            color:  red;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow3_col4 {
            color:  red;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow4_col4 {
            color:  black;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow5_col4 {
            color:  red;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow6_col4 {
            color:  red;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow7_col4 {
            color:  red;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow8_col4 {
            color:  red;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow9_col4 {
            color:  red;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow10_col4 {
            color:  black;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow11_col4 {
            color:  red;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow12_col4 {
            color:  black;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow13_col4 {
            color:  black;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow14_col4 {
            color:  black;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow15_col4 {
            color:  black;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow16_col4 {
            color:  black;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow17_col4 {
            color:  black;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow18_col4 {
            color:  black;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow19_col4 {
            color:  black;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow20_col4 {
            color:  red;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow21_col4 {
            color:  red;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow22_col4 {
            color:  red;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow23_col4 {
            color:  red;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow24_col4 {
            color:  red;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow25_col4 {
            color:  red;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow26_col4 {
            color:  red;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow27_col4 {
            color:  red;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow28_col4 {
            color:  red;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow29_col4 {
            color:  red;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow30_col4 {
            color:  red;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow31_col4 {
            color:  red;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow32_col4 {
            color:  red;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow33_col4 {
            color:  red;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow34_col4 {
            color:  red;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow35_col4 {
            color:  red;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow36_col4 {
            color:  red;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow37_col4 {
            color:  red;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow38_col4 {
            color:  red;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow39_col4 {
            color:  red;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow40_col4 {
            color:  black;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow41_col4 {
            color:  red;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow42_col4 {
            color:  red;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow43_col4 {
            color:  red;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow44_col4 {
            color:  black;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow45_col4 {
            color:  black;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow46_col4 {
            color:  black;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow47_col4 {
            color:  red;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow48_col4 {
            color:  black;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow49_col4 {
            color:  black;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow50_col4 {
            color:  red;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow51_col4 {
            color:  black;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow52_col4 {
            color:  black;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow53_col4 {
            color:  red;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow54_col4 {
            color:  black;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow55_col4 {
            color:  black;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow56_col4 {
            color:  black;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow57_col4 {
            color:  red;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow58_col4 {
            color:  red;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow59_col4 {
            color:  black;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow60_col4 {
            color:  black;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow61_col4 {
            color:  red;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow62_col4 {
            color:  black;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow63_col4 {
            color:  black;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow64_col4 {
            color:  red;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow65_col4 {
            color:  black;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow66_col4 {
            color:  black;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow67_col4 {
            color:  black;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow68_col4 {
            color:  red;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow69_col4 {
            color:  red;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow70_col4 {
            color:  red;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow71_col4 {
            color:  red;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow72_col4 {
            color:  red;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow73_col4 {
            color:  red;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow74_col4 {
            color:  black;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow75_col4 {
            color:  red;
        }    #T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow76_col4 {
            color:  red;
        }</style>  
<table id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2df" > 
<thead>    <tr> 
        <th class="blank level0" ></th> 
        <th class="col_heading level0 col0" >index</th> 
        <th class="col_heading level0 col1" >coef</th> 
        <th class="col_heading level0 col2" >std err</th> 
        <th class="col_heading level0 col3" >t</th> 
        <th class="col_heading level0 col4" >P>|t|</th> 
        <th class="col_heading level0 col5" >[0.025</th> 
        <th class="col_heading level0 col6" >0.975]</th> 
    </tr></thead> 
<tbody>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row0" class="row_heading level0 row0" >52</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow0_col0" class="data row0 col0" >BldgType_2fmCon</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow0_col1" class="data row0 col1" >-2932.76</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow0_col2" class="data row0 col2" >10700</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow0_col3" class="data row0 col3" >-0.273</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow0_col4" class="data row0 col4" >0.785</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow0_col5" class="data row0 col5" >-24000</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow0_col6" class="data row0 col6" >18100</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row1" class="row_heading level0 row1" >53</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow1_col0" class="data row1 col0" >BldgType_Duplex</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow1_col1" class="data row1 col1" >2720.4</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow1_col2" class="data row1 col2" >10400</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow1_col3" class="data row1 col3" >0.261</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow1_col4" class="data row1 col4" >0.794</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow1_col5" class="data row1 col5" >-17700</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow1_col6" class="data row1 col6" >23200</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row2" class="row_heading level0 row2" >54</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow2_col0" class="data row2 col0" >BldgType_Twnhs</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow2_col1" class="data row2 col1" >-6287.44</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow2_col2" class="data row2 col2" >21200</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow2_col3" class="data row2 col3" >-0.296</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow2_col4" class="data row2 col4" >0.767</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow2_col5" class="data row2 col5" >-48000</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow2_col6" class="data row2 col6" >35400</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row3" class="row_heading level0 row3" >55</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow3_col0" class="data row3 col0" >BldgType_TwnhsE</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow3_col1" class="data row3 col1" >-4794.88</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow3_col2" class="data row3 col2" >19900</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow3_col3" class="data row3 col3" >-0.241</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow3_col4" class="data row3 col4" >0.809</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow3_col5" class="data row3 col5" >-43800</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow3_col6" class="data row3 col6" >34200</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row4" class="row_heading level0 row4" >64</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow4_col0" class="data row4 col0" >BsmtExposure_Gd</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow4_col1" class="data row4 col1" >27230</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow4_col2" class="data row4 col2" >4522.97</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow4_col3" class="data row4 col3" >6.021</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow4_col4" class="data row4 col4" >0</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow4_col5" class="data row4 col5" >18400</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow4_col6" class="data row4 col6" >36100</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row5" class="row_heading level0 row5" >65</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow5_col0" class="data row5 col0" >BsmtExposure_Mn</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow5_col1" class="data row5 col1" >2889.91</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow5_col2" class="data row5 col2" >4689.2</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow5_col3" class="data row5 col3" >0.616</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow5_col4" class="data row5 col4" >0.538</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow5_col5" class="data row5 col5" >-6312.53</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow5_col6" class="data row5 col6" >12100</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row6" class="row_heading level0 row6" >66</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow6_col0" class="data row6 col0" >BsmtExposure_No</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow6_col1" class="data row6 col1" >-3138.02</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow6_col2" class="data row6 col2" >3411.63</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow6_col3" class="data row6 col3" >-0.92</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow6_col4" class="data row6 col4" >0.358</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow6_col5" class="data row6 col5" >-9833.27</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow6_col6" class="data row6 col6" >3557.23</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row7" class="row_heading level0 row7" >67</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow7_col0" class="data row7 col0" >BsmtExposure_None</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow7_col1" class="data row7 col1" >-13390</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow7_col2" class="data row7 col2" >8294.48</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow7_col3" class="data row7 col3" >-1.615</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow7_col4" class="data row7 col4" >0.107</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow7_col5" class="data row7 col5" >-29700</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow7_col6" class="data row7 col6" >2882.88</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row8" class="row_heading level0 row8" >68</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow8_col0" class="data row8 col0" >BsmtFinType2_Rec</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow8_col1" class="data row8 col1" >-485.829</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow8_col2" class="data row8 col2" >6319.42</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow8_col3" class="data row8 col3" >-0.077</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow8_col4" class="data row8 col4" >0.939</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow8_col5" class="data row8 col5" >-12900</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow8_col6" class="data row8 col6" >11900</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row9" class="row_heading level0 row9" >69</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow9_col0" class="data row9 col0" >BsmtFinType2_Unf</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow9_col1" class="data row9 col1" >3385.33</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow9_col2" class="data row9 col2" >3964.07</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow9_col3" class="data row9 col3" >0.854</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow9_col4" class="data row9 col4" >0.393</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow9_col5" class="data row9 col5" >-4394.06</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow9_col6" class="data row9 col6" >11200</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row10" class="row_heading level0 row10" >3</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow10_col0" class="data row10 col0" >BsmtFullBath</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow10_col1" class="data row10 col1" >15680</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow10_col2" class="data row10 col2" >2321.7</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow10_col3" class="data row10 col3" >6.753</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow10_col4" class="data row10 col4" >0</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow10_col5" class="data row10 col5" >11100</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow10_col6" class="data row10 col6" >20200</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row11" class="row_heading level0 row11" >4</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow11_col0" class="data row11 col0" >BsmtHalfBath</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow11_col1" class="data row11 col1" >6068.3</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow11_col2" class="data row11 col2" >6598.45</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow11_col3" class="data row11 col3" >0.92</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow11_col4" class="data row11 col4" >0.358</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow11_col5" class="data row11 col5" >-6880.99</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow11_col6" class="data row11 col6" >19000</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row12" class="row_heading level0 row12" >7</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow12_col0" class="data row12 col0" >Fireplaces</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow12_col1" class="data row12 col1" >11390</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow12_col2" class="data row12 col2" >1941.56</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow12_col3" class="data row12 col3" >5.867</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow12_col4" class="data row12 col4" >0</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow12_col5" class="data row12 col5" >7580.29</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow12_col6" class="data row12 col6" >15200</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row13" class="row_heading level0 row13" >5</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow13_col0" class="data row13 col0" >FullBath</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow13_col1" class="data row13 col1" >28630</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow13_col2" class="data row13 col2" >2810.66</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow13_col3" class="data row13 col3" >10.187</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow13_col4" class="data row13 col4" >0</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow13_col5" class="data row13 col5" >23100</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow13_col6" class="data row13 col6" >34100</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row14" class="row_heading level0 row14" >6</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow14_col0" class="data row14 col0" >HalfBath</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow14_col1" class="data row14 col1" >13450</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow14_col2" class="data row14 col2" >2901.02</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow14_col3" class="data row14 col3" >4.635</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow14_col4" class="data row14 col4" >0</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow14_col5" class="data row14 col5" >7752.09</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow14_col6" class="data row14 col6" >19100</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row15" class="row_heading level0 row15" >70</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow15_col0" class="data row15 col0" >KitchenQual_Low</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow15_col1" class="data row15 col1" >-60790</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow15_col2" class="data row15 col2" >5231.18</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow15_col3" class="data row15 col3" >-11.62</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow15_col4" class="data row15 col4" >0</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow15_col5" class="data row15 col5" >-71100</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow15_col6" class="data row15 col6" >-50500</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row16" class="row_heading level0 row16" >71</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow16_col0" class="data row16 col0" >KitchenQual_Med</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow16_col1" class="data row16 col1" >-51120</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow16_col2" class="data row16 col2" >4741.69</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow16_col3" class="data row16 col3" >-10.781</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow16_col4" class="data row16 col4" >0</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow16_col5" class="data row16 col5" >-60400</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow16_col6" class="data row16 col6" >-41800</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row17" class="row_heading level0 row17" >1</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow17_col0" class="data row17 col0" >LotArea</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow17_col1" class="data row17 col1" >17890</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow17_col2" class="data row17 col2" >3307.33</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow17_col3" class="data row17 col3" >5.409</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow17_col4" class="data row17 col4" >0</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow17_col5" class="data row17 col5" >11400</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow17_col6" class="data row17 col6" >24400</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row18" class="row_heading level0 row18" >25</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow18_col0" class="data row18 col0" >LotConfig_CulDSac</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow18_col1" class="data row18 col1" >9711.62</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow18_col2" class="data row18 col2" >4631.47</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow18_col3" class="data row18 col3" >2.097</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow18_col4" class="data row18 col4" >0.036</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow18_col5" class="data row18 col5" >622.483</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow18_col6" class="data row18 col6" >18800</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row19" class="row_heading level0 row19" >26</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow19_col0" class="data row19 col0" >LotConfig_FR</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow19_col1" class="data row19 col1" >-12020</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow19_col2" class="data row19 col2" >5444.33</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow19_col3" class="data row19 col3" >-2.207</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow19_col4" class="data row19 col4" >0.028</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow19_col5" class="data row19 col5" >-22700</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow19_col6" class="data row19 col6" >-1333.61</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row20" class="row_heading level0 row20" >27</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow20_col0" class="data row20 col0" >LotConfig_Inside</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow20_col1" class="data row20 col1" >-1010.33</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow20_col2" class="data row20 col2" >2656.5</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow20_col3" class="data row20 col3" >-0.38</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow20_col4" class="data row20 col4" >0.704</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow20_col5" class="data row20 col5" >-6223.65</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow20_col6" class="data row20 col6" >4202.98</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row21" class="row_heading level0 row21" >11</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow21_col0" class="data row21 col0" >MSSubClass_160</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow21_col1" class="data row21 col1" >7376.77</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow21_col2" class="data row21 col2" >8987.17</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow21_col3" class="data row21 col3" >0.821</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow21_col4" class="data row21 col4" >0.412</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow21_col5" class="data row21 col5" >-10300</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow21_col6" class="data row21 col6" >25000</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row22" class="row_heading level0 row22" >12</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow22_col0" class="data row22 col0" >MSSubClass_180</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow22_col1" class="data row22 col1" >-320.681</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow22_col2" class="data row22 col2" >14700</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow22_col3" class="data row22 col3" >-0.022</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow22_col4" class="data row22 col4" >0.983</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow22_col5" class="data row22 col5" >-29200</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow22_col6" class="data row22 col6" >28600</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row23" class="row_heading level0 row23" >13</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow23_col0" class="data row23 col0" >MSSubClass_190</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow23_col1" class="data row23 col1" >-2932.76</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow23_col2" class="data row23 col2" >10700</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow23_col3" class="data row23 col3" >-0.273</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow23_col4" class="data row23 col4" >0.785</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow23_col5" class="data row23 col5" >-24000</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow23_col6" class="data row23 col6" >18100</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row24" class="row_heading level0 row24" >14</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow24_col0" class="data row24 col0" >MSSubClass_20</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow24_col1" class="data row24 col1" >17440</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow24_col2" class="data row24 col2" >19900</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow24_col3" class="data row24 col3" >0.876</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow24_col4" class="data row24 col4" >0.381</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow24_col5" class="data row24 col5" >-21600</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow24_col6" class="data row24 col6" >56500</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row25" class="row_heading level0 row25" >15</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow25_col0" class="data row25 col0" >MSSubClass_30</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow25_col1" class="data row25 col1" >-78.5385</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow25_col2" class="data row25 col2" >20600</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow25_col3" class="data row25 col3" >-0.004</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow25_col4" class="data row25 col4" >0.997</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow25_col5" class="data row25 col5" >-40600</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow25_col6" class="data row25 col6" >40400</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row26" class="row_heading level0 row26" >16</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow26_col0" class="data row26 col0" >MSSubClass_40</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow26_col1" class="data row26 col1" >39920</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow26_col2" class="data row26 col2" >29600</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow26_col3" class="data row26 col3" >1.347</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow26_col4" class="data row26 col4" >0.178</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow26_col5" class="data row26 col5" >-18200</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow26_col6" class="data row26 col6" >98100</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row27" class="row_heading level0 row27" >17</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow27_col0" class="data row27 col0" >MSSubClass_45</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow27_col1" class="data row27 col1" >11110</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow27_col2" class="data row27 col2" >23400</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow27_col3" class="data row27 col3" >0.475</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow27_col4" class="data row27 col4" >0.635</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow27_col5" class="data row27 col5" >-34800</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow27_col6" class="data row27 col6" >57000</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row28" class="row_heading level0 row28" >18</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow28_col0" class="data row28 col0" >MSSubClass_50</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow28_col1" class="data row28 col1" >20420</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow28_col2" class="data row28 col2" >20300</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow28_col3" class="data row28 col3" >1.008</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow28_col4" class="data row28 col4" >0.314</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow28_col5" class="data row28 col5" >-19300</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow28_col6" class="data row28 col6" >60200</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row29" class="row_heading level0 row29" >19</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow29_col0" class="data row29 col0" >MSSubClass_60</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow29_col1" class="data row29 col1" >17740</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow29_col2" class="data row29 col2" >20100</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow29_col3" class="data row29 col3" >0.884</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow29_col4" class="data row29 col4" >0.377</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow29_col5" class="data row29 col5" >-21700</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow29_col6" class="data row29 col6" >57200</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row30" class="row_heading level0 row30" >20</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow30_col0" class="data row30 col0" >MSSubClass_70</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow30_col1" class="data row30 col1" >21510</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow30_col2" class="data row30 col2" >20900</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow30_col3" class="data row30 col3" >1.03</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow30_col4" class="data row30 col4" >0.303</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow30_col5" class="data row30 col5" >-19500</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow30_col6" class="data row30 col6" >62500</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row31" class="row_heading level0 row31" >21</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow31_col0" class="data row31 col0" >MSSubClass_75</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow31_col1" class="data row31 col1" >40710</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow31_col2" class="data row31 col2" >22900</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow31_col3" class="data row31 col3" >1.776</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow31_col4" class="data row31 col4" >0.076</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow31_col5" class="data row31 col5" >-4277.34</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow31_col6" class="data row31 col6" >85700</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row32" class="row_heading level0 row32" >22</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow32_col0" class="data row32 col0" >MSSubClass_80</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow32_col1" class="data row32 col1" >10800</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow32_col2" class="data row32 col2" >20500</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow32_col3" class="data row32 col3" >0.527</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow32_col4" class="data row32 col4" >0.598</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow32_col5" class="data row32 col5" >-29400</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow32_col6" class="data row32 col6" >51000</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row33" class="row_heading level0 row33" >23</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow33_col0" class="data row33 col0" >MSSubClass_85</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow33_col1" class="data row33 col1" >8295.33</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow33_col2" class="data row33 col2" >22000</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow33_col3" class="data row33 col3" >0.377</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow33_col4" class="data row33 col4" >0.706</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow33_col5" class="data row33 col5" >-34900</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow33_col6" class="data row33 col6" >51500</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row34" class="row_heading level0 row34" >24</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow34_col0" class="data row34 col0" >MSSubClass_90</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow34_col1" class="data row34 col1" >2720.4</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow34_col2" class="data row34 col2" >10400</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow34_col3" class="data row34 col3" >0.261</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow34_col4" class="data row34 col4" >0.794</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow34_col5" class="data row34 col5" >-17700</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow34_col6" class="data row34 col6" >23200</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row35" class="row_heading level0 row35" >2</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow35_col0" class="data row35 col0" >MasVnrArea</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow35_col1" class="data row35 col1" >1271.82</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow35_col2" class="data row35 col2" >1767.57</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow35_col3" class="data row35 col3" >0.72</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow35_col4" class="data row35 col4" >0.472</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow35_col5" class="data row35 col5" >-2196.98</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow35_col6" class="data row35 col6" >4740.63</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row36" class="row_heading level0 row36" >62</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow36_col0" class="data row36 col0" >MasVnrType_None</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow36_col1" class="data row36 col1" >4916.31</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow36_col2" class="data row36 col2" >9364.92</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow36_col3" class="data row36 col3" >0.525</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow36_col4" class="data row36 col4" >0.6</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow36_col5" class="data row36 col5" >-13500</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow36_col6" class="data row36 col6" >23300</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row37" class="row_heading level0 row37" >63</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow37_col0" class="data row37 col0" >MasVnrType_Stone</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow37_col1" class="data row37 col1" >5348.13</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow37_col2" class="data row37 col2" >4332.44</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow37_col3" class="data row37 col3" >1.234</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow37_col4" class="data row37 col4" >0.217</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow37_col5" class="data row37 col5" >-3154.18</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow37_col6" class="data row37 col6" >13900</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row38" class="row_heading level0 row38" >28</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow38_col0" class="data row38 col0" >Neighborhood_Blueste</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow38_col1" class="data row38 col1" >-15350</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow38_col2" class="data row38 col2" >26000</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow38_col3" class="data row38 col3" >-0.591</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow38_col4" class="data row38 col4" >0.555</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow38_col5" class="data row38 col5" >-66300</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow38_col6" class="data row38 col6" >35700</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row39" class="row_heading level0 row39" >29</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow39_col0" class="data row39 col0" >Neighborhood_BrDale</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow39_col1" class="data row39 col1" >-21490</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow39_col2" class="data row39 col2" >15700</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow39_col3" class="data row39 col3" >-1.367</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow39_col4" class="data row39 col4" >0.172</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow39_col5" class="data row39 col5" >-52300</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow39_col6" class="data row39 col6" >9356.86</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row40" class="row_heading level0 row40" >30</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow40_col0" class="data row40 col0" >Neighborhood_BrkSide</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow40_col1" class="data row40 col1" >-29970</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow40_col2" class="data row40 col2" >12900</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow40_col3" class="data row40 col3" >-2.333</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow40_col4" class="data row40 col4" >0.02</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow40_col5" class="data row40 col5" >-55200</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow40_col6" class="data row40 col6" >-4755.8</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row41" class="row_heading level0 row41" >31</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow41_col0" class="data row41 col0" >Neighborhood_ClearCr</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow41_col1" class="data row41 col1" >-13010</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow41_col2" class="data row41 col2" >14000</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow41_col3" class="data row41 col3" >-0.929</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow41_col4" class="data row41 col4" >0.353</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow41_col5" class="data row41 col5" >-40500</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow41_col6" class="data row41 col6" >14500</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row42" class="row_heading level0 row42" >32</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow42_col0" class="data row42 col0" >Neighborhood_CollgCr</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow42_col1" class="data row42 col1" >-19080</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow42_col2" class="data row42 col2" >11400</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow42_col3" class="data row42 col3" >-1.67</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow42_col4" class="data row42 col4" >0.095</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow42_col5" class="data row42 col5" >-41500</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow42_col6" class="data row42 col6" >3337.25</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row43" class="row_heading level0 row43" >33</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow43_col0" class="data row43 col0" >Neighborhood_Crawfor</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow43_col1" class="data row43 col1" >-6327.82</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow43_col2" class="data row43 col2" >12600</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow43_col3" class="data row43 col3" >-0.501</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow43_col4" class="data row43 col4" >0.617</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow43_col5" class="data row43 col5" >-31100</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow43_col6" class="data row43 col6" >18500</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row44" class="row_heading level0 row44" >34</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow44_col0" class="data row44 col0" >Neighborhood_Edwards</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow44_col1" class="data row44 col1" >-46980</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow44_col2" class="data row44 col2" >12100</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow44_col3" class="data row44 col3" >-3.897</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow44_col4" class="data row44 col4" >0</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow44_col5" class="data row44 col5" >-70600</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow44_col6" class="data row44 col6" >-23300</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row45" class="row_heading level0 row45" >35</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow45_col0" class="data row45 col0" >Neighborhood_Gilbert</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow45_col1" class="data row45 col1" >-31980</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow45_col2" class="data row45 col2" >12100</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow45_col3" class="data row45 col3" >-2.643</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow45_col4" class="data row45 col4" >0.008</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow45_col5" class="data row45 col5" >-55700</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow45_col6" class="data row45 col6" >-8237.58</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row46" class="row_heading level0 row46" >36</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow46_col0" class="data row46 col0" >Neighborhood_IDOTRR</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow46_col1" class="data row46 col1" >-47100</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow46_col2" class="data row46 col2" >13200</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow46_col3" class="data row46 col3" >-3.564</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow46_col4" class="data row46 col4" >0</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow46_col5" class="data row46 col5" >-73000</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow46_col6" class="data row46 col6" >-21200</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row47" class="row_heading level0 row47" >37</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow47_col0" class="data row47 col0" >Neighborhood_MeadowV</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow47_col1" class="data row47 col1" >-29690</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow47_col2" class="data row47 col2" >15600</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow47_col3" class="data row47 col3" >-1.907</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow47_col4" class="data row47 col4" >0.057</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow47_col5" class="data row47 col5" >-60200</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow47_col6" class="data row47 col6" >870.83</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row48" class="row_heading level0 row48" >38</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow48_col0" class="data row48 col0" >Neighborhood_Mitchel</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow48_col1" class="data row48 col1" >-30810</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow48_col2" class="data row48 col2" >12300</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow48_col3" class="data row48 col3" >-2.501</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow48_col4" class="data row48 col4" >0.013</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow48_col5" class="data row48 col5" >-55000</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow48_col6" class="data row48 col6" >-6637.35</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row49" class="row_heading level0 row49" >39</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow49_col0" class="data row49 col0" >Neighborhood_NAmes</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow49_col1" class="data row49 col1" >-36990</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow49_col2" class="data row49 col2" >11700</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow49_col3" class="data row49 col3" >-3.171</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow49_col4" class="data row49 col4" >0.002</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow49_col5" class="data row49 col5" >-59900</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow49_col6" class="data row49 col6" >-14100</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row50" class="row_heading level0 row50" >40</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow50_col0" class="data row50 col0" >Neighborhood_NPkVill</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow50_col1" class="data row50 col1" >-18760</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow50_col2" class="data row50 col2" >17200</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow50_col3" class="data row50 col3" >-1.091</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow50_col4" class="data row50 col4" >0.275</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow50_col5" class="data row50 col5" >-52500</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow50_col6" class="data row50 col6" >15000</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row51" class="row_heading level0 row51" >41</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow51_col0" class="data row51 col0" >Neighborhood_NWAmes</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow51_col1" class="data row51 col1" >-24330</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow51_col2" class="data row51 col2" >12300</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow51_col3" class="data row51 col3" >-1.984</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow51_col4" class="data row51 col4" >0.048</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow51_col5" class="data row51 col5" >-48400</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow51_col6" class="data row51 col6" >-259.363</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row52" class="row_heading level0 row52" >42</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow52_col0" class="data row52 col0" >Neighborhood_NoRidge</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow52_col1" class="data row52 col1" >37130</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow52_col2" class="data row52 col2" >13000</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow52_col3" class="data row52 col3" >2.856</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow52_col4" class="data row52 col4" >0.004</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow52_col5" class="data row52 col5" >11600</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow52_col6" class="data row52 col6" >62600</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row53" class="row_heading level0 row53" >43</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow53_col0" class="data row53 col0" >Neighborhood_NridgHt</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow53_col1" class="data row53 col1" >23140</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow53_col2" class="data row53 col2" >11900</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow53_col3" class="data row53 col3" >1.947</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow53_col4" class="data row53 col4" >0.052</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow53_col5" class="data row53 col5" >-188.25</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow53_col6" class="data row53 col6" >46500</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row54" class="row_heading level0 row54" >44</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow54_col0" class="data row54 col0" >Neighborhood_OldTown</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow54_col1" class="data row54 col1" >-41970</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow54_col2" class="data row54 col2" >12300</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow54_col3" class="data row54 col3" >-3.404</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow54_col4" class="data row54 col4" >0.001</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow54_col5" class="data row54 col5" >-66200</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow54_col6" class="data row54 col6" >-17800</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row55" class="row_heading level0 row55" >45</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow55_col0" class="data row55 col0" >Neighborhood_SWISU</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow55_col1" class="data row55 col1" >-43720</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow55_col2" class="data row55 col2" >13900</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow55_col3" class="data row55 col3" >-3.146</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow55_col4" class="data row55 col4" >0.002</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow55_col5" class="data row55 col5" >-71000</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow55_col6" class="data row55 col6" >-16500</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row56" class="row_heading level0 row56" >46</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow56_col0" class="data row56 col0" >Neighborhood_Sawyer</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow56_col1" class="data row56 col1" >-39840</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow56_col2" class="data row56 col2" >12100</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow56_col3" class="data row56 col3" >-3.282</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow56_col4" class="data row56 col4" >0.001</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow56_col5" class="data row56 col5" >-63700</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow56_col6" class="data row56 col6" >-16000</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row57" class="row_heading level0 row57" >47</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow57_col0" class="data row57 col0" >Neighborhood_SawyerW</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow57_col1" class="data row57 col1" >-20590</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow57_col2" class="data row57 col2" >12000</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow57_col3" class="data row57 col3" >-1.722</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow57_col4" class="data row57 col4" >0.085</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow57_col5" class="data row57 col5" >-44100</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow57_col6" class="data row57 col6" >2880.55</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row58" class="row_heading level0 row58" >48</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow58_col0" class="data row58 col0" >Neighborhood_Somerst</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow58_col1" class="data row58 col1" >-9387.18</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow58_col2" class="data row58 col2" >11800</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow58_col3" class="data row58 col3" >-0.796</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow58_col4" class="data row58 col4" >0.426</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow58_col5" class="data row58 col5" >-32500</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow58_col6" class="data row58 col6" >13800</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row59" class="row_heading level0 row59" >49</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow59_col0" class="data row59 col0" >Neighborhood_StoneBr</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow59_col1" class="data row59 col1" >26800</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow59_col2" class="data row59 col2" >12900</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow59_col3" class="data row59 col3" >2.073</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow59_col4" class="data row59 col4" >0.038</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow59_col5" class="data row59 col5" >1431.49</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow59_col6" class="data row59 col6" >52200</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row60" class="row_heading level0 row60" >50</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow60_col0" class="data row60 col0" >Neighborhood_Timber</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow60_col1" class="data row60 col1" >-25920</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow60_col2" class="data row60 col2" >12700</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow60_col3" class="data row60 col3" >-2.041</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow60_col4" class="data row60 col4" >0.042</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow60_col5" class="data row60 col5" >-50800</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow60_col6" class="data row60 col6" >-992.954</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row61" class="row_heading level0 row61" >51</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow61_col0" class="data row61 col0" >Neighborhood_Veenker</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow61_col1" class="data row61 col1" >-15760</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow61_col2" class="data row61 col2" >15400</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow61_col3" class="data row61 col3" >-1.021</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow61_col4" class="data row61 col4" >0.307</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow61_col5" class="data row61 col5" >-46100</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow61_col6" class="data row61 col6" >14500</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row62" class="row_heading level0 row62" >9</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow62_col0" class="data row62 col0" >OpenPorchSF</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow62_col1" class="data row62 col1" >1834.95</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow62_col2" class="data row62 col2" >583.308</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow62_col3" class="data row62 col3" >3.146</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow62_col4" class="data row62 col4" >0.002</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow62_col5" class="data row62 col5" >690.223</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow62_col6" class="data row62 col6" >2979.68</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row63" class="row_heading level0 row63" >58</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow63_col0" class="data row63 col0" >OverallCond_Bad</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow63_col1" class="data row63 col1" >-14710</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow63_col2" class="data row63 col2" >4752.05</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow63_col3" class="data row63 col3" >-3.095</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow63_col4" class="data row63 col4" >0.002</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow63_col5" class="data row63 col5" >-24000</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow63_col6" class="data row63 col6" >-5383.51</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row64" class="row_heading level0 row64" >59</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow64_col0" class="data row64 col0" >OverallCond_Good</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow64_col1" class="data row64 col1" >4929.95</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow64_col2" class="data row64 col2" >2726.29</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow64_col3" class="data row64 col3" >1.808</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow64_col4" class="data row64 col4" >0.071</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow64_col5" class="data row64 col5" >-420.328</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow64_col6" class="data row64 col6" >10300</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row65" class="row_heading level0 row65" >56</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow65_col0" class="data row65 col0" >OverallQual_Low</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow65_col1" class="data row65 col1" >-47280</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow65_col2" class="data row65 col2" >5858.9</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow65_col3" class="data row65 col3" >-8.069</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow65_col4" class="data row65 col4" >0</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow65_col5" class="data row65 col5" >-58800</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow65_col6" class="data row65 col6" >-35800</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row66" class="row_heading level0 row66" >57</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow66_col0" class="data row66 col0" >OverallQual_Med</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow66_col1" class="data row66 col1" >-41370</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow66_col2" class="data row66 col2" >4049.9</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow66_col3" class="data row66 col3" >-10.216</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow66_col4" class="data row66 col4" >0</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow66_col5" class="data row66 col5" >-49300</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow66_col6" class="data row66 col6" >-33400</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row67" class="row_heading level0 row67" >60</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow67_col0" class="data row67 col0" >RoofStyle_Hip</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow67_col1" class="data row67 col1" >10780</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow67_col2" class="data row67 col2" >2808.95</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow67_col3" class="data row67 col3" >3.838</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow67_col4" class="data row67 col4" >0</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow67_col5" class="data row67 col5" >5268.91</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow67_col6" class="data row67 col6" >16300</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row68" class="row_heading level0 row68" >61</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow68_col0" class="data row68 col0" >RoofStyle_Others</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow68_col1" class="data row68 col1" >878.759</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow68_col2" class="data row68 col2" >7726.93</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow68_col3" class="data row68 col3" >0.114</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow68_col4" class="data row68 col4" >0.909</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow68_col5" class="data row68 col5" >-14300</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow68_col6" class="data row68 col6" >16000</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row69" class="row_heading level0 row69" >74</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow69_col0" class="data row69 col0" >SaleCondition_Normal</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow69_col1" class="data row69 col1" >5574.66</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow69_col2" class="data row69 col2" >4193.56</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow69_col3" class="data row69 col3" >1.329</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow69_col4" class="data row69 col4" >0.184</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow69_col5" class="data row69 col5" >-2655.1</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow69_col6" class="data row69 col6" >13800</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row70" class="row_heading level0 row70" >75</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow70_col0" class="data row70 col0" >SaleCondition_Other</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow70_col1" class="data row70 col1" >3363.45</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow70_col2" class="data row70 col2" >7837.97</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow70_col3" class="data row70 col3" >0.429</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow70_col4" class="data row70 col4" >0.668</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow70_col5" class="data row70 col5" >-12000</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow70_col6" class="data row70 col6" >18700</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row71" class="row_heading level0 row71" >76</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow71_col0" class="data row71 col0" >SaleCondition_Partial</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow71_col1" class="data row71 col1" >29570</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow71_col2" class="data row71 col2" >32300</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow71_col3" class="data row71 col3" >0.916</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow71_col4" class="data row71 col4" >0.36</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow71_col5" class="data row71 col5" >-33800</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow71_col6" class="data row71 col6" >92900</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row72" class="row_heading level0 row72" >72</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow72_col0" class="data row72 col0" >SaleType_Other</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow72_col1" class="data row72 col1" >6882.65</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow72_col2" class="data row72 col2" >32800</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow72_col3" class="data row72 col3" >0.21</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow72_col4" class="data row72 col4" >0.834</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow72_col5" class="data row72 col5" >-57500</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow72_col6" class="data row72 col6" >71200</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row73" class="row_heading level0 row73" >73</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow73_col0" class="data row73 col0" >SaleType_WD</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow73_col1" class="data row73 col1" >1183.61</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow73_col2" class="data row73 col2" >32300</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow73_col3" class="data row73 col3" >0.037</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow73_col4" class="data row73 col4" >0.971</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow73_col5" class="data row73 col5" >-62300</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow73_col6" class="data row73 col6" >64600</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row74" class="row_heading level0 row74" >10</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow74_col0" class="data row74 col0" >ScreenPorch</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow74_col1" class="data row74 col1" >1679.66</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow74_col2" class="data row74 col2" >755.392</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow74_col3" class="data row74 col3" >2.224</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow74_col4" class="data row74 col4" >0.026</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow74_col5" class="data row74 col5" >197.218</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow74_col6" class="data row74 col6" >3162.09</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row75" class="row_heading level0 row75" >8</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow75_col0" class="data row75 col0" >WoodDeckSF</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow75_col1" class="data row75 col1" >540.363</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow75_col2" class="data row75 col2" >441.405</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow75_col3" class="data row75 col3" >1.224</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow75_col4" class="data row75 col4" >0.221</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow75_col5" class="data row75 col5" >-325.882</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow75_col6" class="data row75 col6" >1406.61</td> 
    </tr>    <tr> 
        <th id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dflevel0_row76" class="row_heading level0 row76" >0</th> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow76_col0" class="data row76 col0" >const</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow76_col1" class="data row76 col1" >25920</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow76_col2" class="data row76 col2" >46800</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow76_col3" class="data row76 col3" >0.554</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow76_col4" class="data row76 col4" >0.58</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow76_col5" class="data row76 col5" >-65900</td> 
        <td id="T_8b2a2b34_48dd_11e9_9f5f_48d224c0b2dfrow76_col6" class="data row76 col6" >118000</td> 
    </tr></tbody> 
</table> 




```python
cols_to_drop = 'BldgType_2fmCon	BldgType_Duplex	BldgType_Twnhs	BldgType_TwnhsE	BsmtFinType2_Rec	BsmtFinType2_Unf	MSSubClass_160	MSSubClass_180	MSSubClass_190	MSSubClass_20	MSSubClass_30	MSSubClass_40	MSSubClass_45	MSSubClass_50	MSSubClass_60	MSSubClass_70	MSSubClass_75	MSSubClass_80	MSSubClass_85	MSSubClass_90	MasVnrArea	MasVnrType_None	MasVnrType_Stone'
cols_to_drop = cols_to_drop.split('\t')
len(cols_to_drop)
```




    23




```python
print(df_train_x.shape, df_test_x.shape)
df_train_x = df_train_x.drop(cols_to_drop, axis = 1)
df_test_x  = df_test_x.drop(cols_to_drop, axis = 1)
print(df_train_x.shape, df_test_x.shape)
```

    (1021, 77) (438, 77)
    (1021, 54) (438, 54)
    

#### 4.4.2 Building Model No. 3 


```python
lm_3 = sm.OLS(df_train_y, df_train_x).fit()
lm_3.summary()
```




<table class="simpletable">
<caption>OLS Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>        <td>SalePrice</td>    <th>  R-squared:         </th> <td>   0.849</td> 
</tr>
<tr>
  <th>Model:</th>                   <td>OLS</td>       <th>  Adj. R-squared:    </th> <td>   0.840</td> 
</tr>
<tr>
  <th>Method:</th>             <td>Least Squares</td>  <th>  F-statistic:       </th> <td>   102.4</td> 
</tr>
<tr>
  <th>Date:</th>             <td>Sun, 17 Mar 2019</td> <th>  Prob (F-statistic):</th>  <td>  0.00</td>  
</tr>
<tr>
  <th>Time:</th>                 <td>23:23:19</td>     <th>  Log-Likelihood:    </th> <td> -12004.</td> 
</tr>
<tr>
  <th>No. Observations:</th>      <td>  1021</td>      <th>  AIC:               </th> <td>2.412e+04</td>
</tr>
<tr>
  <th>Df Residuals:</th>          <td>   967</td>      <th>  BIC:               </th> <td>2.438e+04</td>
</tr>
<tr>
  <th>Df Model:</th>              <td>    53</td>      <th>                     </th>     <td> </td>    
</tr>
<tr>
  <th>Covariance Type:</th>      <td>nonrobust</td>    <th>                     </th>     <td> </td>    
</tr>
</table>
<table class="simpletable">
<tr>
            <td></td>               <th>coef</th>     <th>std err</th>      <th>t</th>      <th>P>|t|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>const</th>                 <td>-1.633e+04</td> <td>  4.1e+04</td> <td>   -0.398</td> <td> 0.691</td> <td>-9.68e+04</td> <td> 6.42e+04</td>
</tr>
<tr>
  <th>LotArea</th>               <td> 2.389e+04</td> <td> 2743.511</td> <td>    8.710</td> <td> 0.000</td> <td> 1.85e+04</td> <td> 2.93e+04</td>
</tr>
<tr>
  <th>BsmtFullBath</th>          <td> 1.364e+04</td> <td> 2240.361</td> <td>    6.087</td> <td> 0.000</td> <td> 9240.548</td> <td>  1.8e+04</td>
</tr>
<tr>
  <th>BsmtHalfBath</th>          <td> 4838.6767</td> <td> 6564.538</td> <td>    0.737</td> <td> 0.461</td> <td>-8043.706</td> <td> 1.77e+04</td>
</tr>
<tr>
  <th>FullBath</th>              <td>  2.85e+04</td> <td> 2575.411</td> <td>   11.066</td> <td> 0.000</td> <td> 2.34e+04</td> <td> 3.36e+04</td>
</tr>
<tr>
  <th>HalfBath</th>              <td> 1.563e+04</td> <td> 2268.849</td> <td>    6.891</td> <td> 0.000</td> <td> 1.12e+04</td> <td> 2.01e+04</td>
</tr>
<tr>
  <th>Fireplaces</th>            <td> 1.187e+04</td> <td> 1927.184</td> <td>    6.161</td> <td> 0.000</td> <td> 8090.992</td> <td> 1.57e+04</td>
</tr>
<tr>
  <th>WoodDeckSF</th>            <td>  540.9543</td> <td>  439.018</td> <td>    1.232</td> <td> 0.218</td> <td> -320.583</td> <td> 1402.491</td>
</tr>
<tr>
  <th>OpenPorchSF</th>           <td> 2094.9431</td> <td>  563.562</td> <td>    3.717</td> <td> 0.000</td> <td>  988.997</td> <td> 3200.889</td>
</tr>
<tr>
  <th>ScreenPorch</th>           <td> 1613.6453</td> <td>  756.652</td> <td>    2.133</td> <td> 0.033</td> <td>  128.776</td> <td> 3098.515</td>
</tr>
<tr>
  <th>LotConfig_CulDSac</th>     <td> 8192.4584</td> <td> 4656.162</td> <td>    1.759</td> <td> 0.079</td> <td> -944.888</td> <td> 1.73e+04</td>
</tr>
<tr>
  <th>LotConfig_FR</th>          <td>-1.272e+04</td> <td> 5490.556</td> <td>   -2.317</td> <td> 0.021</td> <td>-2.35e+04</td> <td>-1947.419</td>
</tr>
<tr>
  <th>LotConfig_Inside</th>      <td>-1544.0457</td> <td> 2671.858</td> <td>   -0.578</td> <td> 0.563</td> <td>-6787.353</td> <td> 3699.262</td>
</tr>
<tr>
  <th>Neighborhood_Blueste</th>  <td>-7954.8090</td> <td>  2.5e+04</td> <td>   -0.318</td> <td> 0.750</td> <td> -5.7e+04</td> <td> 4.11e+04</td>
</tr>
<tr>
  <th>Neighborhood_BrDale</th>   <td>-1.065e+04</td> <td> 1.31e+04</td> <td>   -0.814</td> <td> 0.416</td> <td>-3.63e+04</td> <td>  1.5e+04</td>
</tr>
<tr>
  <th>Neighborhood_BrkSide</th>  <td>-1.659e+04</td> <td> 1.14e+04</td> <td>   -1.454</td> <td> 0.146</td> <td> -3.9e+04</td> <td> 5807.733</td>
</tr>
<tr>
  <th>Neighborhood_ClearCr</th>  <td>-1549.9608</td> <td> 1.29e+04</td> <td>   -0.120</td> <td> 0.905</td> <td>-2.69e+04</td> <td> 2.38e+04</td>
</tr>
<tr>
  <th>Neighborhood_CollgCr</th>  <td>-4348.4163</td> <td> 1.05e+04</td> <td>   -0.416</td> <td> 0.678</td> <td>-2.49e+04</td> <td> 1.62e+04</td>
</tr>
<tr>
  <th>Neighborhood_Crawfor</th>  <td> 5154.6595</td> <td> 1.16e+04</td> <td>    0.442</td> <td> 0.658</td> <td>-1.77e+04</td> <td>  2.8e+04</td>
</tr>
<tr>
  <th>Neighborhood_Edwards</th>  <td>-3.506e+04</td> <td> 1.09e+04</td> <td>   -3.203</td> <td> 0.001</td> <td>-5.65e+04</td> <td>-1.36e+04</td>
</tr>
<tr>
  <th>Neighborhood_Gilbert</th>  <td>-1.944e+04</td> <td>  1.1e+04</td> <td>   -1.762</td> <td> 0.078</td> <td>-4.11e+04</td> <td> 2212.514</td>
</tr>
<tr>
  <th>Neighborhood_IDOTRR</th>   <td>-3.579e+04</td> <td>  1.2e+04</td> <td>   -2.983</td> <td> 0.003</td> <td>-5.93e+04</td> <td>-1.22e+04</td>
</tr>
<tr>
  <th>Neighborhood_MeadowV</th>  <td>-2.477e+04</td> <td> 1.34e+04</td> <td>   -1.846</td> <td> 0.065</td> <td>-5.11e+04</td> <td> 1563.950</td>
</tr>
<tr>
  <th>Neighborhood_Mitchel</th>  <td>-1.961e+04</td> <td> 1.14e+04</td> <td>   -1.713</td> <td> 0.087</td> <td>-4.21e+04</td> <td> 2853.400</td>
</tr>
<tr>
  <th>Neighborhood_NAmes</th>    <td>-2.292e+04</td> <td> 1.06e+04</td> <td>   -2.153</td> <td> 0.032</td> <td>-4.38e+04</td> <td>-2025.499</td>
</tr>
<tr>
  <th>Neighborhood_NPkVill</th>  <td>-1.612e+04</td> <td> 1.63e+04</td> <td>   -0.986</td> <td> 0.324</td> <td>-4.82e+04</td> <td>  1.6e+04</td>
</tr>
<tr>
  <th>Neighborhood_NWAmes</th>   <td>-1.165e+04</td> <td> 1.13e+04</td> <td>   -1.028</td> <td> 0.304</td> <td>-3.39e+04</td> <td> 1.06e+04</td>
</tr>
<tr>
  <th>Neighborhood_NoRidge</th>  <td> 4.922e+04</td> <td> 1.21e+04</td> <td>    4.082</td> <td> 0.000</td> <td> 2.56e+04</td> <td> 7.29e+04</td>
</tr>
<tr>
  <th>Neighborhood_NridgHt</th>  <td>  3.33e+04</td> <td> 1.09e+04</td> <td>    3.046</td> <td> 0.002</td> <td> 1.18e+04</td> <td> 5.48e+04</td>
</tr>
<tr>
  <th>Neighborhood_OldTown</th>  <td>-2.861e+04</td> <td> 1.09e+04</td> <td>   -2.616</td> <td> 0.009</td> <td>-5.01e+04</td> <td>-7151.222</td>
</tr>
<tr>
  <th>Neighborhood_SWISU</th>    <td>-2.577e+04</td> <td> 1.26e+04</td> <td>   -2.046</td> <td> 0.041</td> <td>-5.05e+04</td> <td>-1047.272</td>
</tr>
<tr>
  <th>Neighborhood_Sawyer</th>   <td>-2.715e+04</td> <td> 1.12e+04</td> <td>   -2.423</td> <td> 0.016</td> <td>-4.91e+04</td> <td>-5161.085</td>
</tr>
<tr>
  <th>Neighborhood_SawyerW</th>  <td>-9801.5575</td> <td> 1.11e+04</td> <td>   -0.879</td> <td> 0.380</td> <td>-3.17e+04</td> <td> 1.21e+04</td>
</tr>
<tr>
  <th>Neighborhood_Somerst</th>  <td> 1194.8585</td> <td> 1.06e+04</td> <td>    0.112</td> <td> 0.911</td> <td>-1.97e+04</td> <td> 2.21e+04</td>
</tr>
<tr>
  <th>Neighborhood_StoneBr</th>  <td>  3.24e+04</td> <td> 1.24e+04</td> <td>    2.617</td> <td> 0.009</td> <td> 8102.888</td> <td> 5.67e+04</td>
</tr>
<tr>
  <th>Neighborhood_Timber</th>   <td>-1.516e+04</td> <td>  1.2e+04</td> <td>   -1.259</td> <td> 0.209</td> <td>-3.88e+04</td> <td> 8476.571</td>
</tr>
<tr>
  <th>Neighborhood_Veenker</th>  <td>-1.275e+04</td> <td> 1.51e+04</td> <td>   -0.846</td> <td> 0.398</td> <td>-4.23e+04</td> <td> 1.68e+04</td>
</tr>
<tr>
  <th>OverallQual_Low</th>       <td>-5.189e+04</td> <td> 5802.753</td> <td>   -8.942</td> <td> 0.000</td> <td>-6.33e+04</td> <td>-4.05e+04</td>
</tr>
<tr>
  <th>OverallQual_Med</th>       <td>-4.433e+04</td> <td> 4022.893</td> <td>  -11.020</td> <td> 0.000</td> <td>-5.22e+04</td> <td>-3.64e+04</td>
</tr>
<tr>
  <th>OverallCond_Bad</th>       <td>-1.545e+04</td> <td> 4698.536</td> <td>   -3.289</td> <td> 0.001</td> <td>-2.47e+04</td> <td>-6232.990</td>
</tr>
<tr>
  <th>OverallCond_Good</th>      <td> 6499.7015</td> <td> 2672.662</td> <td>    2.432</td> <td> 0.015</td> <td> 1254.816</td> <td> 1.17e+04</td>
</tr>
<tr>
  <th>RoofStyle_Hip</th>         <td> 1.134e+04</td> <td> 2723.959</td> <td>    4.161</td> <td> 0.000</td> <td> 5990.153</td> <td> 1.67e+04</td>
</tr>
<tr>
  <th>RoofStyle_Others</th>      <td>  496.5116</td> <td> 7635.712</td> <td>    0.065</td> <td> 0.948</td> <td>-1.45e+04</td> <td> 1.55e+04</td>
</tr>
<tr>
  <th>BsmtExposure_Gd</th>       <td>  2.69e+04</td> <td> 4444.434</td> <td>    6.053</td> <td> 0.000</td> <td> 1.82e+04</td> <td> 3.56e+04</td>
</tr>
<tr>
  <th>BsmtExposure_Mn</th>       <td> 4561.6795</td> <td> 4531.509</td> <td>    1.007</td> <td> 0.314</td> <td>-4331.045</td> <td> 1.35e+04</td>
</tr>
<tr>
  <th>BsmtExposure_No</th>       <td>-1673.3516</td> <td> 3194.757</td> <td>   -0.524</td> <td> 0.601</td> <td>-7942.808</td> <td> 4596.105</td>
</tr>
<tr>
  <th>BsmtExposure_None</th>     <td>-1.631e+04</td> <td> 7334.171</td> <td>   -2.223</td> <td> 0.026</td> <td>-3.07e+04</td> <td>-1914.204</td>
</tr>
<tr>
  <th>KitchenQual_Low</th>       <td>-6.215e+04</td> <td> 5244.327</td> <td>  -11.851</td> <td> 0.000</td> <td>-7.24e+04</td> <td>-5.19e+04</td>
</tr>
<tr>
  <th>KitchenQual_Med</th>       <td>-5.139e+04</td> <td> 4769.522</td> <td>  -10.776</td> <td> 0.000</td> <td>-6.08e+04</td> <td> -4.2e+04</td>
</tr>
<tr>
  <th>SaleType_Other</th>        <td> 6285.5892</td> <td> 3.28e+04</td> <td>    0.191</td> <td> 0.848</td> <td>-5.82e+04</td> <td> 7.07e+04</td>
</tr>
<tr>
  <th>SaleType_WD</th>           <td> 1351.6500</td> <td> 3.24e+04</td> <td>    0.042</td> <td> 0.967</td> <td>-6.22e+04</td> <td>  6.5e+04</td>
</tr>
<tr>
  <th>SaleCondition_Normal</th>  <td> 5169.5009</td> <td> 4219.715</td> <td>    1.225</td> <td> 0.221</td> <td>-3111.354</td> <td> 1.35e+04</td>
</tr>
<tr>
  <th>SaleCondition_Other</th>   <td> 2962.1981</td> <td> 7711.336</td> <td>    0.384</td> <td> 0.701</td> <td>-1.22e+04</td> <td> 1.81e+04</td>
</tr>
<tr>
  <th>SaleCondition_Partial</th> <td> 3.191e+04</td> <td> 3.23e+04</td> <td>    0.987</td> <td> 0.324</td> <td>-3.16e+04</td> <td> 9.54e+04</td>
</tr>
</table>
<table class="simpletable">
<tr>
  <th>Omnibus:</th>       <td>390.909</td> <th>  Durbin-Watson:     </th> <td>   1.981</td> 
</tr>
<tr>
  <th>Prob(Omnibus):</th> <td> 0.000</td>  <th>  Jarque-Bera (JB):  </th> <td>10663.376</td>
</tr>
<tr>
  <th>Skew:</th>          <td> 1.153</td>  <th>  Prob(JB):          </th> <td>    0.00</td> 
</tr>
<tr>
  <th>Kurtosis:</th>      <td>18.663</td>  <th>  Cond. No.          </th> <td>    678.</td> 
</tr>
</table><br/><br/>Warnings:<br/>[1] Standard Errors assume that the covariance matrix of the errors is correctly specified.




```python
rmse_3 = rmse(lm_3, df_test_x, df_test_y)
rmse_3_log_scale = rmse_log_scale(lm_3, df_test_x, df_test_y)
print(rmse_3, rmse_3_log_scale, sep = '\n')
```

    38344.116
    0.1793
    

Now this is looking like a good model.
>* We have no insignificant variables
>* Our Adjusted R-squared value is a little over 0.83
>* Our F-statistic is 100
>* Our RMSE has barely shifted and still stands at a healthy 0.16
>* And as a bonus, no warning about multi-collinearity

All these points are indications of a good, well-built model. But, let's see if we can imporve upon this.

#### 4.5 Model No. 4
Let's take a look at the distribution of the target variable.


```python
plt.rcParams['figure.figsize'] = [6, 6]
sns.distplot(df_train_y);
```

    C:\ProgramData\Anaconda3\lib\site-packages\scipy\stats\stats.py:1713: FutureWarning: Using a non-tuple sequence for multidimensional indexing is deprecated; use `arr[tuple(seq)]` instead of `arr[seq]`. In the future this will be interpreted as an array index, `arr[np.array(seq)]`, which will result either in an error or a different result.
      return np.add.reduce(sorted[indexer] * weights, axis=axis) / sumval
    


![png](output_138_1.png)


As can be seen, the distribution is a bit skewed. Let's try taking log of the target variable and then plotting the distribution.


```python
sns.distplot(df_train_y.apply(math.log));
```


![png](output_140_0.png)


And as can be seen, this is very close to a normal distribution now. Let's build the next model by taking log transformation of the target variable.


```python
X = df_train_x.copy()
y = df_train_y.apply(math.log)
lm_log_1 = sm.OLS(y, X).fit()
lm_log_1.summary()
```




<table class="simpletable">
<caption>OLS Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>        <td>SalePrice</td>    <th>  R-squared:         </th> <td>   0.863</td>
</tr>
<tr>
  <th>Model:</th>                   <td>OLS</td>       <th>  Adj. R-squared:    </th> <td>   0.856</td>
</tr>
<tr>
  <th>Method:</th>             <td>Least Squares</td>  <th>  F-statistic:       </th> <td>   115.3</td>
</tr>
<tr>
  <th>Date:</th>             <td>Sun, 17 Mar 2019</td> <th>  Prob (F-statistic):</th>  <td>  0.00</td> 
</tr>
<tr>
  <th>Time:</th>                 <td>23:23:23</td>     <th>  Log-Likelihood:    </th> <td>  499.10</td>
</tr>
<tr>
  <th>No. Observations:</th>      <td>  1021</td>      <th>  AIC:               </th> <td>  -890.2</td>
</tr>
<tr>
  <th>Df Residuals:</th>          <td>   967</td>      <th>  BIC:               </th> <td>  -624.1</td>
</tr>
<tr>
  <th>Df Model:</th>              <td>    53</td>      <th>                     </th>     <td> </td>   
</tr>
<tr>
  <th>Covariance Type:</th>      <td>nonrobust</td>    <th>                     </th>     <td> </td>   
</tr>
</table>
<table class="simpletable">
<tr>
            <td></td>               <th>coef</th>     <th>std err</th>      <th>t</th>      <th>P>|t|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>const</th>                 <td>   10.8800</td> <td>    0.197</td> <td>   55.219</td> <td> 0.000</td> <td>   10.493</td> <td>   11.267</td>
</tr>
<tr>
  <th>LotArea</th>               <td>    0.1152</td> <td>    0.013</td> <td>    8.738</td> <td> 0.000</td> <td>    0.089</td> <td>    0.141</td>
</tr>
<tr>
  <th>BsmtFullBath</th>          <td>    0.0755</td> <td>    0.011</td> <td>    7.010</td> <td> 0.000</td> <td>    0.054</td> <td>    0.097</td>
</tr>
<tr>
  <th>BsmtHalfBath</th>          <td>    0.0473</td> <td>    0.032</td> <td>    1.500</td> <td> 0.134</td> <td>   -0.015</td> <td>    0.109</td>
</tr>
<tr>
  <th>FullBath</th>              <td>    0.1559</td> <td>    0.012</td> <td>   12.599</td> <td> 0.000</td> <td>    0.132</td> <td>    0.180</td>
</tr>
<tr>
  <th>HalfBath</th>              <td>    0.0852</td> <td>    0.011</td> <td>    7.814</td> <td> 0.000</td> <td>    0.064</td> <td>    0.107</td>
</tr>
<tr>
  <th>Fireplaces</th>            <td>    0.0643</td> <td>    0.009</td> <td>    6.941</td> <td> 0.000</td> <td>    0.046</td> <td>    0.082</td>
</tr>
<tr>
  <th>WoodDeckSF</th>            <td>    0.0057</td> <td>    0.002</td> <td>    2.724</td> <td> 0.007</td> <td>    0.002</td> <td>    0.010</td>
</tr>
<tr>
  <th>OpenPorchSF</th>           <td>    0.0133</td> <td>    0.003</td> <td>    4.909</td> <td> 0.000</td> <td>    0.008</td> <td>    0.019</td>
</tr>
<tr>
  <th>ScreenPorch</th>           <td>    0.0116</td> <td>    0.004</td> <td>    3.184</td> <td> 0.002</td> <td>    0.004</td> <td>    0.019</td>
</tr>
<tr>
  <th>LotConfig_CulDSac</th>     <td>    0.0369</td> <td>    0.022</td> <td>    1.649</td> <td> 0.099</td> <td>   -0.007</td> <td>    0.081</td>
</tr>
<tr>
  <th>LotConfig_FR</th>          <td>   -0.0477</td> <td>    0.026</td> <td>   -1.808</td> <td> 0.071</td> <td>   -0.099</td> <td>    0.004</td>
</tr>
<tr>
  <th>LotConfig_Inside</th>      <td>   -0.0066</td> <td>    0.013</td> <td>   -0.511</td> <td> 0.610</td> <td>   -0.032</td> <td>    0.019</td>
</tr>
<tr>
  <th>Neighborhood_Blueste</th>  <td>   -0.1270</td> <td>    0.120</td> <td>   -1.058</td> <td> 0.290</td> <td>   -0.363</td> <td>    0.109</td>
</tr>
<tr>
  <th>Neighborhood_BrDale</th>   <td>   -0.2233</td> <td>    0.063</td> <td>   -3.551</td> <td> 0.000</td> <td>   -0.347</td> <td>   -0.100</td>
</tr>
<tr>
  <th>Neighborhood_BrkSide</th>  <td>   -0.1811</td> <td>    0.055</td> <td>   -3.303</td> <td> 0.001</td> <td>   -0.289</td> <td>   -0.073</td>
</tr>
<tr>
  <th>Neighborhood_ClearCr</th>  <td>   -0.0037</td> <td>    0.062</td> <td>   -0.060</td> <td> 0.952</td> <td>   -0.126</td> <td>    0.118</td>
</tr>
<tr>
  <th>Neighborhood_CollgCr</th>  <td>   -0.0475</td> <td>    0.050</td> <td>   -0.945</td> <td> 0.345</td> <td>   -0.146</td> <td>    0.051</td>
</tr>
<tr>
  <th>Neighborhood_Crawfor</th>  <td>   -0.0062</td> <td>    0.056</td> <td>   -0.111</td> <td> 0.912</td> <td>   -0.116</td> <td>    0.104</td>
</tr>
<tr>
  <th>Neighborhood_Edwards</th>  <td>   -0.2503</td> <td>    0.053</td> <td>   -4.759</td> <td> 0.000</td> <td>   -0.353</td> <td>   -0.147</td>
</tr>
<tr>
  <th>Neighborhood_Gilbert</th>  <td>   -0.1145</td> <td>    0.053</td> <td>   -2.160</td> <td> 0.031</td> <td>   -0.219</td> <td>   -0.010</td>
</tr>
<tr>
  <th>Neighborhood_IDOTRR</th>   <td>   -0.3472</td> <td>    0.058</td> <td>   -6.022</td> <td> 0.000</td> <td>   -0.460</td> <td>   -0.234</td>
</tr>
<tr>
  <th>Neighborhood_MeadowV</th>  <td>   -0.2477</td> <td>    0.064</td> <td>   -3.842</td> <td> 0.000</td> <td>   -0.374</td> <td>   -0.121</td>
</tr>
<tr>
  <th>Neighborhood_Mitchel</th>  <td>   -0.1187</td> <td>    0.055</td> <td>   -2.159</td> <td> 0.031</td> <td>   -0.227</td> <td>   -0.011</td>
</tr>
<tr>
  <th>Neighborhood_NAmes</th>    <td>   -0.1471</td> <td>    0.051</td> <td>   -2.877</td> <td> 0.004</td> <td>   -0.247</td> <td>   -0.047</td>
</tr>
<tr>
  <th>Neighborhood_NPkVill</th>  <td>   -0.1554</td> <td>    0.079</td> <td>   -1.979</td> <td> 0.048</td> <td>   -0.310</td> <td>   -0.001</td>
</tr>
<tr>
  <th>Neighborhood_NWAmes</th>   <td>   -0.0834</td> <td>    0.054</td> <td>   -1.532</td> <td> 0.126</td> <td>   -0.190</td> <td>    0.023</td>
</tr>
<tr>
  <th>Neighborhood_NoRidge</th>  <td>    0.1044</td> <td>    0.058</td> <td>    1.802</td> <td> 0.072</td> <td>   -0.009</td> <td>    0.218</td>
</tr>
<tr>
  <th>Neighborhood_NridgHt</th>  <td>    0.0743</td> <td>    0.053</td> <td>    1.415</td> <td> 0.157</td> <td>   -0.029</td> <td>    0.177</td>
</tr>
<tr>
  <th>Neighborhood_OldTown</th>  <td>   -0.2502</td> <td>    0.053</td> <td>   -4.763</td> <td> 0.000</td> <td>   -0.353</td> <td>   -0.147</td>
</tr>
<tr>
  <th>Neighborhood_SWISU</th>    <td>   -0.1886</td> <td>    0.061</td> <td>   -3.115</td> <td> 0.002</td> <td>   -0.307</td> <td>   -0.070</td>
</tr>
<tr>
  <th>Neighborhood_Sawyer</th>   <td>   -0.1847</td> <td>    0.054</td> <td>   -3.431</td> <td> 0.001</td> <td>   -0.290</td> <td>   -0.079</td>
</tr>
<tr>
  <th>Neighborhood_SawyerW</th>  <td>   -0.0970</td> <td>    0.054</td> <td>   -1.811</td> <td> 0.070</td> <td>   -0.202</td> <td>    0.008</td>
</tr>
<tr>
  <th>Neighborhood_Somerst</th>  <td>   -0.0108</td> <td>    0.051</td> <td>   -0.212</td> <td> 0.832</td> <td>   -0.111</td> <td>    0.089</td>
</tr>
<tr>
  <th>Neighborhood_StoneBr</th>  <td>    0.0881</td> <td>    0.059</td> <td>    1.482</td> <td> 0.139</td> <td>   -0.029</td> <td>    0.205</td>
</tr>
<tr>
  <th>Neighborhood_Timber</th>   <td>   -0.0728</td> <td>    0.058</td> <td>   -1.258</td> <td> 0.209</td> <td>   -0.186</td> <td>    0.041</td>
</tr>
<tr>
  <th>Neighborhood_Veenker</th>  <td>   -0.0736</td> <td>    0.072</td> <td>   -1.017</td> <td> 0.309</td> <td>   -0.216</td> <td>    0.068</td>
</tr>
<tr>
  <th>OverallQual_Low</th>       <td>   -0.3001</td> <td>    0.028</td> <td>  -10.764</td> <td> 0.000</td> <td>   -0.355</td> <td>   -0.245</td>
</tr>
<tr>
  <th>OverallQual_Med</th>       <td>   -0.1717</td> <td>    0.019</td> <td>   -8.881</td> <td> 0.000</td> <td>   -0.210</td> <td>   -0.134</td>
</tr>
<tr>
  <th>OverallCond_Bad</th>       <td>   -0.1522</td> <td>    0.023</td> <td>   -6.742</td> <td> 0.000</td> <td>   -0.196</td> <td>   -0.108</td>
</tr>
<tr>
  <th>OverallCond_Good</th>      <td>    0.0383</td> <td>    0.013</td> <td>    2.986</td> <td> 0.003</td> <td>    0.013</td> <td>    0.064</td>
</tr>
<tr>
  <th>RoofStyle_Hip</th>         <td>    0.0371</td> <td>    0.013</td> <td>    2.837</td> <td> 0.005</td> <td>    0.011</td> <td>    0.063</td>
</tr>
<tr>
  <th>RoofStyle_Others</th>      <td>   -0.0026</td> <td>    0.037</td> <td>   -0.071</td> <td> 0.944</td> <td>   -0.075</td> <td>    0.069</td>
</tr>
<tr>
  <th>BsmtExposure_Gd</th>       <td>    0.0858</td> <td>    0.021</td> <td>    4.020</td> <td> 0.000</td> <td>    0.044</td> <td>    0.128</td>
</tr>
<tr>
  <th>BsmtExposure_Mn</th>       <td>    0.0339</td> <td>    0.022</td> <td>    1.557</td> <td> 0.120</td> <td>   -0.009</td> <td>    0.077</td>
</tr>
<tr>
  <th>BsmtExposure_No</th>       <td>    0.0062</td> <td>    0.015</td> <td>    0.404</td> <td> 0.686</td> <td>   -0.024</td> <td>    0.036</td>
</tr>
<tr>
  <th>BsmtExposure_None</th>     <td>   -0.1171</td> <td>    0.035</td> <td>   -3.324</td> <td> 0.001</td> <td>   -0.186</td> <td>   -0.048</td>
</tr>
<tr>
  <th>KitchenQual_Low</th>       <td>   -0.2316</td> <td>    0.025</td> <td>   -9.190</td> <td> 0.000</td> <td>   -0.281</td> <td>   -0.182</td>
</tr>
<tr>
  <th>KitchenQual_Med</th>       <td>   -0.1519</td> <td>    0.023</td> <td>   -6.630</td> <td> 0.000</td> <td>   -0.197</td> <td>   -0.107</td>
</tr>
<tr>
  <th>SaleType_Other</th>        <td>    0.0852</td> <td>    0.158</td> <td>    0.540</td> <td> 0.589</td> <td>   -0.225</td> <td>    0.395</td>
</tr>
<tr>
  <th>SaleType_WD</th>           <td>    0.0609</td> <td>    0.156</td> <td>    0.391</td> <td> 0.696</td> <td>   -0.245</td> <td>    0.366</td>
</tr>
<tr>
  <th>SaleCondition_Normal</th>  <td>    0.0665</td> <td>    0.020</td> <td>    3.280</td> <td> 0.001</td> <td>    0.027</td> <td>    0.106</td>
</tr>
<tr>
  <th>SaleCondition_Other</th>   <td>    0.0452</td> <td>    0.037</td> <td>    1.220</td> <td> 0.223</td> <td>   -0.028</td> <td>    0.118</td>
</tr>
<tr>
  <th>SaleCondition_Partial</th> <td>    0.2078</td> <td>    0.155</td> <td>    1.337</td> <td> 0.182</td> <td>   -0.097</td> <td>    0.513</td>
</tr>
</table>
<table class="simpletable">
<tr>
  <th>Omnibus:</th>       <td>106.719</td> <th>  Durbin-Watson:     </th> <td>   1.938</td>
</tr>
<tr>
  <th>Prob(Omnibus):</th> <td> 0.000</td>  <th>  Jarque-Bera (JB):  </th> <td> 304.708</td>
</tr>
<tr>
  <th>Skew:</th>          <td>-0.534</td>  <th>  Prob(JB):          </th> <td>6.82e-67</td>
</tr>
<tr>
  <th>Kurtosis:</th>      <td> 5.454</td>  <th>  Cond. No.          </th> <td>    678.</td>
</tr>
</table><br/><br/>Warnings:<br/>[1] Standard Errors assume that the covariance matrix of the errors is correctly specified.




```python
X = df_test_x.copy()
y = df_test_y.apply(math.log)
rmse_log_1 = rmse(lm_log_1, X, y)
print(rmse_log_1)
```

    0.1761
    

Our model has improved substantially from the last iteration using a log transformation of the target variable.
>* F-statistic, R-squared and Adjusted R-squared values have increased while RMSE has gone down. 
>* We have found some new variables that are insignificant.

Let's go for one more iteration by eliminating the remaining insignificant variables.

#### 4.6 Model No. 5
#### 4.6.1 Removing Insignificant Variables


```python
results_as_html = lm_log.summary().tables[1].as_html()
results_df = pd.read_html(results_as_html, header=0, index_col=0)[0]
results_df = results_df.reset_index()
results_df.sort_values(['index', 'P>|t|']).style.applymap(p_sig, subset = ['P>|t|'])
```




<style  type="text/css" >
    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow0_col4 {
            color:  black;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow1_col4 {
            color:  red;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow2_col4 {
            color:  red;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow3_col4 {
            color:  black;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow4_col4 {
            color:  black;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow5_col4 {
            color:  red;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow6_col4 {
            color:  black;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow7_col4 {
            color:  black;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow8_col4 {
            color:  black;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow9_col4 {
            color:  black;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow10_col4 {
            color:  black;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow11_col4 {
            color:  black;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow12_col4 {
            color:  red;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow13_col4 {
            color:  red;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow14_col4 {
            color:  red;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow15_col4 {
            color:  red;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow16_col4 {
            color:  black;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow17_col4 {
            color:  black;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow18_col4 {
            color:  red;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow19_col4 {
            color:  red;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow20_col4 {
            color:  red;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow21_col4 {
            color:  black;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow22_col4 {
            color:  black;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow23_col4 {
            color:  black;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow24_col4 {
            color:  black;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow25_col4 {
            color:  black;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow26_col4 {
            color:  black;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow27_col4 {
            color:  black;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow28_col4 {
            color:  red;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow29_col4 {
            color:  red;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow30_col4 {
            color:  red;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow31_col4 {
            color:  black;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow32_col4 {
            color:  black;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow33_col4 {
            color:  black;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow34_col4 {
            color:  red;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow35_col4 {
            color:  red;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow36_col4 {
            color:  red;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow37_col4 {
            color:  red;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow38_col4 {
            color:  red;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow39_col4 {
            color:  black;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow40_col4 {
            color:  black;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow41_col4 {
            color:  black;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow42_col4 {
            color:  black;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow43_col4 {
            color:  black;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow44_col4 {
            color:  black;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow45_col4 {
            color:  red;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow46_col4 {
            color:  black;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow47_col4 {
            color:  red;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow48_col4 {
            color:  red;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow49_col4 {
            color:  red;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow50_col4 {
            color:  red;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow51_col4 {
            color:  black;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow52_col4 {
            color:  black;
        }    #T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow53_col4 {
            color:  black;
        }</style>  
<table id="T_915903ca_48dd_11e9_bcaa_48d224c0b2df" > 
<thead>    <tr> 
        <th class="blank level0" ></th> 
        <th class="col_heading level0 col0" >index</th> 
        <th class="col_heading level0 col1" >coef</th> 
        <th class="col_heading level0 col2" >std err</th> 
        <th class="col_heading level0 col3" >t</th> 
        <th class="col_heading level0 col4" >P>|t|</th> 
        <th class="col_heading level0 col5" >[0.025</th> 
        <th class="col_heading level0 col6" >0.975]</th> 
    </tr></thead> 
<tbody>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row0" class="row_heading level0 row0" >43</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow0_col0" class="data row0 col0" >BsmtExposure_Gd</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow0_col1" class="data row0 col1" >0.0858</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow0_col2" class="data row0 col2" >0.021</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow0_col3" class="data row0 col3" >4.02</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow0_col4" class="data row0 col4" >0</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow0_col5" class="data row0 col5" >0.044</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow0_col6" class="data row0 col6" >0.128</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row1" class="row_heading level0 row1" >44</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow1_col0" class="data row1 col0" >BsmtExposure_Mn</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow1_col1" class="data row1 col1" >0.0339</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow1_col2" class="data row1 col2" >0.022</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow1_col3" class="data row1 col3" >1.557</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow1_col4" class="data row1 col4" >0.12</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow1_col5" class="data row1 col5" >-0.009</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow1_col6" class="data row1 col6" >0.077</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row2" class="row_heading level0 row2" >45</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow2_col0" class="data row2 col0" >BsmtExposure_No</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow2_col1" class="data row2 col1" >0.0062</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow2_col2" class="data row2 col2" >0.015</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow2_col3" class="data row2 col3" >0.404</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow2_col4" class="data row2 col4" >0.686</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow2_col5" class="data row2 col5" >-0.024</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow2_col6" class="data row2 col6" >0.036</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row3" class="row_heading level0 row3" >46</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow3_col0" class="data row3 col0" >BsmtExposure_None</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow3_col1" class="data row3 col1" >-0.1171</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow3_col2" class="data row3 col2" >0.035</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow3_col3" class="data row3 col3" >-3.324</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow3_col4" class="data row3 col4" >0.001</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow3_col5" class="data row3 col5" >-0.186</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow3_col6" class="data row3 col6" >-0.048</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row4" class="row_heading level0 row4" >2</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow4_col0" class="data row4 col0" >BsmtFullBath</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow4_col1" class="data row4 col1" >0.0755</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow4_col2" class="data row4 col2" >0.011</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow4_col3" class="data row4 col3" >7.01</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow4_col4" class="data row4 col4" >0</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow4_col5" class="data row4 col5" >0.054</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow4_col6" class="data row4 col6" >0.097</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row5" class="row_heading level0 row5" >3</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow5_col0" class="data row5 col0" >BsmtHalfBath</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow5_col1" class="data row5 col1" >0.0473</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow5_col2" class="data row5 col2" >0.032</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow5_col3" class="data row5 col3" >1.5</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow5_col4" class="data row5 col4" >0.134</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow5_col5" class="data row5 col5" >-0.015</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow5_col6" class="data row5 col6" >0.109</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row6" class="row_heading level0 row6" >6</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow6_col0" class="data row6 col0" >Fireplaces</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow6_col1" class="data row6 col1" >0.0643</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow6_col2" class="data row6 col2" >0.009</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow6_col3" class="data row6 col3" >6.941</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow6_col4" class="data row6 col4" >0</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow6_col5" class="data row6 col5" >0.046</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow6_col6" class="data row6 col6" >0.082</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row7" class="row_heading level0 row7" >4</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow7_col0" class="data row7 col0" >FullBath</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow7_col1" class="data row7 col1" >0.1559</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow7_col2" class="data row7 col2" >0.012</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow7_col3" class="data row7 col3" >12.599</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow7_col4" class="data row7 col4" >0</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow7_col5" class="data row7 col5" >0.132</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow7_col6" class="data row7 col6" >0.18</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row8" class="row_heading level0 row8" >5</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow8_col0" class="data row8 col0" >HalfBath</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow8_col1" class="data row8 col1" >0.0852</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow8_col2" class="data row8 col2" >0.011</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow8_col3" class="data row8 col3" >7.814</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow8_col4" class="data row8 col4" >0</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow8_col5" class="data row8 col5" >0.064</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow8_col6" class="data row8 col6" >0.107</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row9" class="row_heading level0 row9" >47</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow9_col0" class="data row9 col0" >KitchenQual_Low</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow9_col1" class="data row9 col1" >-0.2316</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow9_col2" class="data row9 col2" >0.025</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow9_col3" class="data row9 col3" >-9.19</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow9_col4" class="data row9 col4" >0</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow9_col5" class="data row9 col5" >-0.281</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow9_col6" class="data row9 col6" >-0.182</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row10" class="row_heading level0 row10" >48</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow10_col0" class="data row10 col0" >KitchenQual_Med</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow10_col1" class="data row10 col1" >-0.1519</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow10_col2" class="data row10 col2" >0.023</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow10_col3" class="data row10 col3" >-6.63</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow10_col4" class="data row10 col4" >0</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow10_col5" class="data row10 col5" >-0.197</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow10_col6" class="data row10 col6" >-0.107</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row11" class="row_heading level0 row11" >1</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow11_col0" class="data row11 col0" >LotArea</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow11_col1" class="data row11 col1" >0.1152</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow11_col2" class="data row11 col2" >0.013</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow11_col3" class="data row11 col3" >8.738</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow11_col4" class="data row11 col4" >0</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow11_col5" class="data row11 col5" >0.089</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow11_col6" class="data row11 col6" >0.141</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row12" class="row_heading level0 row12" >10</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow12_col0" class="data row12 col0" >LotConfig_CulDSac</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow12_col1" class="data row12 col1" >0.0369</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow12_col2" class="data row12 col2" >0.022</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow12_col3" class="data row12 col3" >1.649</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow12_col4" class="data row12 col4" >0.099</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow12_col5" class="data row12 col5" >-0.007</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow12_col6" class="data row12 col6" >0.081</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row13" class="row_heading level0 row13" >11</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow13_col0" class="data row13 col0" >LotConfig_FR</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow13_col1" class="data row13 col1" >-0.0477</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow13_col2" class="data row13 col2" >0.026</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow13_col3" class="data row13 col3" >-1.808</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow13_col4" class="data row13 col4" >0.071</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow13_col5" class="data row13 col5" >-0.099</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow13_col6" class="data row13 col6" >0.004</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row14" class="row_heading level0 row14" >12</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow14_col0" class="data row14 col0" >LotConfig_Inside</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow14_col1" class="data row14 col1" >-0.0066</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow14_col2" class="data row14 col2" >0.013</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow14_col3" class="data row14 col3" >-0.511</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow14_col4" class="data row14 col4" >0.61</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow14_col5" class="data row14 col5" >-0.032</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow14_col6" class="data row14 col6" >0.019</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row15" class="row_heading level0 row15" >13</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow15_col0" class="data row15 col0" >Neighborhood_Blueste</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow15_col1" class="data row15 col1" >-0.127</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow15_col2" class="data row15 col2" >0.12</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow15_col3" class="data row15 col3" >-1.058</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow15_col4" class="data row15 col4" >0.29</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow15_col5" class="data row15 col5" >-0.363</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow15_col6" class="data row15 col6" >0.109</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row16" class="row_heading level0 row16" >14</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow16_col0" class="data row16 col0" >Neighborhood_BrDale</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow16_col1" class="data row16 col1" >-0.2233</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow16_col2" class="data row16 col2" >0.063</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow16_col3" class="data row16 col3" >-3.551</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow16_col4" class="data row16 col4" >0</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow16_col5" class="data row16 col5" >-0.347</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow16_col6" class="data row16 col6" >-0.1</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row17" class="row_heading level0 row17" >15</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow17_col0" class="data row17 col0" >Neighborhood_BrkSide</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow17_col1" class="data row17 col1" >-0.1811</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow17_col2" class="data row17 col2" >0.055</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow17_col3" class="data row17 col3" >-3.303</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow17_col4" class="data row17 col4" >0.001</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow17_col5" class="data row17 col5" >-0.289</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow17_col6" class="data row17 col6" >-0.073</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row18" class="row_heading level0 row18" >16</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow18_col0" class="data row18 col0" >Neighborhood_ClearCr</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow18_col1" class="data row18 col1" >-0.0037</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow18_col2" class="data row18 col2" >0.062</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow18_col3" class="data row18 col3" >-0.06</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow18_col4" class="data row18 col4" >0.952</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow18_col5" class="data row18 col5" >-0.126</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow18_col6" class="data row18 col6" >0.118</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row19" class="row_heading level0 row19" >17</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow19_col0" class="data row19 col0" >Neighborhood_CollgCr</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow19_col1" class="data row19 col1" >-0.0475</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow19_col2" class="data row19 col2" >0.05</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow19_col3" class="data row19 col3" >-0.945</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow19_col4" class="data row19 col4" >0.345</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow19_col5" class="data row19 col5" >-0.146</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow19_col6" class="data row19 col6" >0.051</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row20" class="row_heading level0 row20" >18</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow20_col0" class="data row20 col0" >Neighborhood_Crawfor</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow20_col1" class="data row20 col1" >-0.0062</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow20_col2" class="data row20 col2" >0.056</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow20_col3" class="data row20 col3" >-0.111</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow20_col4" class="data row20 col4" >0.912</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow20_col5" class="data row20 col5" >-0.116</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow20_col6" class="data row20 col6" >0.104</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row21" class="row_heading level0 row21" >19</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow21_col0" class="data row21 col0" >Neighborhood_Edwards</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow21_col1" class="data row21 col1" >-0.2503</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow21_col2" class="data row21 col2" >0.053</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow21_col3" class="data row21 col3" >-4.759</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow21_col4" class="data row21 col4" >0</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow21_col5" class="data row21 col5" >-0.353</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow21_col6" class="data row21 col6" >-0.147</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row22" class="row_heading level0 row22" >20</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow22_col0" class="data row22 col0" >Neighborhood_Gilbert</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow22_col1" class="data row22 col1" >-0.1145</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow22_col2" class="data row22 col2" >0.053</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow22_col3" class="data row22 col3" >-2.16</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow22_col4" class="data row22 col4" >0.031</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow22_col5" class="data row22 col5" >-0.219</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow22_col6" class="data row22 col6" >-0.01</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row23" class="row_heading level0 row23" >21</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow23_col0" class="data row23 col0" >Neighborhood_IDOTRR</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow23_col1" class="data row23 col1" >-0.3472</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow23_col2" class="data row23 col2" >0.058</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow23_col3" class="data row23 col3" >-6.022</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow23_col4" class="data row23 col4" >0</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow23_col5" class="data row23 col5" >-0.46</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow23_col6" class="data row23 col6" >-0.234</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row24" class="row_heading level0 row24" >22</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow24_col0" class="data row24 col0" >Neighborhood_MeadowV</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow24_col1" class="data row24 col1" >-0.2477</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow24_col2" class="data row24 col2" >0.064</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow24_col3" class="data row24 col3" >-3.842</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow24_col4" class="data row24 col4" >0</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow24_col5" class="data row24 col5" >-0.374</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow24_col6" class="data row24 col6" >-0.121</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row25" class="row_heading level0 row25" >23</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow25_col0" class="data row25 col0" >Neighborhood_Mitchel</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow25_col1" class="data row25 col1" >-0.1187</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow25_col2" class="data row25 col2" >0.055</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow25_col3" class="data row25 col3" >-2.159</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow25_col4" class="data row25 col4" >0.031</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow25_col5" class="data row25 col5" >-0.227</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow25_col6" class="data row25 col6" >-0.011</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row26" class="row_heading level0 row26" >24</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow26_col0" class="data row26 col0" >Neighborhood_NAmes</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow26_col1" class="data row26 col1" >-0.1471</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow26_col2" class="data row26 col2" >0.051</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow26_col3" class="data row26 col3" >-2.877</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow26_col4" class="data row26 col4" >0.004</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow26_col5" class="data row26 col5" >-0.247</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow26_col6" class="data row26 col6" >-0.047</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row27" class="row_heading level0 row27" >25</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow27_col0" class="data row27 col0" >Neighborhood_NPkVill</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow27_col1" class="data row27 col1" >-0.1554</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow27_col2" class="data row27 col2" >0.079</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow27_col3" class="data row27 col3" >-1.979</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow27_col4" class="data row27 col4" >0.048</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow27_col5" class="data row27 col5" >-0.31</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow27_col6" class="data row27 col6" >-0.001</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row28" class="row_heading level0 row28" >26</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow28_col0" class="data row28 col0" >Neighborhood_NWAmes</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow28_col1" class="data row28 col1" >-0.0834</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow28_col2" class="data row28 col2" >0.054</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow28_col3" class="data row28 col3" >-1.532</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow28_col4" class="data row28 col4" >0.126</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow28_col5" class="data row28 col5" >-0.19</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow28_col6" class="data row28 col6" >0.023</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row29" class="row_heading level0 row29" >27</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow29_col0" class="data row29 col0" >Neighborhood_NoRidge</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow29_col1" class="data row29 col1" >0.1044</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow29_col2" class="data row29 col2" >0.058</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow29_col3" class="data row29 col3" >1.802</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow29_col4" class="data row29 col4" >0.072</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow29_col5" class="data row29 col5" >-0.009</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow29_col6" class="data row29 col6" >0.218</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row30" class="row_heading level0 row30" >28</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow30_col0" class="data row30 col0" >Neighborhood_NridgHt</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow30_col1" class="data row30 col1" >0.0743</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow30_col2" class="data row30 col2" >0.053</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow30_col3" class="data row30 col3" >1.415</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow30_col4" class="data row30 col4" >0.157</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow30_col5" class="data row30 col5" >-0.029</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow30_col6" class="data row30 col6" >0.177</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row31" class="row_heading level0 row31" >29</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow31_col0" class="data row31 col0" >Neighborhood_OldTown</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow31_col1" class="data row31 col1" >-0.2502</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow31_col2" class="data row31 col2" >0.053</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow31_col3" class="data row31 col3" >-4.763</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow31_col4" class="data row31 col4" >0</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow31_col5" class="data row31 col5" >-0.353</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow31_col6" class="data row31 col6" >-0.147</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row32" class="row_heading level0 row32" >30</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow32_col0" class="data row32 col0" >Neighborhood_SWISU</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow32_col1" class="data row32 col1" >-0.1886</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow32_col2" class="data row32 col2" >0.061</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow32_col3" class="data row32 col3" >-3.115</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow32_col4" class="data row32 col4" >0.002</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow32_col5" class="data row32 col5" >-0.307</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow32_col6" class="data row32 col6" >-0.07</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row33" class="row_heading level0 row33" >31</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow33_col0" class="data row33 col0" >Neighborhood_Sawyer</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow33_col1" class="data row33 col1" >-0.1847</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow33_col2" class="data row33 col2" >0.054</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow33_col3" class="data row33 col3" >-3.431</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow33_col4" class="data row33 col4" >0.001</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow33_col5" class="data row33 col5" >-0.29</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow33_col6" class="data row33 col6" >-0.079</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row34" class="row_heading level0 row34" >32</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow34_col0" class="data row34 col0" >Neighborhood_SawyerW</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow34_col1" class="data row34 col1" >-0.097</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow34_col2" class="data row34 col2" >0.054</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow34_col3" class="data row34 col3" >-1.811</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow34_col4" class="data row34 col4" >0.07</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow34_col5" class="data row34 col5" >-0.202</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow34_col6" class="data row34 col6" >0.008</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row35" class="row_heading level0 row35" >33</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow35_col0" class="data row35 col0" >Neighborhood_Somerst</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow35_col1" class="data row35 col1" >-0.0108</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow35_col2" class="data row35 col2" >0.051</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow35_col3" class="data row35 col3" >-0.212</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow35_col4" class="data row35 col4" >0.832</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow35_col5" class="data row35 col5" >-0.111</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow35_col6" class="data row35 col6" >0.089</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row36" class="row_heading level0 row36" >34</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow36_col0" class="data row36 col0" >Neighborhood_StoneBr</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow36_col1" class="data row36 col1" >0.0881</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow36_col2" class="data row36 col2" >0.059</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow36_col3" class="data row36 col3" >1.482</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow36_col4" class="data row36 col4" >0.139</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow36_col5" class="data row36 col5" >-0.029</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow36_col6" class="data row36 col6" >0.205</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row37" class="row_heading level0 row37" >35</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow37_col0" class="data row37 col0" >Neighborhood_Timber</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow37_col1" class="data row37 col1" >-0.0728</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow37_col2" class="data row37 col2" >0.058</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow37_col3" class="data row37 col3" >-1.258</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow37_col4" class="data row37 col4" >0.209</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow37_col5" class="data row37 col5" >-0.186</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow37_col6" class="data row37 col6" >0.041</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row38" class="row_heading level0 row38" >36</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow38_col0" class="data row38 col0" >Neighborhood_Veenker</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow38_col1" class="data row38 col1" >-0.0736</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow38_col2" class="data row38 col2" >0.072</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow38_col3" class="data row38 col3" >-1.017</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow38_col4" class="data row38 col4" >0.309</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow38_col5" class="data row38 col5" >-0.216</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow38_col6" class="data row38 col6" >0.068</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row39" class="row_heading level0 row39" >8</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow39_col0" class="data row39 col0" >OpenPorchSF</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow39_col1" class="data row39 col1" >0.0133</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow39_col2" class="data row39 col2" >0.003</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow39_col3" class="data row39 col3" >4.909</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow39_col4" class="data row39 col4" >0</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow39_col5" class="data row39 col5" >0.008</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow39_col6" class="data row39 col6" >0.019</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row40" class="row_heading level0 row40" >39</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow40_col0" class="data row40 col0" >OverallCond_Bad</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow40_col1" class="data row40 col1" >-0.1522</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow40_col2" class="data row40 col2" >0.023</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow40_col3" class="data row40 col3" >-6.742</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow40_col4" class="data row40 col4" >0</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow40_col5" class="data row40 col5" >-0.196</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow40_col6" class="data row40 col6" >-0.108</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row41" class="row_heading level0 row41" >40</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow41_col0" class="data row41 col0" >OverallCond_Good</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow41_col1" class="data row41 col1" >0.0383</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow41_col2" class="data row41 col2" >0.013</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow41_col3" class="data row41 col3" >2.986</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow41_col4" class="data row41 col4" >0.003</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow41_col5" class="data row41 col5" >0.013</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow41_col6" class="data row41 col6" >0.064</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row42" class="row_heading level0 row42" >37</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow42_col0" class="data row42 col0" >OverallQual_Low</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow42_col1" class="data row42 col1" >-0.3001</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow42_col2" class="data row42 col2" >0.028</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow42_col3" class="data row42 col3" >-10.764</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow42_col4" class="data row42 col4" >0</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow42_col5" class="data row42 col5" >-0.355</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow42_col6" class="data row42 col6" >-0.245</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row43" class="row_heading level0 row43" >38</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow43_col0" class="data row43 col0" >OverallQual_Med</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow43_col1" class="data row43 col1" >-0.1717</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow43_col2" class="data row43 col2" >0.019</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow43_col3" class="data row43 col3" >-8.881</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow43_col4" class="data row43 col4" >0</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow43_col5" class="data row43 col5" >-0.21</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow43_col6" class="data row43 col6" >-0.134</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row44" class="row_heading level0 row44" >41</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow44_col0" class="data row44 col0" >RoofStyle_Hip</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow44_col1" class="data row44 col1" >0.0371</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow44_col2" class="data row44 col2" >0.013</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow44_col3" class="data row44 col3" >2.837</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow44_col4" class="data row44 col4" >0.005</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow44_col5" class="data row44 col5" >0.011</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow44_col6" class="data row44 col6" >0.063</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row45" class="row_heading level0 row45" >42</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow45_col0" class="data row45 col0" >RoofStyle_Others</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow45_col1" class="data row45 col1" >-0.0026</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow45_col2" class="data row45 col2" >0.037</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow45_col3" class="data row45 col3" >-0.071</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow45_col4" class="data row45 col4" >0.944</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow45_col5" class="data row45 col5" >-0.075</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow45_col6" class="data row45 col6" >0.069</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row46" class="row_heading level0 row46" >51</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow46_col0" class="data row46 col0" >SaleCondition_Normal</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow46_col1" class="data row46 col1" >0.0665</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow46_col2" class="data row46 col2" >0.02</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow46_col3" class="data row46 col3" >3.28</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow46_col4" class="data row46 col4" >0.001</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow46_col5" class="data row46 col5" >0.027</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow46_col6" class="data row46 col6" >0.106</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row47" class="row_heading level0 row47" >52</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow47_col0" class="data row47 col0" >SaleCondition_Other</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow47_col1" class="data row47 col1" >0.0452</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow47_col2" class="data row47 col2" >0.037</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow47_col3" class="data row47 col3" >1.22</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow47_col4" class="data row47 col4" >0.223</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow47_col5" class="data row47 col5" >-0.028</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow47_col6" class="data row47 col6" >0.118</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row48" class="row_heading level0 row48" >53</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow48_col0" class="data row48 col0" >SaleCondition_Partial</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow48_col1" class="data row48 col1" >0.2078</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow48_col2" class="data row48 col2" >0.155</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow48_col3" class="data row48 col3" >1.337</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow48_col4" class="data row48 col4" >0.182</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow48_col5" class="data row48 col5" >-0.097</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow48_col6" class="data row48 col6" >0.513</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row49" class="row_heading level0 row49" >49</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow49_col0" class="data row49 col0" >SaleType_Other</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow49_col1" class="data row49 col1" >0.0852</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow49_col2" class="data row49 col2" >0.158</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow49_col3" class="data row49 col3" >0.54</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow49_col4" class="data row49 col4" >0.589</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow49_col5" class="data row49 col5" >-0.225</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow49_col6" class="data row49 col6" >0.395</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row50" class="row_heading level0 row50" >50</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow50_col0" class="data row50 col0" >SaleType_WD</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow50_col1" class="data row50 col1" >0.0609</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow50_col2" class="data row50 col2" >0.156</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow50_col3" class="data row50 col3" >0.391</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow50_col4" class="data row50 col4" >0.696</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow50_col5" class="data row50 col5" >-0.245</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow50_col6" class="data row50 col6" >0.366</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row51" class="row_heading level0 row51" >9</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow51_col0" class="data row51 col0" >ScreenPorch</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow51_col1" class="data row51 col1" >0.0116</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow51_col2" class="data row51 col2" >0.004</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow51_col3" class="data row51 col3" >3.184</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow51_col4" class="data row51 col4" >0.002</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow51_col5" class="data row51 col5" >0.004</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow51_col6" class="data row51 col6" >0.019</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row52" class="row_heading level0 row52" >7</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow52_col0" class="data row52 col0" >WoodDeckSF</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow52_col1" class="data row52 col1" >0.0057</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow52_col2" class="data row52 col2" >0.002</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow52_col3" class="data row52 col3" >2.724</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow52_col4" class="data row52 col4" >0.007</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow52_col5" class="data row52 col5" >0.002</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow52_col6" class="data row52 col6" >0.01</td> 
    </tr>    <tr> 
        <th id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dflevel0_row53" class="row_heading level0 row53" >0</th> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow53_col0" class="data row53 col0" >const</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow53_col1" class="data row53 col1" >10.88</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow53_col2" class="data row53 col2" >0.197</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow53_col3" class="data row53 col3" >55.219</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow53_col4" class="data row53 col4" >0</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow53_col5" class="data row53 col5" >10.493</td> 
        <td id="T_915903ca_48dd_11e9_bcaa_48d224c0b2dfrow53_col6" class="data row53 col6" >11.267</td> 
    </tr></tbody> 
</table> 




```python
cols_to_drop = ['LotConfig_CulDSac', 'LotConfig_FR', 'LotConfig_Inside', 'SaleType_Other', 'SaleType_WD']
print(df_train_x.shape, df_test_x.shape)
df_train_x = df_train_x.drop(cols_to_drop, axis = 1)
df_test_x  = df_test_x.drop(cols_to_drop, axis = 1)
print(df_train_x.shape, df_test_x.shape)
```

    (1021, 54) (438, 54)
    (1021, 49) (438, 49)
    

#### 4.6.2 Building the Model


```python
X = df_train_x.copy()
y = df_train_y.apply(math.log)
lm_log_2 = sm.OLS(y, X).fit()
lm_log_2.summary()
```




<table class="simpletable">
<caption>OLS Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>        <td>SalePrice</td>    <th>  R-squared:         </th> <td>   0.862</td>
</tr>
<tr>
  <th>Model:</th>                   <td>OLS</td>       <th>  Adj. R-squared:    </th> <td>   0.855</td>
</tr>
<tr>
  <th>Method:</th>             <td>Least Squares</td>  <th>  F-statistic:       </th> <td>   126.6</td>
</tr>
<tr>
  <th>Date:</th>             <td>Sun, 17 Mar 2019</td> <th>  Prob (F-statistic):</th>  <td>  0.00</td> 
</tr>
<tr>
  <th>Time:</th>                 <td>23:23:32</td>     <th>  Log-Likelihood:    </th> <td>  494.09</td>
</tr>
<tr>
  <th>No. Observations:</th>      <td>  1021</td>      <th>  AIC:               </th> <td>  -890.2</td>
</tr>
<tr>
  <th>Df Residuals:</th>          <td>   972</td>      <th>  BIC:               </th> <td>  -648.7</td>
</tr>
<tr>
  <th>Df Model:</th>              <td>    48</td>      <th>                     </th>     <td> </td>   
</tr>
<tr>
  <th>Covariance Type:</th>      <td>nonrobust</td>    <th>                     </th>     <td> </td>   
</tr>
</table>
<table class="simpletable">
<tr>
            <td></td>               <th>coef</th>     <th>std err</th>      <th>t</th>      <th>P>|t|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>const</th>                 <td>   10.8961</td> <td>    0.117</td> <td>   93.029</td> <td> 0.000</td> <td>   10.666</td> <td>   11.126</td>
</tr>
<tr>
  <th>LotArea</th>               <td>    0.1211</td> <td>    0.013</td> <td>    9.318</td> <td> 0.000</td> <td>    0.096</td> <td>    0.147</td>
</tr>
<tr>
  <th>BsmtFullBath</th>          <td>    0.0749</td> <td>    0.011</td> <td>    6.951</td> <td> 0.000</td> <td>    0.054</td> <td>    0.096</td>
</tr>
<tr>
  <th>BsmtHalfBath</th>          <td>    0.0451</td> <td>    0.032</td> <td>    1.431</td> <td> 0.153</td> <td>   -0.017</td> <td>    0.107</td>
</tr>
<tr>
  <th>FullBath</th>              <td>    0.1531</td> <td>    0.012</td> <td>   12.390</td> <td> 0.000</td> <td>    0.129</td> <td>    0.177</td>
</tr>
<tr>
  <th>HalfBath</th>              <td>    0.0843</td> <td>    0.011</td> <td>    7.720</td> <td> 0.000</td> <td>    0.063</td> <td>    0.106</td>
</tr>
<tr>
  <th>Fireplaces</th>            <td>    0.0658</td> <td>    0.009</td> <td>    7.102</td> <td> 0.000</td> <td>    0.048</td> <td>    0.084</td>
</tr>
<tr>
  <th>WoodDeckSF</th>            <td>    0.0056</td> <td>    0.002</td> <td>    2.669</td> <td> 0.008</td> <td>    0.001</td> <td>    0.010</td>
</tr>
<tr>
  <th>OpenPorchSF</th>           <td>    0.0131</td> <td>    0.003</td> <td>    4.860</td> <td> 0.000</td> <td>    0.008</td> <td>    0.018</td>
</tr>
<tr>
  <th>ScreenPorch</th>           <td>    0.0115</td> <td>    0.004</td> <td>    3.169</td> <td> 0.002</td> <td>    0.004</td> <td>    0.019</td>
</tr>
<tr>
  <th>Neighborhood_Blueste</th>  <td>   -0.1107</td> <td>    0.120</td> <td>   -0.927</td> <td> 0.354</td> <td>   -0.345</td> <td>    0.124</td>
</tr>
<tr>
  <th>Neighborhood_BrDale</th>   <td>   -0.2180</td> <td>    0.063</td> <td>   -3.464</td> <td> 0.001</td> <td>   -0.342</td> <td>   -0.094</td>
</tr>
<tr>
  <th>Neighborhood_BrkSide</th>  <td>   -0.1868</td> <td>    0.055</td> <td>   -3.406</td> <td> 0.001</td> <td>   -0.294</td> <td>   -0.079</td>
</tr>
<tr>
  <th>Neighborhood_ClearCr</th>  <td>   -0.0026</td> <td>    0.062</td> <td>   -0.042</td> <td> 0.966</td> <td>   -0.125</td> <td>    0.120</td>
</tr>
<tr>
  <th>Neighborhood_CollgCr</th>  <td>   -0.0511</td> <td>    0.050</td> <td>   -1.017</td> <td> 0.310</td> <td>   -0.150</td> <td>    0.048</td>
</tr>
<tr>
  <th>Neighborhood_Crawfor</th>  <td>   -0.0124</td> <td>    0.056</td> <td>   -0.221</td> <td> 0.825</td> <td>   -0.122</td> <td>    0.097</td>
</tr>
<tr>
  <th>Neighborhood_Edwards</th>  <td>   -0.2522</td> <td>    0.053</td> <td>   -4.795</td> <td> 0.000</td> <td>   -0.355</td> <td>   -0.149</td>
</tr>
<tr>
  <th>Neighborhood_Gilbert</th>  <td>   -0.1166</td> <td>    0.053</td> <td>   -2.196</td> <td> 0.028</td> <td>   -0.221</td> <td>   -0.012</td>
</tr>
<tr>
  <th>Neighborhood_IDOTRR</th>   <td>   -0.3489</td> <td>    0.058</td> <td>   -6.051</td> <td> 0.000</td> <td>   -0.462</td> <td>   -0.236</td>
</tr>
<tr>
  <th>Neighborhood_MeadowV</th>  <td>   -0.2451</td> <td>    0.065</td> <td>   -3.794</td> <td> 0.000</td> <td>   -0.372</td> <td>   -0.118</td>
</tr>
<tr>
  <th>Neighborhood_Mitchel</th>  <td>   -0.1203</td> <td>    0.055</td> <td>   -2.186</td> <td> 0.029</td> <td>   -0.228</td> <td>   -0.012</td>
</tr>
<tr>
  <th>Neighborhood_NAmes</th>    <td>   -0.1516</td> <td>    0.051</td> <td>   -2.964</td> <td> 0.003</td> <td>   -0.252</td> <td>   -0.051</td>
</tr>
<tr>
  <th>Neighborhood_NPkVill</th>  <td>   -0.1592</td> <td>    0.079</td> <td>   -2.027</td> <td> 0.043</td> <td>   -0.313</td> <td>   -0.005</td>
</tr>
<tr>
  <th>Neighborhood_NWAmes</th>   <td>   -0.0847</td> <td>    0.055</td> <td>   -1.553</td> <td> 0.121</td> <td>   -0.192</td> <td>    0.022</td>
</tr>
<tr>
  <th>Neighborhood_NoRidge</th>  <td>    0.1034</td> <td>    0.058</td> <td>    1.788</td> <td> 0.074</td> <td>   -0.010</td> <td>    0.217</td>
</tr>
<tr>
  <th>Neighborhood_NridgHt</th>  <td>    0.0662</td> <td>    0.053</td> <td>    1.262</td> <td> 0.207</td> <td>   -0.037</td> <td>    0.169</td>
</tr>
<tr>
  <th>Neighborhood_OldTown</th>  <td>   -0.2521</td> <td>    0.052</td> <td>   -4.807</td> <td> 0.000</td> <td>   -0.355</td> <td>   -0.149</td>
</tr>
<tr>
  <th>Neighborhood_SWISU</th>    <td>   -0.1930</td> <td>    0.061</td> <td>   -3.184</td> <td> 0.001</td> <td>   -0.312</td> <td>   -0.074</td>
</tr>
<tr>
  <th>Neighborhood_Sawyer</th>   <td>   -0.1876</td> <td>    0.054</td> <td>   -3.478</td> <td> 0.001</td> <td>   -0.293</td> <td>   -0.082</td>
</tr>
<tr>
  <th>Neighborhood_SawyerW</th>  <td>   -0.0999</td> <td>    0.054</td> <td>   -1.862</td> <td> 0.063</td> <td>   -0.205</td> <td>    0.005</td>
</tr>
<tr>
  <th>Neighborhood_Somerst</th>  <td>   -0.0123</td> <td>    0.051</td> <td>   -0.241</td> <td> 0.809</td> <td>   -0.113</td> <td>    0.088</td>
</tr>
<tr>
  <th>Neighborhood_StoneBr</th>  <td>    0.0951</td> <td>    0.059</td> <td>    1.599</td> <td> 0.110</td> <td>   -0.022</td> <td>    0.212</td>
</tr>
<tr>
  <th>Neighborhood_Timber</th>   <td>   -0.0773</td> <td>    0.058</td> <td>   -1.334</td> <td> 0.182</td> <td>   -0.191</td> <td>    0.036</td>
</tr>
<tr>
  <th>Neighborhood_Veenker</th>  <td>   -0.0785</td> <td>    0.072</td> <td>   -1.094</td> <td> 0.274</td> <td>   -0.219</td> <td>    0.062</td>
</tr>
<tr>
  <th>OverallQual_Low</th>       <td>   -0.3045</td> <td>    0.028</td> <td>  -10.948</td> <td> 0.000</td> <td>   -0.359</td> <td>   -0.250</td>
</tr>
<tr>
  <th>OverallQual_Med</th>       <td>   -0.1740</td> <td>    0.019</td> <td>   -9.005</td> <td> 0.000</td> <td>   -0.212</td> <td>   -0.136</td>
</tr>
<tr>
  <th>OverallCond_Bad</th>       <td>   -0.1518</td> <td>    0.023</td> <td>   -6.741</td> <td> 0.000</td> <td>   -0.196</td> <td>   -0.108</td>
</tr>
<tr>
  <th>OverallCond_Good</th>      <td>    0.0386</td> <td>    0.013</td> <td>    3.030</td> <td> 0.003</td> <td>    0.014</td> <td>    0.064</td>
</tr>
<tr>
  <th>RoofStyle_Hip</th>         <td>    0.0362</td> <td>    0.013</td> <td>    2.765</td> <td> 0.006</td> <td>    0.010</td> <td>    0.062</td>
</tr>
<tr>
  <th>RoofStyle_Others</th>      <td>   -0.0054</td> <td>    0.037</td> <td>   -0.149</td> <td> 0.882</td> <td>   -0.077</td> <td>    0.066</td>
</tr>
<tr>
  <th>BsmtExposure_Gd</th>       <td>    0.0870</td> <td>    0.021</td> <td>    4.070</td> <td> 0.000</td> <td>    0.045</td> <td>    0.129</td>
</tr>
<tr>
  <th>BsmtExposure_Mn</th>       <td>    0.0372</td> <td>    0.022</td> <td>    1.707</td> <td> 0.088</td> <td>   -0.006</td> <td>    0.080</td>
</tr>
<tr>
  <th>BsmtExposure_No</th>       <td>    0.0078</td> <td>    0.015</td> <td>    0.511</td> <td> 0.609</td> <td>   -0.022</td> <td>    0.038</td>
</tr>
<tr>
  <th>BsmtExposure_None</th>     <td>   -0.1168</td> <td>    0.035</td> <td>   -3.311</td> <td> 0.001</td> <td>   -0.186</td> <td>   -0.048</td>
</tr>
<tr>
  <th>KitchenQual_Low</th>       <td>   -0.2296</td> <td>    0.025</td> <td>   -9.100</td> <td> 0.000</td> <td>   -0.279</td> <td>   -0.180</td>
</tr>
<tr>
  <th>KitchenQual_Med</th>       <td>   -0.1485</td> <td>    0.023</td> <td>   -6.477</td> <td> 0.000</td> <td>   -0.194</td> <td>   -0.104</td>
</tr>
<tr>
  <th>SaleCondition_Normal</th>  <td>    0.0597</td> <td>    0.020</td> <td>    3.048</td> <td> 0.002</td> <td>    0.021</td> <td>    0.098</td>
</tr>
<tr>
  <th>SaleCondition_Other</th>   <td>    0.0406</td> <td>    0.037</td> <td>    1.107</td> <td> 0.268</td> <td>   -0.031</td> <td>    0.113</td>
</tr>
<tr>
  <th>SaleCondition_Partial</th> <td>    0.1406</td> <td>    0.027</td> <td>    5.180</td> <td> 0.000</td> <td>    0.087</td> <td>    0.194</td>
</tr>
</table>
<table class="simpletable">
<tr>
  <th>Omnibus:</th>       <td>106.079</td> <th>  Durbin-Watson:     </th> <td>   1.939</td>
</tr>
<tr>
  <th>Prob(Omnibus):</th> <td> 0.000</td>  <th>  Jarque-Bera (JB):  </th> <td> 304.831</td>
</tr>
<tr>
  <th>Skew:</th>          <td>-0.529</td>  <th>  Prob(JB):          </th> <td>6.41e-67</td>
</tr>
<tr>
  <th>Kurtosis:</th>      <td> 5.459</td>  <th>  Cond. No.          </th> <td>    501.</td>
</tr>
</table><br/><br/>Warnings:<br/>[1] Standard Errors assume that the covariance matrix of the errors is correctly specified.




```python
X = df_test_x.copy()
y = df_test_y.apply(math.log)
rmse_log_2 = rmse(lm_log_2, X, y)
print(rmse_log_2)
```

    0.1765
    

As can be seen in the summary
>* We have no insignificant variables
>* Our Adjusted R-squared value is a little over 0.85
>* Our F-statistic is 126
>* Our RMSE has barely shifted and still stands at a healthy 0.149

In order to consider this as our final model, we will do two tests.
>1. Compare all the models and select the best model.
>2. We will see if all assumptions are held true for this model.

### 5. Model Selection
#### 5.1 Model Comparison




```python
model_comp = pd.DataFrame({'Model Name': ['lm_base', 'lm_2', 'lm_3', 'lm_log_1', 'lm_log_2'],
                           'R-squared': [lm_base.rsquared, lm_2.rsquared, lm_3.rsquared,  lm_log_1.rsquared, lm_log_2.rsquared],
                           'Adj. R-squared': [lm_base.rsquared_adj, lm_2.rsquared_adj, lm_3.rsquared_adj,  lm_log_1.rsquared_adj, lm_log_2.rsquared_adj],
                           'F-Statistic': [lm_base.fvalue, lm_2.fvalue, lm_3.fvalue, lm_log_1.fvalue, lm_log_2.fvalue],
                           'RMSE': [rmse_base, rmse_2, rmse_3, rmse_log_1, rmse_log_2],
                           'RMSE (log scale)': [rmse_base_log_scale, rmse_2_log_scale, rmse_3_log_scale, rmse_log_1, rmse_log_2]})
model_comp
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Model Name</th>
      <th>R-squared</th>
      <th>Adj. R-squared</th>
      <th>F-Statistic</th>
      <th>RMSE</th>
      <th>RMSE (log scale)</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>lm_base</td>
      <td>0.875254</td>
      <td>0.855078</td>
      <td>43.382211</td>
      <td>38323.7447</td>
      <td>0.1744</td>
    </tr>
    <tr>
      <th>1</th>
      <td>lm_2</td>
      <td>0.856679</td>
      <td>0.845467</td>
      <td>76.412847</td>
      <td>37868.6155</td>
      <td>0.1798</td>
    </tr>
    <tr>
      <th>2</th>
      <td>lm_3</td>
      <td>0.848725</td>
      <td>0.840434</td>
      <td>102.365002</td>
      <td>38344.1160</td>
      <td>0.1793</td>
    </tr>
    <tr>
      <th>3</th>
      <td>lm_log_1</td>
      <td>0.863426</td>
      <td>0.855940</td>
      <td>115.347202</td>
      <td>0.1761</td>
      <td>0.1761</td>
    </tr>
    <tr>
      <th>4</th>
      <td>lm_log_2</td>
      <td>0.862079</td>
      <td>0.855268</td>
      <td>126.573092</td>
      <td>0.1765</td>
      <td>0.1765</td>
    </tr>
  </tbody>
</table>
</div>



As can be seen, to select the best model of these five can be quite a confusion. So, we are going to use Occam's Razor principle to select the best suited model.

> Occam’s Razor principle -  
“When presented with competing hypothetical answers to a problem, one should select the one that makes the fewest assumptions”. 

According to this statement we consider Linear Regression Model **lm_log_2** with **R-Squared value of 0.86** and **RMSE of 0.1491** to make the model perform better with new data as well.

#### 5.2 Validating Assumptions
Now that we have chosen our model, we will have to see that it satisfies all the assumptions given below.
>1. Mean of residuals is (close to) zero.
>2. Residuals have a constant variance
>3. Residuals are normally distributed.


```python
# Function to get residuals
def get_residuals(lm, X, y):
    predicted = lm.predict(X)
    actual = y
    residual = actual - predicted
    return residual

# Residual Mean
residuals = get_residuals(lm_log_2, X, y)
print("Residual Mean =", residuals.mean())
```

    Residual Mean = -0.005373166441867121
    


```python
# Residual Variance
y_hat = lm_log_2.predict(X)
sns.residplot(residuals, y_hat, lowess = True, color = 'g');
```


![png](output_157_0.png)



```python
# Residual Distribution
import scipy.stats as stats
import pylab
stats.probplot(residuals, dist = 'norm', plot = pylab);
```


![png](output_158_0.png)


We can safely say that our model is sound as all the assumptions are validated. We will now use this model to predict the values on the testing data set.

### 6. Predictions for the Test Dataset
#### 6.1 Cleaning test dataset


```python
df_train_x.shape
```




    (1021, 49)




```python
cols_to_drop = list(set(test.columns).difference(set(df_train_x.columns)))
cols_to_drop.remove("Id")
test = test.drop(cols_to_drop, axis = 1)
test.shape
```




    (1446, 47)




```python
list(set(df_train_x.columns).difference(set(test.columns)))
```




    ['OverallQual_Med', 'OverallQual_Low', 'const']



As can be seen, we need to add 3 more columns to the test dataset.


```python
test = sm.add_constant(test)
test['OverallQual_Med'], test['OverallQual_Low'] = 0, 0
test.shape
```




    (1446, 50)



#### 6.2 Predictions


```python
predict = lm_log_2.predict(test.drop('Id', axis = 1))
result = pd.DataFrame({'Id': test['Id'],
                       'Sale Price': predict.apply(math.exp).apply(round)})
result.head(50)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Id</th>
      <th>Sale Price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1461</td>
      <td>134003</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1462</td>
      <td>113130</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1463</td>
      <td>227001</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1464</td>
      <td>162470</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1465</td>
      <td>195826</td>
    </tr>
    <tr>
      <th>5</th>
      <td>1466</td>
      <td>220449</td>
    </tr>
    <tr>
      <th>6</th>
      <td>1467</td>
      <td>165296</td>
    </tr>
    <tr>
      <th>7</th>
      <td>1468</td>
      <td>209465</td>
    </tr>
    <tr>
      <th>8</th>
      <td>1469</td>
      <td>161873</td>
    </tr>
    <tr>
      <th>9</th>
      <td>1470</td>
      <td>156845</td>
    </tr>
    <tr>
      <th>10</th>
      <td>1471</td>
      <td>174261</td>
    </tr>
    <tr>
      <th>11</th>
      <td>1472</td>
      <td>122016</td>
    </tr>
    <tr>
      <th>12</th>
      <td>1473</td>
      <td>118208</td>
    </tr>
    <tr>
      <th>13</th>
      <td>1474</td>
      <td>123660</td>
    </tr>
    <tr>
      <th>14</th>
      <td>1475</td>
      <td>105114</td>
    </tr>
    <tr>
      <th>15</th>
      <td>1476</td>
      <td>363522</td>
    </tr>
    <tr>
      <th>16</th>
      <td>1477</td>
      <td>266094</td>
    </tr>
    <tr>
      <th>17</th>
      <td>1478</td>
      <td>210848</td>
    </tr>
    <tr>
      <th>18</th>
      <td>1479</td>
      <td>211091</td>
    </tr>
    <tr>
      <th>19</th>
      <td>1480</td>
      <td>260184</td>
    </tr>
    <tr>
      <th>20</th>
      <td>1481</td>
      <td>250525</td>
    </tr>
    <tr>
      <th>21</th>
      <td>1482</td>
      <td>186358</td>
    </tr>
    <tr>
      <th>22</th>
      <td>1483</td>
      <td>176018</td>
    </tr>
    <tr>
      <th>23</th>
      <td>1484</td>
      <td>150553</td>
    </tr>
    <tr>
      <th>24</th>
      <td>1485</td>
      <td>204290</td>
    </tr>
    <tr>
      <th>25</th>
      <td>1486</td>
      <td>189560</td>
    </tr>
    <tr>
      <th>26</th>
      <td>1487</td>
      <td>237242</td>
    </tr>
    <tr>
      <th>27</th>
      <td>1488</td>
      <td>175796</td>
    </tr>
    <tr>
      <th>28</th>
      <td>1489</td>
      <td>206530</td>
    </tr>
    <tr>
      <th>29</th>
      <td>1490</td>
      <td>222957</td>
    </tr>
    <tr>
      <th>30</th>
      <td>1491</td>
      <td>172927</td>
    </tr>
    <tr>
      <th>31</th>
      <td>1492</td>
      <td>155531</td>
    </tr>
    <tr>
      <th>32</th>
      <td>1493</td>
      <td>187066</td>
    </tr>
    <tr>
      <th>33</th>
      <td>1494</td>
      <td>269313</td>
    </tr>
    <tr>
      <th>34</th>
      <td>1495</td>
      <td>261643</td>
    </tr>
    <tr>
      <th>35</th>
      <td>1496</td>
      <td>178488</td>
    </tr>
    <tr>
      <th>36</th>
      <td>1497</td>
      <td>173806</td>
    </tr>
    <tr>
      <th>37</th>
      <td>1498</td>
      <td>158511</td>
    </tr>
    <tr>
      <th>38</th>
      <td>1499</td>
      <td>181167</td>
    </tr>
    <tr>
      <th>39</th>
      <td>1500</td>
      <td>181083</td>
    </tr>
    <tr>
      <th>40</th>
      <td>1501</td>
      <td>180692</td>
    </tr>
    <tr>
      <th>41</th>
      <td>1502</td>
      <td>164278</td>
    </tr>
    <tr>
      <th>42</th>
      <td>1503</td>
      <td>277997</td>
    </tr>
    <tr>
      <th>43</th>
      <td>1504</td>
      <td>227425</td>
    </tr>
    <tr>
      <th>44</th>
      <td>1505</td>
      <td>210274</td>
    </tr>
    <tr>
      <th>45</th>
      <td>1506</td>
      <td>148728</td>
    </tr>
    <tr>
      <th>46</th>
      <td>1507</td>
      <td>197180</td>
    </tr>
    <tr>
      <th>47</th>
      <td>1508</td>
      <td>240028</td>
    </tr>
    <tr>
      <th>48</th>
      <td>1509</td>
      <td>161501</td>
    </tr>
    <tr>
      <th>49</th>
      <td>1510</td>
      <td>155108</td>
    </tr>
  </tbody>
</table>
</div>



#### --------------------------------- End of Markdown ---------------------------------
##### Thank You for reading
